package Objects;
import Actors.Gender;
import Actors.Staff;
import Actors.SuperAdmin;
import Actors.User;
import Services.Booking;
import java.util.ArrayList;
import java.util.List;
public class Storage {

    // TRAIN DB
    public static List<Train> TrainInventory = new ArrayList<>();

    // STAFF DB

    public static List<Staff> StaffDatabase = new ArrayList<>();

    static {
        StaffDatabase.add(new SuperAdmin("Sailuksha", "9999999999", "sa001@railway.in", "sa001@123"));
    }

    //USER DATABASE

    public static List<User> UserDB = new ArrayList<>();

    static {
        UserDB.add(new User("Sailuksha", "9442919737", "sai@gmail.com", "sailuksha", null, Gender.FEMALE, "288374009424"));
    }

    //BOOKING DB

    public static List<Booking> ActiveBookings = new ArrayList<>();
}


