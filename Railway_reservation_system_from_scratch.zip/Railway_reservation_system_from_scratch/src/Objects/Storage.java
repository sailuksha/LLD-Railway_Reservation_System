package Objects;
import Enums.CoachType;
import Enums.Gender;
import Actors.Staff;
import Actors.SuperAdmin;
import Actors.User;
import Services.BookingService;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Storage {
    // TRAIN DB
    public static List<Train> TrainInventory = new ArrayList<>();
    static{
        Train train1 = new Train(12623, "Chennai", "Trivandrum", "Chennai, Coimbatore, Ernakulam, Trivandrum", 500.0);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train1, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train1, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train1, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train1, 10, 10, 10);
        TrainInventory.add(train1);


        Train train2 = new Train(16345, "Coimbatore", "Bangalore", "Coimbatore, Erode, Salem, Bangalore", 400.0);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train2, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train2, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train2, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train2, 10, 10, 10);

        TrainInventory.add(train2);

        Train train3 = new Train(20607, "Chennai", "Mysore", "Chennai, Katpadi, Bengaluru, Mysore", 750.0);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train3, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train3, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train3, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train3, 10, 10, 10);

        TrainInventory.add(train3);


        Train train4 = new Train(20608, "Mysore", "Chennai", "Mysore, Bengaluru, Katpadi, Chennai", 750.0);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train4, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train4, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train4, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train4, 10, 10, 10);

        TrainInventory.add(train4);



        Train train5 = new Train(20631, "Mysore", "Chennai", "Mysore, Bengaluru, Katpadi, Chennai", 1200.0);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train5, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train5, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train5, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train5, 10, 10, 10);
        TrainInventory.add(train5);



        Train train6 = new Train(20642, "Coimbatore", "Bangalore", "Coimbatore, Tiruppur, Erode, Salem, Bengaluru", 1100.0);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train6, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train6, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train6, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train6, 10, 10, 10);
        TrainInventory.add(train6);


        Train train7 = new Train(12675, "Chennai", "Coimbatore", "Chennai, Salem, Erode, Tiruppur, Coimbatore", 450.0);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train7, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train7, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train7, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train7, 10, 10, 10);

        TrainInventory.add(train7);


        Train train8 = new Train(12625, "Trivandrum", "Delhi", "Trivandrum, Ernakulam, Kozhikode, Mangalore, Mumbai, Kota, Delhi", 1800.0);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_CHAIR_CAR, 1, train8, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.EXECUTIVE_CHAIR_CAR, 1, train8, 10, 10, 10);
        TrainInventory.add(train8);


        Train train9 = new Train(12664, "Howrah", "Chennai", "Howrah, Bhubaneswar, Visakhapatnam, Vijayawada, Chennai", 950.0);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_CHAIR_CAR, 1, train9, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.EXECUTIVE_CHAIR_CAR, 1, train9, 10, 10, 10);
        TrainInventory.add(train9);

        Train train10 = new Train(12627, "Chennai", "Delhi", "Chennai, Vijayawada, Nagpur, Bhopal, Agra, Delhi", 1600.0);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_CHAIR_CAR, 1, train10, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.EXECUTIVE_CHAIR_CAR, 1, train10, 10, 10, 10);
        TrainInventory.add(train10);


        Train train11 = new Train(20665, "Chennai", "Tirunelveli", "Chennai, Villupuram, Trichy, Madurai, Tirunelveli", 900.0);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train11, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train11, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train11, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train11, 10, 10, 10);
        TrainInventory.add(train11);


        Train train12 = new Train(20627, "Chennai", "Nagercoil", "Chennai, Villupuram, Trichy, Madurai, Nagercoil", 1300.0);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train12, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train12, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train12, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train12, 10, 10, 10);
        TrainInventory.add(train12);


        Train train13 = new Train(12678, "Bangalore", "Ernakulam", "Bangalore, Salem, Erode, Coimbatore, Palakkad, Ernakulam", 650.0);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train13, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train13, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train13, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train13, 10, 10, 10);
        TrainInventory.add(train13);


        Train train14 = new Train(16316, "Mysore", "Trivandrum", "Mysore, Bangalore, Erode, Coimbatore, Ernakulam, Trivandrum", 850.0);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train14, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train14, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train14, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train14, 10, 10, 10);
        TrainInventory.add(train14);

        Train train15 = new Train(20633, "Mangalore", "Madgaon", "Mangalore, Udupi, Karwar, Madgaon", 1000.0);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train15, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train15, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train15, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train15, 10, 10, 10);
        TrainInventory.add(train15);
    }
    // STAFF DB
    public static List<Staff> StaffDatabase = new ArrayList<>();
    static {StaffDatabase.add(new SuperAdmin("SA001","Sailuksha", "9999999999", "sa001@railway.in", "sa001@123"));}
    //USER DATABASE
    public static List<User> UserDB = new ArrayList<>();
    static {UserDB.add(new User("Sailuksha", "9442919737", "sai@gmail.com", "sailuksha", LocalDate.of(2005,5,15), Gender.FEMALE, "288374009424"));}
    //BOOKING DB
    public static List<BookingService> ActiveBookings = new ArrayList<>();
}