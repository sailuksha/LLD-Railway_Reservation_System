package Objects;
import Actors.Staff;
import java.util.Scanner;
import static Objects.Coach.AddCoach;
import static Objects.Storage.TrainInventory;
import static Objects.Train.DisplayTrainInventory;
import static Objects.Train.ValidateTrain;
import static PortalRunners.ChartAndReport.Redirect;
import static Services.InputValidators.OnlyFloat;
import static Services.InputValidators.OnlyInteger;

public class Inventory {

    public static void EditInventory(Scanner scanner, Staff staff) {
        boolean run=true;
        while (run) {
            System.out.println(" EDITING INVENTORY : ");
            System.out.println("1.Add train ");
            System.out.println("2.Edit train");
            System.out.println("3.Remove train");
            System.out.println("4.Exit");
            System.out.println("Enter : ");
            int ch = OnlyInteger(scanner);
            switch (ch) {
                case 1 -> {
                    int trainNo;
                    DisplayTrainInventory(TrainInventory);
                    while (true) {
                        System.out.println("ADDING TRAIN : ");
                        System.out.println("Enter train no : ");
                        trainNo = OnlyInteger(scanner);
                        if (!ValidateTrain(trainNo)) {
                            System.out.println("Train already exists");
                        } else {
                            break;
                        }
                    }
                    System.out.println("Enter source : ");
                    String source = scanner.nextLine().trim();
                    System.out.println("Enter destination : ");
                    String dest = scanner.nextLine().trim();
                    System.out.println("Enter complete route : ");
                    String Route = scanner.nextLine().trim();
                    double BaseFare = OnlyFloat(scanner, "Enter base fare : ");
                    Train NewTrain = new Train(trainNo, source, dest, Route, BaseFare);
                    AddCoach(scanner, NewTrain);
                    TrainInventory.add(NewTrain);
                    System.out.println("Added successfully.");
                    Redirect(scanner,staff);
                }
                case 2 -> {
                    DisplayTrainInventory(TrainInventory);
                    System.out.println("EDITTING TRAIN : ");
                    System.out.println("Enter the train no to be edited : ");
                    int trainno = OnlyInteger(scanner);
                    Train TrainToEdit = null;
                    for (Train t : TrainInventory) {
                        if (trainno == t.getTrainNo()) {
                            TrainToEdit = t;
                            break;
                        }
                    }
                    if (TrainToEdit == null) {
                        System.out.println("Train not found!");
                        break;
                    }
                    System.out.println("1.Edit train no \n 2.Edit source \n 3.Edit destination \n 4.Edit basefare \n5.Edit Coaches");
                    int choose = OnlyInteger(scanner);
                    switch (choose) {
                        case 1 -> {
                            System.out.println("Enter new trainno : ");
                            int NewTrainNo = OnlyInteger(scanner);
                            TrainToEdit.setTrainNo(NewTrainNo);
                            System.out.println("editted");
                        }
                        case 2 -> {
                            System.out.println("Enter new source : ");
                            String NewSource = scanner.nextLine().trim();
                            TrainToEdit.setSource(NewSource);
                            System.out.println("editted");
                        }
                        case 3 -> {
                            System.out.println("Enter new destination : ");
                            String NewDestination = scanner.nextLine().trim();
                            TrainToEdit.setDestination(NewDestination);
                            System.out.println("editted");
                        }
                        case 4 -> {
                            double NewBaseFare = OnlyFloat(scanner, "Enter new Basefare : ");
                            TrainToEdit.SetBaseFare(NewBaseFare);
                            System.out.println("editted");
                        }
                        case 5 -> {
                            EditCoach(scanner, TrainToEdit);
                        }
                    }
                    Redirect(scanner,staff);
                }
                case 3 -> {
                    DisplayTrainInventory(TrainInventory);
                    System.out.println("Enter trainno to remove : ");
                    int TrainToRemoveno = OnlyInteger(scanner);
                    Train Traintoremove = null;
                    for (Train t : TrainInventory) {
                        if (t.getTrainNo() == TrainToRemoveno) {
                            Traintoremove = t;
                            break;
                        }
                    }
                    if (Traintoremove != null) {
                        TrainInventory.remove(Traintoremove);
                        System.out.println(TrainToRemoveno + " removed.");
                        Redirect(scanner,staff);
                    } else {
                        System.out.println("Train does not exist");
                    }
                }
                case 4 ->{
                    run=false;
                    Redirect(scanner,staff);
                }
                default -> {
                    System.out.println("invalid option!");
                }
            }
        }
    }

    public static void EditCoach(Scanner scanner, Train train) {

        System.out.println("EDITING COACHES IN TRAIN: " + train.getTrainNo());
        System.out.println("1. Add coach");
        System.out.println("2. Remove coach");
        System.out.println("3. Exit");

        int choice = OnlyInteger(scanner);

        switch (choice) {

            case 1 -> AddCoach(scanner, train);

            case 2 -> {

                if (train.GetCoaches().isEmpty()) {
                    System.out.println("No coaches available!");
                    return;
                }

                for (Coach c : train.GetCoaches()) {
                    System.out.println(
                            c.getCoachId() + " | " + c.getCoachType()
                    );
                }

                System.out.println("Enter coach ID to remove:");
                String id = scanner.next().trim();
                Coach coachToRemove = null;
                for (Coach c : train.GetCoaches()) {
                    if (c.getCoachId().equalsIgnoreCase(id)) {
                        coachToRemove = c;
                        break;
                    }
                }
                if (coachToRemove != null) {
                    train.RemoveCoaches(coachToRemove);
                    System.out.println("Coach removed successfully!");
                } else {
                    System.out.println("Coach not found!");
                }
            }
            case 3 -> {
                return;
            }
            default -> System.out.println("Invalid choice!");
        }
    }
}