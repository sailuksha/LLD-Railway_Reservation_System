package Objects;
import Services.Passenger;
import Enums.BookingStatus;
import java.util.ArrayList;
import java.util.List;

public class SeatInventory {

    private List<Seat> availableSeats = new ArrayList<>();
    private List<Passenger> racList = new ArrayList<>();
    private List<Passenger> waitingList = new ArrayList<>();
    private int Totalrac;
    private int totalWaitlist;

    public SeatInventory(int racLimit, int waitingListLimit) {
        this.Totalrac = racLimit;
        this.totalWaitlist = waitingListLimit;
    }

    public List<Seat> getAvailableSeats() {
        return availableSeats;
    }

    public List<Passenger> getRacList() {
        return racList;
    }

    public List<Passenger> getWaitingList() {
        return waitingList;
    }
    public boolean hasAvailableSeat() {
        return !availableSeats.isEmpty();
    }

    public boolean RacCapacity() {
        return racList.size() < Totalrac;
    }

    public boolean WaitingListCapacity() {
        return waitingList.size() < totalWaitlist;
    }

    public boolean addRacPassenger(Passenger passenger) {
        if (!RacCapacity()) {
            return false;
        }
        racList.add(passenger);
        passenger.setBookingStatus(BookingStatus.RAC);
        passenger.setWaitListNo(0);
        return true;
    }
    public boolean addWaitingPassenger(Passenger passenger) {
        if (!WaitingListCapacity()) {
            return false;
        }
        waitingList.add(passenger);
        passenger.setBookingStatus(BookingStatus.WAITLIST);
        passenger.setWaitListNo(waitingList.size());
        return true;
    }
    public Passenger removeFirstRacPassenger() {
        if (racList.isEmpty()) {
            return null;
        }
        return racList.remove(0);
    }
    public Passenger removeFirstWaitingPassenger() {
        if (waitingList.isEmpty()) {
            return null;
        }
        Passenger passenger = waitingList.remove(0);
        updateWaitingListNumbers();
        return passenger;
    }

    public boolean removeRacPassenger(Passenger passenger) {
        return racList.remove(passenger);
    }
    public boolean removeWaitingPassenger(Passenger passenger) {
        boolean removed = waitingList.remove(passenger);
        if (removed) {
            updateWaitingListNumbers();

        }
        return removed;
    }
    private void updateWaitingListNumbers() {
        for (int i = 0; i < waitingList.size(); i++) {
            waitingList.get(i).setWaitListNo(i + 1);
        }
    }
    public void addAvailableSeat(Seat seat) {
        if (seat != null && !availableSeats.contains(seat)) {
            seat.setBookingstatus(BookingStatus.AVAILABLE);
            availableSeats.add(seat);
        }
    }
    public void removeAvailableSeat(Seat seat) {
        availableSeats.remove(seat);
    }
}
