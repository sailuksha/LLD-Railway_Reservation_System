package Objects;
import Enums.*;
import java.util.*;
import static Services.InputValidators.OnlyInteger;

public class Coach {
    private String CoachId;
    private CoachType Type;
    private int GeneralSeats;
    private int ladiesSeats;
    private int seniorCitizenSeats;
    private int physicallyChallengedSeats;
    private int TatkalSeats;
    private SeatInventory seatInventory;
    private List<Seat> seats = new ArrayList<>();
    private List<Seat> TotalConfirmedSeats = new ArrayList<>();

    public Coach(String coachId, CoachType type, int generalSeats, int ladiesSeats, int seniorSeats, int physicallySeats) {
        this.CoachId = coachId;
        this.Type = type;
        int tatkal = (int) Math.ceil(generalSeats * 0.10);
        int premiumTatkal = (int) Math.ceil(generalSeats * 0.05);
        this.GeneralSeats = generalSeats - tatkal - premiumTatkal;
        this.TatkalSeats = tatkal;
        this.ladiesSeats = ladiesSeats;
        this.seniorCitizenSeats = seniorSeats;
        this.physicallyChallengedSeats = physicallySeats;
        this.seatInventory = new SeatInventory(TotalRacCount(type), TotalWaitlistCount(type)
        );
    }
    private int TotalRacCount(CoachType type) {
        return switch (type) {
            case AC_FIRST, EXECUTIVE_CHAIR_CAR, AC_CHAIR_CAR -> 0;
            case AC_2TIER -> 18;
            case AC_3TIER -> 18;
            case SLEEPER -> 18;
        };
    }
    private int TotalWaitlistCount(CoachType type) {
        return switch (type) {
            case AC_FIRST -> 10;
            case AC_2TIER -> 15;
            case AC_3TIER -> 30;
            case SLEEPER -> 30;
            case EXECUTIVE_CHAIR_CAR, AC_CHAIR_CAR -> 10;
        };
    }
    public SeatInventory getSeatInventory() {
        return seatInventory;
    }

    public void addtoTotalConfirmedSeats(Seat seat) {
        if (!TotalConfirmedSeats.contains(seat)) {
            TotalConfirmedSeats.add(seat);
        }
    }
    public void removeFromTotalConfirmedSeats(Seat seat) {
        TotalConfirmedSeats.remove(seat);
    }

    public List<Seat> getTotalAvailableSeats() {
        return seatInventory.getAvailableSeats();
    }

    public List<Seat> getTotalConfirmedSeats() {
        return TotalConfirmedSeats;
    }

    public CoachType getCoachType() {
        return Type;
    }

    public String getCoachId() {
        return CoachId;
    }

    private static BerthType AssignBerthType(int seatNo, CoachType coachType) {

        if (coachType == CoachType.AC_FIRST) {
            return seatNo % 2 == 1 ? BerthType.LOWER : BerthType.UPPER;
        }

        if (coachType == CoachType.AC_2TIER) {
            int rem = seatNo % 6;

            return switch (rem) {
                case 1, 3 -> BerthType.LOWER;
                case 2, 4 -> BerthType.UPPER;
                case 5 -> BerthType.SIDE_LOWER;
                default -> BerthType.SIDE_UPPER;
            };
        }

        if (coachType == CoachType.AC_3TIER || coachType == CoachType.SLEEPER) {
            int rem = seatNo % 8;
            return switch (rem) {
                case 1, 4 -> BerthType.LOWER;
                case 2, 5 -> BerthType.MIDDLE;
                case 3, 6 -> BerthType.UPPER;
                case 7 -> BerthType.SIDE_LOWER;
                default -> BerthType.SIDE_UPPER;
            };
        }
        return BerthType.CHAIR_CAR;
    }
    public void addSeats(Seat seat) {
        seats.add(seat);
        seatInventory.addAvailableSeat(seat);
    }
    public void GenerateSeats(Train train, int ladiesSeat, int seniorCitizenSeat, int physicallyChallengedSeats) {
        int totalSeats = Type.getTotalSeats();
        int ladiesCount = 0;
        int seniorCount = 0;
        int physicallyCount = 0;
        int tatkalcount=0;
        for (int i = 1; i <= totalSeats; i++) {
            BerthType berthType = AssignBerthType(i, Type);
            QuotaType quotaType;
            if (ladiesCount < ladiesSeat) {
                quotaType = QuotaType.LADIES;
                ladiesCount++;
            } else if (physicallyCount < physicallyChallengedSeats && berthType == BerthType.LOWER) {
                quotaType = QuotaType.PHYSICALLY_CHALLENGED;
                physicallyCount++;
            } else if (seniorCount < seniorCitizenSeat && berthType == BerthType.LOWER) {
                quotaType = QuotaType.SENIOR_CITIZEN;
                seniorCount++;
            }else if (tatkalcount<TatkalSeats){
                quotaType =QuotaType.TATKAL;
                tatkalcount++;
            } else {
                quotaType = QuotaType.GENERAL;
            }
            Seat seat = new Seat(i, berthType, quotaType, BookingStatus.AVAILABLE);
            addSeats(seat);
        }
    }
    public static void AddCoach(Scanner scanner, Train train) {

        while (true) {

            System.out.println("1.AC First\n2.AC 2 Tier\n3.AC 3 Tier\n" + "4.Sleeper\n5.Executive Chair Car\n" + "6.AC Chair Car\n7.Exit");
            int ch = OnlyInteger(scanner);
            CoachType coachType;
            switch (ch) {
                case 1 -> coachType = CoachType.AC_FIRST;
                case 2 -> coachType = CoachType.AC_2TIER;
                case 3 -> coachType = CoachType.AC_3TIER;
                case 4 -> coachType = CoachType.SLEEPER;
                case 5 -> coachType = CoachType.EXECUTIVE_CHAIR_CAR;
                case 6 -> coachType = CoachType.AC_CHAIR_CAR;
                case 7 -> {
                    return;
                }
                default -> {
                    System.out.println("Invalid!");
                    continue;
                }
            }
            System.out.println("Enter number of coaches:");
            int noOfCoaches = OnlyInteger(scanner);
            System.out.println("Enter ladies reservation percentage:");
            int ladies = OnlyInteger(scanner);
            System.out.println("Enter senior citizen reservation percentage:");
            int senior = OnlyInteger(scanner);
            System.out.println("Enter physically challenged reservation percentage:");
            int physically = OnlyInteger(scanner);
            if (noOfCoaches <= 0 || ladies < 0 || senior < 0 || physically < 0 || ladies + senior + physically > 40) {
                System.out.println("Invalid values!");
                continue;
            }
            GenerateCoach(scanner, coachType, noOfCoaches, train, ladies, senior, physically
            );
        }
    }
    public static void GenerateCoach(Scanner scanner, CoachType coachType, int noOfCoaches, Train train, int ladiesReservation, int seniorReservation, int physicallyReservation) {

        String prefix = switch (coachType) {
            case AC_FIRST -> "A";
            case AC_2TIER -> "B";
            case AC_3TIER -> "C";
            case SLEEPER -> "S";
            case AC_CHAIR_CAR -> "CC";
            case EXECUTIVE_CHAIR_CAR -> "EC";
        };
        int existingCount = 0;
        for (Coach c : train.GetCoaches()) {
            if (c.getCoachType() == coachType) {
                existingCount++;
            }
        }
        for (int i = existingCount + 1; i <= existingCount + noOfCoaches; i++) {
            String coachId = prefix + i;
            int totalSeats = coachType.getTotalSeats();
            int ladies = (int) Math.ceil(ladiesReservation * totalSeats / 100.0);
            int senior = (int) Math.ceil(seniorReservation * totalSeats / 100.0);
            int physically = (int) Math.ceil(physicallyReservation * totalSeats / 100.0);
            int general = totalSeats - ladies - senior - physically;
            Coach coach = new Coach(coachId, coachType, general, ladies, senior, physically);
            coach.GenerateSeats(train, ladies, senior, physically);
            train.AddCoach(coach);
            train.addCoachtype(coachType);
        }
    }
}