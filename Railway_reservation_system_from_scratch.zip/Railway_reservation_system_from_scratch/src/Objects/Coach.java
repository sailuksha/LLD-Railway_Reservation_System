package Objects;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import static Services.InputValidators.OnlyInteger;
public class Coach {
    private String CoachId;
    private CoachType Type;
    private int GeneralSeats;
    private int ladiesSeats;
    private int seniorCitizenSeats;
    private int physicallyChallengedSeats;
    private int TatkalSeats;
    private int PremiumTatkalSeats;
    private List<Seat> Seats = new ArrayList<>();
    private List<Seat> TotalConfirmedSeats = new ArrayList<>();
    private List<Seat> TotalAvailableSeats = new ArrayList<>();

    public Coach(String coachId, CoachType type, int generalSeats, int ladiesSeats, int seniorCitizenSeats, int physicallyHandicappedSeats) {
        this.CoachId = coachId;
        this.Type = type;
        int tatkal = Math.max(2, (int) (generalSeats * 0.10));
        int premTatkal = Math.max(1, (int) (generalSeats * 0.05));
        int gen = Math.max(1, generalSeats - tatkal - premTatkal);
        this.GeneralSeats = gen;
        this.TatkalSeats = tatkal;
        this.PremiumTatkalSeats = premTatkal;
        this.ladiesSeats = ladiesSeats;
        this.seniorCitizenSeats = seniorCitizenSeats;
        this.physicallyChallengedSeats = physicallyHandicappedSeats;
    }
    public List<Seat> getTotalAvailableSeats() {
        return TotalAvailableSeats;
    }

    public List<Seat> getTotalConfirmedSeats() {
        return TotalConfirmedSeats;
    }

    public void addSeats(Seat seat) {
        this.Seats.add(seat);
    }
    public void addtoTotalConfirmedSeats(Seat seat) {
        this.TotalConfirmedSeats.add(seat);

    }
    public void addtoTotalAvailableSeats(Seat seat) {
        this.TotalAvailableSeats.add(seat);

    }
    public void removeTotalConfirmedSeats(Seat seat) {
        this.TotalConfirmedSeats.remove(seat);

    }
    public void removeTotalAvailableSeats(Seat seat) {
        this.TotalAvailableSeats.remove(seat);

    }
    public List<Seat> getSeats() {
        return Seats;
    }

    public CoachType getCoachType() {
        return this.Type;
    }

    public static void DisplayCoaches(Train train) {

        for (Coach c : train.getCoaches()) {
            System.out.println("Coach :" + c.getCoachId() + " " + c.getCoachType());
        }
    }
    public String getCoachId() {
        return CoachId;
    }

    public int getGeneralSeats() {
        return GeneralSeats;
    }

    public CoachType getType() {
        return Type;
    }

    public int getLadiesSeats() {
        return ladiesSeats;
    }

    public int getPhysicallyChallengedSeats() {
        return physicallyChallengedSeats;
    }

    public int getSeniorCitizenSeats() {
        return seniorCitizenSeats;
    }
    private static BerthType AssignBerthType(int SeatNo, CoachType coachtype) {
        if (coachtype == CoachType.AC_FIRST) {
            return (SeatNo % 2 == 1) ? BerthType.LOWER : BerthType.UPPER;
        } else if (coachtype == CoachType.AC_2TIER) {
            int rem = SeatNo % 6;
            return switch (rem) {
                case 1, 3 -> BerthType.LOWER;
                case 2, 4 -> BerthType.UPPER;
                case 5 -> BerthType.SIDE_LOWER;
                default -> BerthType.SIDE_UPPER;
            };
        } else {
            int rem = SeatNo % 8;
            return switch (rem) {
                case 1, 4 -> BerthType.LOWER;
                case 2, 5 -> BerthType.MIDDLE;
                case 3, 6 -> BerthType.UPPER;
                case 7 -> BerthType.SIDE_LOWER;
                default -> BerthType.SIDE_UPPER;
            };
        }
    }
    public static void BookAvailableSeat(Coach coach) {
        for (Seat s : coach.getSeats()) {
        }
    }
    public static void AddCoach(Scanner scanner, Train train) {
        CoachType coachType = null;
        while (true) {
            System.out.println("Enter Coach type : \n1.AC_First\n2.AC_2_tier\n3.AC_3_tier\n4.Sleeper\n5.Executive chair car\n6.Ac chair car\n7.exit");
            int ch = OnlyInteger(scanner);
            switch (ch) {
                case 1 -> {
                    coachType = CoachType.AC_FIRST;
                    break;
                }
                case 2 -> {
                    coachType = CoachType.AC_2TIER;
                    break;
                }
                case 3 -> {
                    coachType = CoachType.AC_3TIER;
                    break;
                }
                case 4 -> {
                    coachType = CoachType.SLEEPER;
                    break;
                }
                case 5 -> {
                    coachType = CoachType.EXECUTIVE_CHAIR_CAR;
                    break;
                }
                case 6 -> {
                    coachType = CoachType.AC_CHAIR_CAR;
                    break;
                }
                case 7 -> {
                    return;
                }
                default -> {
                    System.out.println("invalid!");
                    break;
                }
            }
                if (coachType != null) {
                    System.out.println("Enter total number of this type : ");
                    int no = OnlyInteger(scanner);
                    System.out.println("Enter total ladies reservation in percentage :  ");
                    int LadiesReservation = OnlyInteger(scanner);
                    System.out.println("Enter Senior Citizens seat reservation in percentage : ");
                    int Senior_citizen = OnlyInteger(scanner);
                    System.out.println("Enter Physically challenged reservation  in percentage: ");
                    int PhysicallyChallenged = OnlyInteger(scanner);
                    GenerateCoach(scanner, coachType, no, train, LadiesReservation, PhysicallyChallenged, Senior_citizen);
                }
            }
    }
    public static void EditCoach(Scanner scanner, Train train) {
        System.out.println(" EDITING COACHES IN TRAIN : " + train.getTrainNo());
        System.out.println("1.Add coach\n2.Remove coach\n3.Exit");
        int choice = OnlyInteger(scanner);
        switch (choice) {
            case 1 -> {
                AddCoach(scanner, train);
                System.out.println("Coaches added");
            }
            case 2 -> {
                for (Coach c : train.GetCoaches()) {
                    System.out.println(c.getCoachId());
                }
                System.out.println("Enter coach to remove : ");
                Coach CoachToRemove = null;
                for (Coach st : train.GetCoaches()) {
                    if (st.getCoachId().equals(CoachToRemove)) {
                        CoachToRemove = st;
                        break;

                    }
                }
                if (CoachToRemove != null) {
                    train.RemoveCoaches(CoachToRemove);
                    System.out.println("Coach removed successfully!");
                } else {
                    System.out.println("Coach not found!");
                }
            }
            case 3 -> {
                return;
            }
        }
    }
    public static void GenerateCoach(Scanner scanner,CoachType coachType, int NoOfCoaches, Train train, int LadiesReservation, int SeniorCitizenSeats, int Physically_challenged_seats) {
        String st = "";
        if (coachType.equals(CoachType.AC_FIRST)) {
            st += 'A';
        } else if (coachType.equals(CoachType.AC_2TIER)) {
            st += 'B';
        } else if (coachType.equals(CoachType.AC_3TIER)) {
            st += 'C';
        } else {
            st += 'S';
        }
        for (int i = 1; i <= NoOfCoaches; i++) {
            String temp = st;
            temp += String.valueOf(i);
            String CoachId = temp;
            int TotalNoOfSeats = coachType.getTotalSeats();
            int LadiesSeat = (int) Math.ceil((double)(LadiesReservation*TotalNoOfSeats)/100);
            int SeniorCitizenSeat = (int) Math.ceil((double)(SeniorCitizenSeats*TotalNoOfSeats)/100);
            int PhysicallyChallengedSeats = (int) Math.ceil((double)(Physically_challenged_seats*TotalNoOfSeats)/100);
            int GeneralSeats = TotalNoOfSeats - (LadiesSeat + PhysicallyChallengedSeats + SeniorCitizenSeat);
            Coach coach = new Coach(CoachId, coachType, GeneralSeats, LadiesSeat, SeniorCitizenSeat, PhysicallyChallengedSeats);
            GenerateSeats(coach, train, LadiesSeat,  PhysicallyChallengedSeats,SeniorCitizenSeat);
            train.AddCoach(coach);
        }
    }
    public static void GenerateSeats(Coach coach, Train train, int LadiesSeat, int SeniorCitizenSeat, int PhysicallychallengedSeats) {
        CoachType coachType = coach.getType();
        int Totalnoofseats = coachType.getTotalSeats();
        int LadiesSeatCount=0;
        int PhysicallyChallengedCount=0;
        int SeniorCitizencount=0;

        for (int i = 1; i <= Totalnoofseats; i++) {
            BerthType berthType=AssignBerthType(i,coachType);
            QuotaType quotaType;
            if (LadiesSeatCount<LadiesSeat){
                quotaType=QuotaType.LADIES;
                LadiesSeatCount++;

            }
            else if(PhysicallyChallengedCount<PhysicallychallengedSeats && berthType==BerthType.LOWER){
                quotaType=QuotaType.PHYSICALLY_CHALLENGED;
                PhysicallyChallengedCount++;

            }
            else if (SeniorCitizencount<SeniorCitizenSeat && berthType==BerthType.LOWER){
                quotaType=QuotaType.SENIOR_CITIZEN;
                SeniorCitizencount++;

            }else{
                quotaType=QuotaType.GENERAL;
            }
            Seat seat=new Seat(i,berthType,quotaType,BookingStatus.AVAILABLE);
            coach.addSeats(seat);
            coach.addtoTotalAvailableSeats(seat);
        }DisplaySeatInfo(coach);
    }
    public static void DisplaySeatInfo(Coach coach){
        for (Seat s : coach.getSeats()){
            System.out.println("Seat no : "+s.getSeatNo()+" Berth type : "+s.getBerthtype()+" quota : "+s.getAssignedquota());
        }
    }
}