package Objects;
import Enums.CoachType;
import Enums.QuotaType;
import Services.BookingService;
import Services.Passenger;
import java.util.*;
import static Objects.Storage.TrainInventory;
public class Train {
    private int TrainNo;
    private String Source;
    private String destination;
    private double BaseFare;
    private List<String> Route;
    private List<Coach> coaches = new ArrayList<>();
    private List<BookingService> TrainBookings = new ArrayList<>();
    private Set<CoachType> TypeAvailable = new LinkedHashSet<>();
    private List<Passenger> passengerList = new ArrayList<>();
    public Train(int TrainNo, String source, String destination, String Route, double BaseFare) {
        this.TrainNo = TrainNo;
        this.Source = source;
        this.destination = destination;
        this.BaseFare = BaseFare;
        this.Route = new ArrayList<>();
        for (String st : Route.split(",")) {this.Route.add(st.trim());}
    }
    public List<Passenger> getPassengerList() {
        return passengerList;
    }
    public void addPassengerList(List<Passenger> passengers) {
        passengerList.addAll(passengers);
    }
    public void AddCoach(Coach coach) {
        if (coach != null) {
            coaches.add(coach);
            TypeAvailable.add(coach.getCoachType());
        }
    }
    public List<Coach> GetCoaches() {
        return coaches;
    }
    public void RemoveCoaches(Coach coach) {
        coaches.remove(coach);
        boolean typeStillExists = coaches.stream().anyMatch(c -> c.getCoachType() == coach.getCoachType());
        if (!typeStillExists) {
            TypeAvailable.remove(coach.getCoachType());
        }
    }
    public void addCoachtype(CoachType coachType) {
        TypeAvailable.add(coachType);
    }

    public Coach HoldSeatInCoach(Train train, Scanner scanner, QuotaType quotaType) {
        while (true) {
            System.out.println("Enter preferred coach:");
            System.out.println("1AC / 2AC / 3AC / SL / EC / CC");
            String choice = scanner.next().trim().toUpperCase();
            CoachType selectedType = switch (choice) {
                case "1AC" -> selectedType = CoachType.AC_FIRST;
                case "2AC" -> selectedType = CoachType.AC_2TIER;
                case "3AC" -> selectedType = CoachType.AC_3TIER;
                case "SL" -> selectedType = CoachType.SLEEPER;
                case "EC" -> selectedType = CoachType.EXECUTIVE_CHAIR_CAR;
                case "CC" -> selectedType = CoachType.AC_CHAIR_CAR;
                default -> null;
            };
            if (selectedType == null) {
                System.out.println("Invalid coach type");
            }
            List<Coach> matchingcoaches = new ArrayList<>();
            for (Coach c : train.GetCoaches()) {
                if (c.getCoachType() == selectedType) {
                    matchingcoaches.add(c);
                }
            }
            if (matchingcoaches.isEmpty()) {
                System.out.println("Train : " + train.getTrainNo() + "does not have choice coaches" + choice + "coaches.");
                continue;
            }
            int totalquotaseats = 0;
            int totalracavailable = 0;
            int totalwaitlistavailable = 0;
            for (Coach c : matchingcoaches) {
                int countquotaseats = (int)c.getSeatInventory().getAvailableSeats().stream().filter(seat -> seat.getAssignedquota() == quotaType).count();
                totalquotaseats += countquotaseats;
                totalracavailable += (c.getSeatInventory().RacCapacity() ? 1 : 0);
                totalwaitlistavailable += (c.getSeatInventory().WaitingListCapacity() ? 1 : 0);
            }
            System.out.println("AVAILABILITY FOR : " + choice + " Quotatype :" + quotaType);
            if (totalquotaseats > 0) {
                System.out.println("AVAILABLE : " + totalquotaseats);
            } else if (totalracavailable > 0) {
                System.out.println("RAC available ");
            } else if (totalwaitlistavailable > 0) {
                System.out.println("WAITLIST available");
            } else {
                System.out.println("REGRET");
                return null;
            }
            return matchingcoaches.get(0);
        }
    }
    public void setTrainBookings(BookingService trainBooking) {
        TrainBookings.add(trainBooking);
    }
    public void SetBaseFare(double baseFare) {
        this.BaseFare = baseFare;
    }
    public int getTrainNo() {
        return TrainNo;
    }
    public void setTrainNo(int trainNo) {
        TrainNo = trainNo;
    }
    public String getSource() {
        return Source;
    }
    public void setSource(String source) {
        Source = source;
    }
    public String getDestination() {
        return destination;
    }
    public void setDestination(String destination) {
        this.destination = destination;
    }
    public double getBaseFare() {
        return BaseFare;
    }
    public List<String> getRouteStations() {
        return Route;
    }
    public static void DisplayTrainInventory(List<Train> TrainInventory) {
        System.out.println(" TRAIN INVENTORY : ");
        for (Train t : TrainInventory) {
            System.out.println("\nTrain : " + t.getTrainNo() + " | " + t.getSource() + " to " + t.getDestination() + " | base fare : rs. " + t.getBaseFare());
            System.out.printf("%-15s | %-25s | %-15s%n", "COACH ID", "COACH TYPE", "AVAILABLE SEATS");
            for (Coach c : t.GetCoaches()) {
                System.out.printf("%-15s | %-25s | %-15s%n", c.getCoachId(), c.getCoachType(), c.getSeatInventory().getAvailableSeats().size());
            }
        }
    }
    public static boolean ValidateTrain(int Trainno) {
        for (Train t : TrainInventory) {
            if (t.getTrainNo() == Trainno) {
                return false;
            }
        }
        return true;
    }
    public static void DisplayTrainInfo(int TrainNo) {
        for (Train t : TrainInventory) {
            if (t.getTrainNo() == TrainNo) {
                System.out.println("\nTrain : " + t.getTrainNo() + " | " + t.getSource() + " to " + t.getDestination() + " | base fare : rs. " + t.getBaseFare());
                return;
            }
        }
    }
    public static Train FindTrain(int TrainNo) {
        for (Train t : TrainInventory) {
            if (t.getTrainNo() == TrainNo) {
                return t;
            }
        }
        return null;
    }
}