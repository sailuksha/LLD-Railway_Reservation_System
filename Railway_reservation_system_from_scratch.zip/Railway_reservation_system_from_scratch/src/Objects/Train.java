package Objects;
import Enums.CoachType;
import Enums.QuotaType;
import Services.BookingService;
import Services.Passenger;
import java.util.*;
import static Objects.Storage.TrainInventory;
public class Train {
    private int TrainNo;
    private String Source;
    private String destination;
    private double BaseFare;
    private List<String> Route;
    private List<Coach> coaches = new ArrayList<>();
    private List<BookingService> TrainBookings = new ArrayList<>();
    private Set<CoachType> TypeAvailable = new LinkedHashSet<>();
    private List<Passenger> passengerList = new ArrayList<>();
    private List<Passenger> Waitlist = new ArrayList<>();
    private List<Seat> AvailableSeats1AC = new ArrayList<>();
    private List<Seat> AvailableSeats2AC = new ArrayList<>();
    private List<Seat> AvailableSeats3AC = new ArrayList<>();
    private List<Seat> AvailableSeatSL = new ArrayList<>();
    private List<Seat> AvailableSeatEC = new ArrayList<>();
    private List<Seat> AvailableSeatCC = new ArrayList<>();

    public Train(int TrainNo, String source, String destination, String Route, double BaseFare) {
        this.TrainNo = TrainNo;
        this.Source = source;
        this.destination = destination;
        this.BaseFare = BaseFare;
        this.Route = new ArrayList<>();
        for (String st : Route.split(",")) {this.Route.add(st.trim());}
    }
    public List<Passenger> getPassengerList() {
        return passengerList;
    }

    public void addPassengerList(List<Passenger> passengers) {
        passengerList.addAll(passengers);
    }

    public void removePassenger(Passenger passenger) {
        passengerList.remove(passenger);
    }

    public void AddCoach(Coach coach) {
        if (coach != null) {
            coaches.add(coach);
            TypeAvailable.add(coach.getCoachType());
        }
    }

    public List<Coach> GetCoaches() {
        return coaches;
    }

    public void RemoveCoaches(Coach coach) {
        coaches.remove(coach);

        boolean typeStillExists = coaches.stream().anyMatch(c -> c.getCoachType() == coach.getCoachType());

        if (!typeStillExists) {
            TypeAvailable.remove(coach.getCoachType());
        }
    }

    public void addCoachtype(CoachType coachType) {
        TypeAvailable.add(coachType);
    }

    public Set<CoachType> getTypeAvailable() {
        return TypeAvailable;
    }

    public Coach HoldSeatInCoach(Train train, Scanner scanner, QuotaType quotaType) {
        while (true) {
            System.out.println("Enter preferred coach:");
            System.out.println("1AC / 2AC / 3AC / SL / EC / CC");
            String choice = scanner.next().trim().toUpperCase();
            CoachType selectedType;
            switch (choice) {
                case "1AC" -> selectedType = CoachType.AC_FIRST;
                case "2AC" -> selectedType = CoachType.AC_2TIER;
                case "3AC" -> selectedType = CoachType.AC_3TIER;
                case "SL" -> selectedType = CoachType.SLEEPER;
                case "EC" -> selectedType = CoachType.EXECUTIVE_CHAIR_CAR;
                case "CC" -> selectedType = CoachType.AC_CHAIR_CAR;
                default -> {
                    System.out.println("Invalid coach type!");
                    continue;
                }
            }
            for (Coach c : train.GetCoaches()) {
                if (c.getCoachType() == selectedType) {
                    long available = c.getSeatInventory().getAvailableSeats().stream().filter(seat -> seat.getAssignedquota() == quotaType).count();
                    if (available > 0) {
                        System.out.println("Available seats in " + c.getCoachId() + ": " + available);
                        return c;
                    }
                }
            }
            System.out.println("No confirmed seats available in this coach.");
            System.out.println("Checking WL availability...");
            return train.GetCoaches().stream().filter(c -> c.getCoachType() == selectedType).findFirst().orElse(null);
        }
    }
    // for 1ac

    public List<Seat> getAvailableSeats1AC() {
        return AvailableSeats1AC;
    }

    public void setAvailableSeats1AC(List<Seat> seats) {
        AvailableSeats1AC.addAll(seats);
    }

    public void removeAvailableSeats1AC(Seat seat) {
        AvailableSeats1AC.remove(seat);
    }

    // for 2ac

    public List<Seat> getAvailableSeats2AC() {
        return AvailableSeats2AC;
    }

    public void setAvailableSeats2AC(List<Seat> seats) {
        AvailableSeats2AC.addAll(seats);
    }

    public void removeAvailableSeats2AC(Seat seat) {
        AvailableSeats2AC.remove(seat);
    }

    // for 3ac

    public List<Seat> getAvailableSeats3AC() {
        return AvailableSeats3AC;
    }

    public void setAvailableSeats3AC(List<Seat> seats) {
        AvailableSeats3AC.addAll(seats);
    }

    public void removeAvailableSeats3AC(Seat seat) {
        AvailableSeats3AC.remove(seat);
    }

    // for sl

    public List<Seat> getAvailableSeatSL() {
        return AvailableSeatSL;
    }

    public void setAvailableSeatSL(List<Seat> seats) {
        AvailableSeatSL.addAll(seats);
    }

    public void removeAvailableSeatSL(Seat seat) {
        AvailableSeatSL.remove(seat);
    }

    // for ec

    public List<Seat> getAvailableSeatEC() {
        return AvailableSeatEC;
    }

    public void setAvailableSeatEC(List<Seat> seats) {
        AvailableSeatEC.addAll(seats);
    }

    public void removeAvailableSeatEC(Seat seat) {
        AvailableSeatEC.remove(seat);
    }

    // for cc

    public List<Seat> getAvailableSeatCC() {
        return AvailableSeatCC;
    }

    public void setAvailableSeatCC(List<Seat> seats) {
        AvailableSeatCC.addAll(seats);
    }

    public void removeAvailableSeatCC(Seat seat) {
        AvailableSeatCC.remove(seat);
    }


    public void setTrainBookings(BookingService trainBooking) {
        TrainBookings.add(trainBooking);
    }

//    public List<BookingService> getTrainBookings() {
//        return TrainBookings;
//    }
//
//    public void removeTrainBooking(BookingService booking) {
//        TrainBookings.remove(booking);
//    }

    public void SetBaseFare(double baseFare) {
        this.BaseFare = baseFare;
    }

    public int getTrainNo() {
        return TrainNo;
    }

    public void setTrainNo(int trainNo) {
        TrainNo = trainNo;
    }

    public String getSource() {
        return Source;
    }

    public void setSource(String source) {
        Source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public double getBaseFare() {
        return BaseFare;
    }

    public List<String> getRouteStations() {
        return Route;
    }

    public static void DisplayTrainInventory(List<Train> TrainInventory) {

        System.out.println(" TRAIN INVENTORY : ");

        for (Train t : TrainInventory) {

            System.out.println("\nTrain : " + t.getTrainNo() + " | " + t.getSource() + " to " + t.getDestination() + " | base fare : rs. " + t.getBaseFare());

            System.out.printf("%-15s | %-25s | %-15s%n", "COACH ID", "COACH TYPE", "AVAILABLE SEATS");

            for (Coach c : t.GetCoaches()) {
                System.out.printf("%-15s | %-25s | %-15s%n", c.getCoachId(), c.getCoachType(), c.getSeatInventory().getAvailableSeats().size());
            }
        }
    }
    public static boolean ValidateTrain(int Trainno) {
        for (Train t : TrainInventory) {
            if (t.getTrainNo() == Trainno) {
                return false;
            }
        }
        return true;
    }
    public static void DisplayTrainInfo(int TrainNo) {
        for (Train t : TrainInventory) {
            if (t.getTrainNo() == TrainNo) {
                System.out.println("\nTrain : " + t.getTrainNo() + " | " + t.getSource() + " to " + t.getDestination() + " | base fare : rs. " + t.getBaseFare());
                return;
            }
        }
    }
    public static Train FindTrain(int TrainNo) {
        for (Train t : TrainInventory) {
            if (t.getTrainNo() == TrainNo) {
                return t;
            }
        }
        return null;
    }
}
