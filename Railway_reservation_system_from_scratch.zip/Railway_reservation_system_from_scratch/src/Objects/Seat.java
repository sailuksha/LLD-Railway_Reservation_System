package Objects;
import Enums.BerthType;
import Enums.BookingStatus;
import Enums.QuotaType;

public class Seat {

    private int SeatNo;
    private BerthType berthtype;
    private QuotaType assignedquota;
    private BookingStatus bookingstatus;

    public Seat(int seatno, BerthType berthType, QuotaType quotaType, BookingStatus bookingStatus) {

        this.SeatNo = seatno;
        this.berthtype = berthType;
        this.assignedquota = quotaType;
        this.bookingstatus = bookingStatus;
    }

    public int getSeatNo() {
        return SeatNo;
    }

    public BerthType getBerthtype() {
        return berthtype;
    }

    public QuotaType getAssignedquota() {
        return assignedquota;
    }

    public BookingStatus getBookingstatus() {
        return bookingstatus;
    }

    public void setBookingstatus(BookingStatus bookingstatus) {
        this.bookingstatus = bookingstatus;
    }
}
