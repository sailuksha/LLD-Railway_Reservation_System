//package Services;
//import Actors.InventoryManager;
//import Actors.Staff;
//import Actors.SuperAdmin;
//import Actors.TTE;
//import PortalRunners.InventoryManagerPortal;
//import PortalRunners.SuperAdminPortal;
//import PortalRunners.TTEPortal;
//import java.util.Scanner;
//import static Actors.Staff.GenerateStaffId;
//import static Objects.Storage.StaffDatabase;
//import static Services.InputValidators.*;
//import static Services.InputValidators.ReadValidPassword;
//
//public class RegisterAndLogin {
//
//    public static void RegisterStaff(Scanner scanner) {
//        System.out.println("REGISTERING NEW STAFF");
//        System.out.println("1. Inventory Manager \n2. TTE");
//        int Role = OnlyInteger(scanner);
//        if (Role != 1 && Role != 2) {
//            System.out.println("Invalid choice");
//        } else if (Role == 1) {
//            System.out.println("Enter Staff name : ");
//            String name = scanner.nextLine().trim();
//            String phone = "";
//            while (true) {
//                boolean phoneexist = false;
//                String Phone = ReadValidPhoneNumber(scanner, "Enter phone no : ");
//                for (Staff s : StaffDatabase) {
//                    if (s.getPhoneNo().equals(Phone)) {
//                        phoneexist = true;
//                        break;
//                    }
//                }
//                if (phoneexist) {
//                    System.out.println("Phone number already exists");
//                } else {
//                    phone = Phone;
//                    break;
//                }
//            }
//                String email = ReadValidEmail(scanner, "Enter staff email : ");
//                String pass = ReadValidPassword(scanner, "Setup password : ");
//                Staff newstaff = new InventoryManager(name, phone, email, pass);
//                StaffDatabase.add(newstaff);
//                String staffid = GenerateStaffId(newstaff);
//                newstaff.setStaffId(staffid);
//                System.out.println("Inventory manager " + name + " added successfully.");
//
//        } else if (Role == 2) {
//            System.out.println("Enter Staff name : ");
//            String name = scanner.nextLine().trim();
//            String phone = "";
//            while (true) {
//                boolean phoneexist = false;
//                String Phone = ReadValidPhoneNumber(scanner, "Enter phone no : ");
//
//                for (Staff s : StaffDatabase) {
//                    if (s.getPhoneNo().equals(Phone)) {
//                        phoneexist = true;
//                        break;
//                    }
//                }
//                if (phoneexist) {
//                    System.out.println("Phone number already exists");
//                } else {
//                    phone = Phone;
//                    break;
//                }
//            }
//            String email = ReadValidEmail(scanner, "Enter staff email : ");
//                String pass = ReadValidPassword(scanner, "Setup password : ");
//                System.out.println("Enter assigned train no : ");
//                int AssignedTrain = OnlyInteger(scanner);
//                Staff newstaff = new TTE(name, phone, email, pass, AssignedTrain);
//                StaffDatabase.add(newstaff);
//                String staffid = GenerateStaffId(newstaff);
//                newstaff.setStaffId(staffid);
//                System.out.println("TTE " + name + " registered successfully.");
//        }
//    }
//    public static void LoginStaff(Scanner scanner, String UserName) {
//        Staff CurrentUser = null;
//        for (Staff s : StaffDatabase) {
//            boolean match;
//            match = ((s.getEmail().equals(UserName)) || s.getStaffId().equals(UserName) || s.getPhoneNo().equals(UserName));
//            if (match) {
//                CurrentUser = s;
//                break;
//            }
//        }
//        if (CurrentUser == null) {
//            System.out.println("Staff does not exist!");
//            return;
//        }
//        System.out.println("Enter your password : ");
//        String pass = scanner.nextLine().trim();
//        if (CurrentUser.ValidatePass(pass, CurrentUser)) {
//            System.out.println("Welcome, " + CurrentUser.getName() + " - " + CurrentUser.getRole());
//            if (CurrentUser instanceof SuperAdmin) {
//                SuperAdminPortal.Menu(scanner, CurrentUser);
//            } else if (CurrentUser instanceof InventoryManager) {
//                InventoryManagerPortal.Menu(scanner, CurrentUser);
//            } else if (CurrentUser instanceof TTE) {
//                TTE tte=(TTE) CurrentUser;
//                TTEPortal.Menu(scanner,tte);
//            }
//        } else {
//            System.out.println("Invalid login credentials.");
//        }
//    }
//}