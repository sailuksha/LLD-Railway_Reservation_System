package Services;
import Actors.Staff;
import java.security.SecureRandom;
import java.util.Scanner;
import static Services.InputValidators.ReadValidPassword;

public class OTPService {

    private static final SecureRandom random = new SecureRandom();
    private static final int MaxAttempts = 3;
    private static final long OtpValidityTime = 300000;
    private static boolean verifyOTP(Scanner scanner, String ReceivingPerson, String OTPPurpose) {

        String generatedOtp = String.valueOf(random.nextInt(99999)+100000);
        long expiryTime = System.currentTimeMillis() + OtpValidityTime;
        System.out.println(OTPPurpose + " sent to " + ReceivingPerson + ": " + generatedOtp);
        for (int attempts = 1; attempts <= MaxAttempts; attempts++) {
            System.out.print("Enter " + OTPPurpose + " OTP: ");
            String input = scanner.nextLine().trim();
            if (System.currentTimeMillis() >= expiryTime) {
                System.out.println("OTP has expired.");
                return false;
            }
            if (input.equals(generatedOtp)) {
                System.out.println("Verification Successful!");
                return true;
            }
            System.out.println("Invalid OTP. " + (MaxAttempts - attempts) + " attempts remaining.");
        }
        System.out.println("Too many failed attempts.");
        return false;
    }
    public static boolean VerifyPhone(Scanner scanner, String phone) {
        return verifyOTP(scanner, phone, "Verifying Phone no");
    }
    public static boolean VerifyEmail(Scanner scanner, String email) {
        return verifyOTP(scanner, email, "Veryfying email");
    }
//    public boolean TwoFactorAunthentication(Scanner scanner, String email) {
//        return verifyOTP(scanner, email, "Two-factor-authentication");
//    }
    public static boolean ResetPassword(Scanner scanner, String recovery, Staff staff) {
        boolean verified = verifyOTP(scanner, recovery, "Resetting password");
        if (!verified) {
            return false;
        }
        String newpass = ReadValidPassword(scanner, "Enter new password: ");
        staff.setPassword(newpass);
        System.out.println("Password reset successfully.");
        return true;
    }
}