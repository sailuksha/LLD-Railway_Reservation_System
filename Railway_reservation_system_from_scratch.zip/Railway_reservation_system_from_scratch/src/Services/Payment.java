package Services;
import Enums.CoachType;
import java.util.Scanner;
import java.util.UUID;
import static Services.InputValidators.OnlyInteger;

public class Payment {
    private String PaymentID;
    private double amount;
    static Scanner scanner = new Scanner(System.in);
    public Payment(String paymentID, double amount) {
        this.PaymentID = paymentID;
        this.amount = amount;
    }
    public static boolean ProcessPayment(double amt) {
        String paymentid = UUID.randomUUID().toString();
        System.out.println("1.Proceed payment\n2.Cancel payment");
        while (true) {
            int ch = OnlyInteger(scanner);
            if (ch == 1) {
                System.out.println("Payment successful, payment id :"+paymentid);
                return true;

            } else if (ch == 2) {
                System.out.println("Payment cancelled");
                return false;

            } else {
                System.out.println("Invalid option");
            }
        }
    }
    public static void Refund(Passenger passenger, double fare) {
        double cancellationfee = 0.0;
        double refundamt = 0.0;
            switch (passenger.getCoachType()) {
                case CoachType.AC_FIRST-> {
                    cancellationfee = 240.0;
                    break;}
                case CoachType.AC_2TIER->{cancellationfee = 200.0
                    ;
                    break;}
                case CoachType.AC_3TIER-> {
                    cancellationfee = 180.0
                    ;
                    break;}
                case CoachType.SLEEPER -> {
                    cancellationfee=120;
                    break;
                }
                case CoachType.EXECUTIVE_CHAIR_CAR -> {
                    cancellationfee=250;
                    break;
                }
                case CoachType.AC_CHAIR_CAR -> {
                    cancellationfee=150;
                    break;
                }
            }
            refundamt=fare-cancellationfee;
            System.out.printf("TICKET CANCELLED : \n cancellation fee : %2f\n Original fare paid : %2f\n refund amt : %2f",cancellationfee,fare,refundamt);
        }
}