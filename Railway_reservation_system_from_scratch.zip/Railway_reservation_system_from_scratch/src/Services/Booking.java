package Services;
import Actors.User;
import Objects.BookingStatus;
import Objects.Coach;
import Objects.Seat;
import Objects.Train;
import java.util.ArrayList;
import java.util.Random;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import static Objects.Coach.DisplayCoaches;
import static Objects.Coach.DisplaySeatInfo;
import static Objects.Storage.ActiveBookings;
import static Objects.Storage.TrainInventory;
import static Objects.Train.DisplayTrainInfo;
import static Objects.Train.FindTrain;
import static Services.InputValidators.OnlyInteger;

public class Booking {

    private String pnrNo;
    private User user;
    private String source;
    private String destination;
    private double totalFare;
    private LocalDate bookingDate;
    private BookingStatus status;
    private TTECheckStatus TTECheck;
    private Coach coach;
    private Seat seat;

    public Booking(String pnrNo, User user, String source,String destination, double totalFare, BookingStatus status) {
        this.pnrNo = pnrNo;
        this.user=user;
        this.source=source;
        this.destination=destination;
        this.totalFare = totalFare;
        this.bookingDate = LocalDate.now();
        this.status = status;
        this.TTECheck = TTECheckStatus.YET_TO_VERIFY;

    }
    public String getpnrno() {
        return pnrNo;
    }

    public User getUser() {
        return user;
    }
    public TTECheckStatus getTTECheck() {
        return TTECheck;
    }
    public static void BookingsReport(int trainno) {
        Train TrainPreparingChart = null;
        for (Train t : TrainInventory) {
            if (t.getTrainNo() == trainno) {
                TrainPreparingChart = t;
                break;
            }
        }
        System.out.printf("TRAIN CHART  FOR TRAIN : %d : \n" , trainno);
        System.out.printf("%-20s | %-20s | %-20s %n " , "COACHID", "CONFIRMED SEATS", "AVAILABLE SEATS");
        for (Coach c : TrainPreparingChart.getCoaches()) {
            System.out.printf("%-20s | %-20d | %-20d %n" ,c.getCoachId(),c.getTotalConfirmedSeats().size(),c.getTotalAvailableSeats().size());


        }

    }
    public void setTTECheck(TTECheckStatus TTECheck) {
        this.TTECheck = TTECheck;
    }
    public BookingStatus getStatus() {
        return status;
    }

    public void setStatus(BookingStatus status) {
        this.status = status;
    }

    public static void BookTicket(Scanner scanner, User user){
        System.out.println("Enter source");
        String source =scanner.nextLine().trim();
        System.out.println("Enter Destination");
        String destination=scanner.nextLine().trim();
        List<Train> AvailableTrains=new ArrayList<>();

        for (Train t : TrainInventory){
            List<String> route=t.getRouteStations();
            boolean CrossSource=route.contains(source);
            boolean CrossDestination=route.contains(destination);
            if (CrossSource && CrossDestination){
                int si=route.indexOf(source);
                int sd=route.indexOf(destination);
                if(si<sd){
                    AvailableTrains.add(t);
                    DisplayTrainInfo(t.getTrainNo());

                }
            }
        }
        if (AvailableTrains.isEmpty()){
            System.out.println("No trains available.");
        }
        else{
            System.out.println("Enter train no : ");
            int choice=OnlyInteger(scanner);
            Train Traintobetravelled=FindTrain(choice);
            DisplayCoaches(Traintobetravelled);
            System.out.println("Enter Coach : \n");
            String CoachSelected=scanner.nextLine().trim();
            Coach Coachselected=null;
            for (Coach c : Traintobetravelled.getCoaches()){
                if (CoachSelected.equals(c.getCoachId())){
                    List<Seat> AvailableSeats =c.getSeats();
                    Coachselected=c;
                }
            }
            DisplaySeatInfo(Coachselected);
            System.out.println();
            System.out.println("Select seat : ");
            int SelectedSeat=OnlyInteger(scanner);
            Seat Selectedseat=null;
            for (Seat s: Coachselected.getSeats()){
                if (s.getSeatNo()==SelectedSeat){
                    Selectedseat=s;
                }
            }
            String pnr =GeneratePNR();
            Coachselected.addtoTotalConfirmedSeats(Selectedseat);
            Coachselected.removeTotalAvailableSeats(Selectedseat);
            Double Fare=Traintobetravelled.getBaseFare();
            Booking booking=new Booking(pnr,user,source,destination,Fare,BookingStatus.CONFIRMED);
            user.addToMyBookings(booking);
            ActiveBookings.add(booking);
            Traintobetravelled.setTrainBookings(booking);
            System.out.println("Ticket booked \n your pnr : "+pnr);
        }
    }
    public static String GeneratePNR(){
        Random random = new Random();
        String pnrNo = String.valueOf((long)random.nextLong(999999999L) + 1000000000L);
        return pnrNo;
    }
}

