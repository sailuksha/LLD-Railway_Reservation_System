package Services;
import Enums.*;
import Objects.*;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import static Services.InputValidators.OnlyInteger;
public class Passenger {

    private String pnr;
    private int Seatno;
    //    private String source;
//    private String destination;
//    private int Trainno;
    private CoachType coachType;
    private String coachid;
    private String PassengerName;
    private LocalDate dob;
    private Gender gender;
    private QuotaType quotaType;
    private BerthType Berthpreferred;
    private BookingStatus bookingStatus;
    private TTECheckStatus tteCheckStatus;
    private int WaitListNo;

    public Passenger(String pnr, String PassengerName, LocalDate dob, Gender gender, QuotaType quotaType, BerthType berthpreferred, BookingStatus bookingStatus, TTECheckStatus tteCheckStatus) {
        this.pnr = pnr;
        this.PassengerName = PassengerName;
        this.dob = dob;
        this.gender = gender;
        this.quotaType = quotaType;
        this.Berthpreferred = berthpreferred;
        this.bookingStatus = bookingStatus;
        this.tteCheckStatus = tteCheckStatus;
    }

    public String getCoachid() {
        return coachid;
    }

    public void setCoachid(String coachid) {
        this.coachid = coachid;
    }

    public int getWaitListNo() {
        return WaitListNo;
    }

    public void setWaitListNo(int waitListNo) {
        WaitListNo = waitListNo;
    }

    public BerthType getBerthpreferred() {
        return Berthpreferred;
    }

    public int getSeatno() {
        return Seatno;
    }

    public void setSeatno(int seatno) {
        Seatno = seatno;
    }

    public String getPnr() {
        return pnr;
    }

    public String getPassengerName() {
        return PassengerName;
    }

    public String getName() {
        return PassengerName;
    }

    public LocalDate getDob() {
        return dob;
    }

    public int getage(LocalDate dob) {
        return Period.between(dob, LocalDate.now()).getYears();
    }

    public QuotaType getQuotaType() {
        return quotaType;
    }

    public BookingStatus getBookingStatus() {
        return bookingStatus;
    }

    public void setBookingStatus(BookingStatus bookingStatus) {
        this.bookingStatus = bookingStatus;
    }

    public TTECheckStatus getTteCheckStatus() {
        return tteCheckStatus;
    }

    public Gender getGender() {
        return gender;
    }

    public CoachType getCoachType() {
        return coachType;
    }

    public void setCoachType(CoachType coachType) {
        this.coachType = coachType;
    }

    public static void UpgradeRAC(Scanner scanner, Train train) {
        if (train == null) {
            System.out.println("Train not found!");
            return;
        }
        List<Passenger> racPassengers = new ArrayList<>();
        System.out.println(" RAC PASSENGERS :");
        int index = 1;
        for (Coach coach : train.GetCoaches()) {
            for (Passenger p : coach.getSeatInventory().getRacList()) {
                racPassengers.add(p);
                System.out.printf("%d. %s | PNR: %s | Coach: %s | RAC%n", index++, p.getPassengerName(), p.getPnr(), coach.getCoachId());
            }
        }
        if (racPassengers.isEmpty()) {
            System.out.println("No RAC passengers available!");
            return;
        }

        System.out.println("Enter passenger number to upgrade:");
        int choice = OnlyInteger(scanner);
        if (choice <= 0 || choice > racPassengers.size()) {
            System.out.println("Invalid selection!");
            return;
        }
        Passenger selectedPassenger = racPassengers.get(choice - 1);
        Coach selectedCoach = null;
        for (Coach coach : train.GetCoaches()) {
            if (coach.getCoachId().equalsIgnoreCase(selectedPassenger.getCoachid())) {
                selectedCoach = coach;
                break;
            }
        }
        if (selectedCoach == null) {
            System.out.println("Coach not found!");
            return;
        }
        SeatInventory inventory = selectedCoach.getSeatInventory();
        Seat availableSeat = null;
        for (Seat seat : inventory.getAvailableSeats()) {
            if (seat.getBookingstatus() == BookingStatus.AVAILABLE && seat.getAssignedquota() == selectedPassenger.getQuotaType() && seat.getBerthtype() == selectedPassenger.getBerthpreferred()) {
                availableSeat = seat;
                break;
            }
        }
        if (availableSeat == null) {
            System.out.println("No suitable confirmed seat available!");
            return;
        }
        inventory.getRacList().remove(selectedPassenger);
        availableSeat.setBookingstatus(BookingStatus.CONFIRMED);
        selectedPassenger.setSeatno(availableSeat.getSeatNo());
        selectedPassenger.setBookingStatus(BookingStatus.CONFIRMED);
        selectedPassenger.setWaitListNo(0);
        inventory.removeAvailableSeat(availableSeat);
        selectedCoach.addtoTotalConfirmedSeats(availableSeat);
        System.out.println("\nRAC UPGRADE SUCCESSFUL!");
        System.out.println("Passenger: " + selectedPassenger.getPassengerName());
        System.out.println("Coach: " + selectedCoach.getCoachId());
        System.out.println("Seat Number: " + availableSeat.getSeatNo());
        System.out.println("Status: CONFIRMED");
    }


    public static void AssignSeats(Train train, List<Passenger> passengers) {
        for (Passenger p : passengers) {
            boolean allocated = false;
            for (Coach c : train.GetCoaches()) {
                if (c.getCoachType() == p.getCoachType()) {
                    SeatInventory inventory = c.getSeatInventory();
                    for (Seat s : inventory.getAvailableSeats()) {
                        if (s.getBookingstatus() == BookingStatus.AVAILABLE && s.getBerthtype() == p.getBerthpreferred() && s.getAssignedquota() == p.getQuotaType()) {
                            inventory.removeAvailableSeat(s);
                            s.setBookingstatus(BookingStatus.CONFIRMED);
                            p.setSeatno(s.getSeatNo());
                            p.setCoachid(c.getCoachId());
                            p.setCoachType(c.getCoachType());
                            p.setBookingStatus(BookingStatus.CONFIRMED);
                            p.setWaitListNo(0);
                            c.addtoTotalConfirmedSeats(s);
                            allocated = true;
                            break;
                        }
                    }
                    if (allocated) {
                        break;
                    }
                }
                if (!allocated) {
                    for (Coach c1 : train.GetCoaches()) {
                        if (c1.getCoachType() == p.getCoachType()) {
                            SeatInventory inventory = c1.getSeatInventory();
                            if (inventory.addRacPassenger(p)) {
                                p.setCoachid(c.getCoachId());
                                p.setCoachType(c.getCoachType());
                                p.setSeatno(0);
                                allocated = true;
                                break;
                            }
                        }
                    }
                }
                for (Coach c2 : train.GetCoaches()) {
                    if (c2.getCoachType() == p.getCoachType()) {
                        SeatInventory inventory = c2.getSeatInventory();
                        if (inventory.addWaitingPassenger(p)) {
                            p.setCoachid(c2.getCoachId());
                            p.setCoachType(c2.getCoachType());
                            p.setSeatno(0);
                            allocated = true;
                            break;
                        }
                    }
                    if (!allocated) {
                        p.setBookingStatus(BookingStatus.CANCELLED);
                        System.out.println(p.getPassengerName() + " reservation capacity full."
                        );
                    }
                }
            }
        }
    }
}