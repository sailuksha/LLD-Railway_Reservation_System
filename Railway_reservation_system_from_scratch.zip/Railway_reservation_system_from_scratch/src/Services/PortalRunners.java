//package Services;
//import Enums.Gender;
//import Actors.Staff;
//import Actors.TTE;
//import Actors.User;
//import Enums.BookingStatus;
//import Objects.Train;
//import java.util.Date;
//import java.util.Scanner;
//import static Actors.TTE.VerifyTickets;
//import static Actors.TTE.displayTTETab;
//import static Objects.Inventory.EditInventory;
//import static Objects.Storage.*;
//import static Objects.Train.DisplayTrainInventory;
//import static Services.Booking.BookingsReport;
//import static Services.Booking.DisplayChart;
//import static Services.InputValidators.*;
//import static Services.OTPService.*;
//import static Services.Passenger.AssignSeats;
//import static Services.Payment.Refund;
//import static Services.RegisterAndLogin.LoginStaff;
//import static Services.RegisterAndLogin.RegisterStaff;
//import static java.lang.Integer.parseInt;
//
//public class PortalRunners {
//    public static void Railway(Scanner scanner) {
//            System.out.println("  RAILWAY RESERVATION SYSTEM : ");
//            System.out.println("1.Staff Portal");
//            System.out.println("2.Passenger Portal");
//            System.out.println("3.PNR Check with Guest Login");
//            System.out.println("4.Exit System");
//            System.out.println("Your choice : ");
//            int choice = InputValidators.OnlyInteger(scanner);
//            switch (choice) {
//                case 1 -> StaffPortal(scanner);
//                case 2 -> PassengerPortal(scanner);
//                case 3 -> PortalRunners.GuestMenu(scanner);
//                case 4 -> {
//                    System.out.println("Exited. Thankyou!");
//                }
//                default -> System.out.println("Invalid option");
//            }
//        }
//
//    public static void StaffPortal(Scanner scanner) {
//        boolean run = true;
//        while (run) {
//            System.out.println("STAFF PORTAL :");
//            System.out.println("1.Login");
//            System.out.println("2.Forgot password");
//            System.out.println("3.Home.");
//            int UserInput = OnlyInteger(scanner);
//            if (UserInput == 1) {
//                System.out.println("Enter your staff id or email or phone no : ");
//                String UserName = scanner.nextLine().trim();
//                LoginStaff(scanner, UserName);
//            } else if (UserInput == 2) {
//                System.out.println("Enter recovery email or phone : ");
//                String recovery = scanner.nextLine().trim();
//                Staff resetid = null;
//                for (Staff s : StaffDatabase) {
//                    if ((s.getEmail().equals(recovery)) || (s.getPhoneNo().equals(recovery))) {
//                        resetid = s;
//                        ResetPassword(scanner, recovery, resetid);
//                    }
//                }
//            } else {
//                Railway(scanner);
//            }
//        }
//    }
//    public static void SuperAdminPortal(Scanner scanner, Staff staff) {
//        while (true) {
//            System.out.println(" SUPER ADMIN DASHBOARD : ");
//            System.out.println("1.Register new staff");
//            System.out.println("2.List of current staff");
//            System.out.println("3.Remove Staff");
//            System.out.println("4.View current train inventory");
//            System.out.println("5.Edit inventory");
//            System.out.println("6.View prepared chart");
//            System.out.println("7.View complete Bookings report");
//            System.out.println("8.Logout");
//            System.out.println("Enter your choice : ");
//            int choice = OnlyInteger(scanner);
//            switch (choice) {
//                case 1 -> {
//                    RegisterStaff(scanner);
//                }
//                case 2 -> {
//                    System.out.println(" ACTIVE STAFFS : ");
//                    System.out.printf("%-20s | %-20s | %-20s | %-20s | %-20s | %-20s %n ", " STAFF ID", " STAFF NAME ", "ROLE", " PHONE", " EMAIL", " TRAINNO (FOR TTE)");
//                    for (Staff s : StaffDatabase) {
//                        String train = (s instanceof TTE tte) ? "Train : " + tte.getAssignedTrainNo() : "NA";
//                        System.out.printf("%-20s | %-20s | %-20s | %-20s | %-20s | %-20s %n ", s.getStaffId(), s.getName(), s.getRole(), s.getPhoneNo(), s.getEmail(), train);
//                    }
//                }
//                case 3 -> {
//                    System.out.println(" ACTIVE STAFFS : ");
//                    System.out.printf(" %-20s | %-20s | %-20s | %-20s | %-20s | %-20s %n ", "STAFF ID", "STAFF NAME ", "ROLE", "PHONE", "EMAIL", "TRAINNO (FOR TTE)");
//                    for (Staff s : StaffDatabase) {
//                        String train = (s instanceof TTE tte) ? "Train : " + tte.getAssignedTrainNo() : "NA";
//                        System.out.printf(" %-20s | %-20s | %-20s | %-20s | %-20s | %-20s %n ", s.getStaffId(), s.getName(), s.getRole(), s.getPhoneNo(), s.getEmail(), train);
//                    }
//                    System.out.println("Enter StaffID to remove : ");
//                    String id = scanner.nextLine().trim();
//                    Staff remove = null;
//                    for (Staff ss : StaffDatabase) {
//                        if (ss.getStaffId().equals(id)) {
//                            remove = ss;
//                            break;
//                        }
//                    }
//                    if (remove == null) {
//                        System.out.println("Staff id not found. ");
//
//
//                    } else {
//                        StaffDatabase.remove(remove);
//                        System.out.println("Staff : " + remove.getName() + "removed.");
//
//                    }
//                }
//                case 4 -> {
//                    DisplayTrainInventory(TrainInventory);
//
//                }
//                case 5 -> {
//                    EditInventory(scanner, staff);
//
//                }
//                case 6-> {
//                    System.out.println("enter train no : ");
//                    int trainno=OnlyInteger(scanner);
//                    for (Train t : TrainInventory){
//                        if (t.getTrainNo()==trainno){
//                            AssignSeats(t);
//                            DisplayChart(t);
//                        }
//                    }
//                }
//
//                case 7 -> {
//                    System.out.println("Enter train no to view report : ");
//                    int Trainno=OnlyInteger(scanner);
//                    BookingsReport(Trainno);
//
//                }
//                case 8 -> {
//                    System.out.println("Logged out!");
//                    StaffPortal(scanner);
//                }
//                default -> {
//                    System.out.println("Invalid option.");
//
//                }
//            }
//        }
//    }
//    public static void InventoryManagerPortal(Scanner scanner, Staff staff) {
//        while (true) {
//            System.out.println(" INVENTORY MANAGER DASHBOARD : ");
//            System.out.println("1.View complete inventory");
//            System.out.println("2.Edit Inventory ");
//            System.out.println("3.View Prepared Chart");
//            System.out.println("4.View complete bookings report");
//            System.out.println("5.Logout");
//            int ch = OnlyInteger(scanner);
//            switch (ch) {
//                case 1 -> {
//                    DisplayTrainInventory(TrainInventory);
//                    InventoryManagerPortal(scanner, staff);
//                }
//                case 2 -> {
//                    EditInventory(scanner, staff);
//                }
//                case 3 -> {
//                    System.out.println("enter train no : ");
//                    int trainno=OnlyInteger(scanner);
//                    for (Train t : TrainInventory){
//                        if (t.getTrainNo()==trainno){
//                            AssignSeats(t);
//                            DisplayChart(t);
//                        }
//                    }
//                }
//                case 4 ->{
//                    System.out.println("Enter trainno to view report : ");
//                    int trainno=parseInt(scanner.nextLine().trim());
//                    BookingsReport(trainno);
//                }
//                case 5 -> {
//                    return;
//                }
//            }
//        }
//    }
//    public static void TTEPortal(Scanner scanner,TTE tte) {
//        boolean run = true;
//        while (run) {
//            System.out.println("TTE PORTAL : ");
//            System.out.println("1.Verify tickets");
//            System.out.println("2.Upgrade Rac to seat");
//            System.out.println("3.View prepared chart");
//            System.out.println("4.Logout");
//            System.out.println("Enter your choice : ");
//            int choice = OnlyInteger(scanner);
//
//            switch (choice) {
//                case 1 -> {
//                    Train train=null;
//                    for (Train t : TrainInventory){
//                        if (t.getTrainNo()==tte.getAssignedTrainNo());
//                        train=t;
//                    }
//                    displayTTETab(train);
//                    VerifyTickets(scanner);
//                }
//                case 2->{
//                }
//                case 3->{
//                    System.out.println("enter train no : ");
//                    int trainno=OnlyInteger(scanner);
//                    for (Train t : TrainInventory){
//                        if (t.getTrainNo()==trainno){
//                            AssignSeats(t);
//                            DisplayChart(t);
//                        }
//                    }
//                }
//                case 4 -> {
//                    run = false;
//                }
//            }
//        }
//    }
//    public static void PassengerPortal(Scanner scanner) {
//        while (true) {
//            System.out.println("PASSENGER PORTAL : ");
//            System.out.println("1.Login");
//            System.out.println("2.Register");
//            System.out.println("3.Exit");
//            System.out.println("Enter : ");
//            int choice = OnlyInteger(scanner);
//            switch (choice) {
//                case 1 -> {
//                    System.out.println("Enter phone no or email : ");
//                    String UserLogin = scanner.nextLine().trim();
//                    User Current = null;
//                    for (User u : UserDB) {
//                        if ((u.getPhoneNo().equals(UserLogin)) || (u.getEmail().equals(UserLogin))) {
//                            System.out.println("Enter your password : ");
//                            String pass = scanner.nextLine().trim();
//                            if (u.getPassword().equals(pass)) {
//                                System.out.println("Login successful!" + u.getName());
//                                Current = u;
//                            }
//
//                        }
//
//                    }
//                    if (Current != null) {
//                        PassengerMenu(scanner, Current);
//                    }else{
//                        System.out.println("Invalid");
//                    }
//                }
//                case 2 ->{
//                    String name=readValidName(scanner,"Enter name as it is in Aadhar : ");
//                    String phoneno=ReadValidPhoneNumber(scanner,"Phone no : ");
//                    VerifyPhone(scanner,phoneno);
//                    String email=ReadValidEmail(scanner,"Email  : ");
//                    VerifyEmail(scanner,email);
//                    String pass=ReadValidPassword(scanner,"Set password : ");
//                    Date dob=Readvaliddob(scanner,"Enter date of birth (dd-mm-yyyy) : ");
//                    Gender gender= ReadValidGender(scanner);
//                    String aadharno=ReadValidAadhar(scanner,"Enter you aadhar no : ");
//                    User user=new User(name,phoneno,email,pass,dob,gender,aadharno);
//                    UserDB.add(user);
//                    System.out.println("Registration successful!");
//                }
//                case 3->{
//                    System.out.println("Logged out ! ");
//                    Railway(scanner);
//                }
//                case 4->{
//                    return;
//
//                }
//            }
//        }
//    }
//        public static void PassengerMenu (Scanner scanner, User user){
//
//            while (true) {
//                System.out.println("PASSENGER DASHBOARD : ");
//                System.out.println("1.Book Ticket");
//                System.out.println("2.View Booking history");
//                System.out.println("3.Cancel ticket");
//                System.out.println("4.Logout");
//                int choice = OnlyInteger(scanner);
//
//                switch (choice) {
//                    case 1 -> {
//                        user.BookTicket(scanner);
//                    }
//                    case 2 ->{
//                        if (user.getMyBookings().isEmpty()){
//                            System.out.println("No bookings!");
//                        }else {
//                            for (Booking b : user.getMyBookings()) {
//                                System.out.println(b.getpnrno() + " is your pnr, status :" + b.getStatus());
//
//                            }
//                        }
//                    }
//
//                    case 3 ->{
//                        System.out.println("Enter Pnr to cancel : ");
//                        String pnr=scanner.nextLine().trim();
//                        for (Booking b : ActiveBookings){
//                            if (b.getpnrno().equals(pnr)){
//                                b.setStatus(BookingStatus.CANCELLED);
//                                Passenger Pass =b.getPassengerlist().get(0);
//                                Refund(Pass, b.getTotalFare());
//                            }
//                        }
//                    }
//                    case 4->{
//                        return;
//                    }
//                }
//            }
//        }
//        public static void GuestMenu(Scanner scanner){
//            System.out.println("Enter PNR to check :");
//            String PNR=scanner.nextLine().trim();
//            for (Booking b : ActiveBookings){
//                if (b.getpnrno().equals(PNR)){
//                    System.out.println("PNR : "+PNR+" is "+b.getStatus());
//                }
//            }
//        }
//    }