package Services;
import Enums.Gender;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.Scanner;
public class InputValidators {
    public static int OnlyInteger(Scanner scanner) {
        while (true) {
            String input=scanner.nextLine().trim();
            if (input.isEmpty()){
                continue;
            }
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.print("Invalid input, enter again :  ");
            }
        }
    }
    public static double OnlyFloat(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Float.parseFloat(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input, enter again : ");
            }
        }
    }
    public static String ReadValidPhoneNumber(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String phone = scanner.nextLine().trim();
            if (phone.matches("\\d{10}")) return phone;
            System.out.println("Invalid phone number. Must be exactly 10 digits.");
        }
    }
    public static String readValidName(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String name = scanner.nextLine().trim();
            if (name.length() > 2 && name.matches("[a-zA-Z ]+")) return name;
            System.out.println("Invalid name. ");
        }
    }
    public static String ReadValidEmail(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String email = scanner.nextLine().trim();
            if (email.matches("^[A-Za-z0-9_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) return email;
            System.out.println("Invalid email address, try again : ");
        }
    }
    public static String ReadValidAadhar(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String aadhar = scanner.nextLine().trim();
            if (aadhar.matches("\\d{12}")) return aadhar;
            System.out.println("Invalid input, enter again : ");
        }
    }
    public static String ReadValidPassword(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String pass = scanner.nextLine().trim();
            if (pass.length() >= 6) return pass;
            System.out.println(" Minimum 6 characters required.");
        }
    }
    public static LocalDate Readvaliddob(Scanner scanner, String prompt) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-uuuu").withResolverStyle(ResolverStyle.STRICT);
        while (true) {
            try {
                System.out.println(prompt);
                String input = scanner.nextLine().trim();
                LocalDate date =LocalDate.parse(input,formatter);
                return date;
            } catch (DateTimeParseException e) {
                System.out.println("Invalid dob, enter again : ");;
            }
        }
    }
    public static Gender ReadValidGender(Scanner scanner) {
        Gender gender=null;
        while (gender==null){
            System.out.println("Choose your gender : \n 1.male \n 2.female \n 3.other");
            int choice = OnlyInteger(scanner);
            switch (choice) {
                case 1 -> gender = Gender.MALE;
                case 2 -> gender = Gender.FEMALE;
                case 3 -> gender = Gender.OTHER;
                default -> System.out.println("Invalid option");
            }
        }
        return gender;
    }
}
