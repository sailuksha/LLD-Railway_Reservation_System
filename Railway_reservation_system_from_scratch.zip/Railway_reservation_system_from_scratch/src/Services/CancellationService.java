package Services;
import Objects.*;
import Enums.BookingStatus;
import static Objects.Storage.ActiveBookings;
public class CancellationService {
    public static boolean cancelPassenger(String pnr, String passengerName) {
        BookingService booking = null;
        Passenger passenger = null;
        for (BookingService b : ActiveBookings) {
            if (b.getpnrno().equals(pnr)) {
                booking = b;
                break;
            }
        }
        if (booking == null) {
            System.out.println("PNR not found.");
            return false;
        }

        for (Passenger p : booking.getPassengerlist()) {
            if (p.getPassengerName().equalsIgnoreCase(passengerName) && p.getBookingStatus() != BookingStatus.CANCELLED) {
                passenger = p;
                break;
            }
        }
        if (passenger == null) {
            System.out.println("Passenger not found.");
            return false;
        }
        Train train = booking.getBookedTrain();
        if (train == null) {
            return false;
        }
        Coach coach = null;
        for (Coach c : train.GetCoaches()) {
            if (c.getCoachId().equalsIgnoreCase(passenger.getCoachid())) {
                coach = c;
                break;
            }
        }
        if (coach == null) {
            return false;
        }
        SeatInventory inventory = coach.getSeatInventory();
        switch (passenger.getBookingStatus()) {
            case CONFIRMED -> {
                Seat releasedSeat = null;
                for (Seat seat : coach.getTotalConfirmedSeats()) {
                    if (seat.getSeatNo() == passenger.getSeatno()) {
                        releasedSeat = seat;
                        break;
                    }
                }
                if (releasedSeat == null) {
                    return false;
                }
                coach.removeFromTotalConfirmedSeats(releasedSeat);
                promotePassengers(releasedSeat, coach, inventory);
            }
            case RAC -> {
                if (!inventory.removeRacPassenger(passenger)) {
                    return false;
                }
                promoteWaitingToRAC(inventory);
            }
            case WAITLIST -> {
                if (!inventory.removeWaitingPassenger(passenger)) {
                    return false;
                }
            }
            default -> {
                System.out.println("Cannot cancel this passenger.");
                return false;
            }
        }
        passenger.setBookingStatus(BookingStatus.CANCELLED);
        passenger.setSeatno(0);
        passenger.setWaitListNo(0);
        boolean allCancelled = booking.getPassengerlist()
                .stream()
                .allMatch(p -> p.getBookingStatus() == BookingStatus.CANCELLED);
        if (allCancelled) {
            booking.setStatus(BookingStatus.CANCELLED);
        }
        System.out.println(passenger.getPassengerName()+ " cancelled successfully.");
        return true;
    }
    private static void promotePassengers(Seat releasedSeat, Coach coach, SeatInventory inventory) {
        Passenger racPassenger = inventory.removeFirstRacPassenger();
        if (racPassenger == null) {
            inventory.addAvailableSeat(releasedSeat);
            return;
        }
        releasedSeat.setBookingstatus(BookingStatus.CONFIRMED);
        racPassenger.setBookingStatus(BookingStatus.CONFIRMED);
        racPassenger.setSeatno(releasedSeat.getSeatNo());
        racPassenger.setCoachid(coach.getCoachId());
        racPassenger.setCoachType(coach.getCoachType());
        racPassenger.setWaitListNo(0);
        coach.addtoTotalConfirmedSeats(releasedSeat);
        System.out.println(racPassenger.getPassengerName() + " promoted to CONFIRMED.");
        promoteWaitingToRAC(inventory);
    }
    private static void promoteWaitingToRAC(SeatInventory inventory) {
        Passenger waitingPassenger = inventory.removeFirstWaitingPassenger();
        if (waitingPassenger == null) {
            return;
        }
        inventory.addRacPassenger(waitingPassenger);
        System.out.println(waitingPassenger.getPassengerName() + " promoted from WAITLIST to RAC."
        );
    }
}