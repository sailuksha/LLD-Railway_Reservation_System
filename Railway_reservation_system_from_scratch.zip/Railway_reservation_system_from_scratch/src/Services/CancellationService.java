package Services;
import Objects.*;
import Enums.BookingStatus;
import java.util.List;
import java.util.Scanner;
import static Objects.Storage.ActiveBookings;
import static Services.InputValidators.OnlyInteger;

public class CancellationService {
    public static void CancelTicket(Scanner scanner) {
        System.out.println("Enter pnr to cancel : ");
        String pnr = scanner.nextLine().trim();
        BookingService booking = null;
        for (BookingService b : ActiveBookings) {
            if (b.getpnrno().equals(pnr)) {
                booking = b;
                break;
            }
        }
        if (booking == null) {
            System.out.println("PNR not found ");
            return;
        }
        List<Passenger> passengers = booking.getPassengerlist();
        boolean anyactive = passengers.stream().anyMatch(p -> p.getBookingStatus() == BookingStatus.CANCELLED);
        if (anyactive) {
            System.out.println("This whole booking cancelled already");
            booking.setStatus(BookingStatus.CANCELLED);
            return;
        }
        while (true) {
            System.out.println("PASSENGER LIST : ");
            System.out.println("Train : " + booking.getBookedTrain().getTrainNo() + "from : " + booking.getSource() + "to : " + booking.getDestination());
            System.out.printf("%-20s | %-20s | %-20s | %-20s | %-20s | %-20s %n", "Sl.no", "NAME", "STATUS", "COACH", "SEAT/RAC/WL", "QUOTA");
            for (int i = 0; i < passengers.size(); i++) {
                Passenger p = passengers.get(i);
                String seatInfo = "-";
                if (p.getBookingStatus() == BookingStatus.CONFIRMED) {
                    seatInfo = "Seat: " + p.getSeatno();
                } else if (p.getBookingStatus() == BookingStatus.RAC) {
                    seatInfo = "RAC";
                } else if (p.getBookingStatus() == BookingStatus.WAITLIST) {
                    seatInfo = "WL: " + p.getWaitListNo();
                } else if (p.getBookingStatus() == BookingStatus.CANCELLED) {
                    seatInfo = "CANCELLED";
                }
                String coachInfo = (p.getCoachid() != null && !p.getCoachid().isEmpty()) ? p.getCoachid() : "-";
                System.out.printf("%-20d | %-20s | %-20s | %-20s | %-20s | %-20s%n",
                        (i + 1), p.getPassengerName(), p.getBookingStatus(), coachInfo, seatInfo, p.getQuotaType());
            }
            System.out.println(" CANCELLATION OPTIONS:");
            System.out.println("1. Cancel a specific passenger");
            System.out.println("2. Cancel all active passengers");
            System.out.println("3. Back to Dashboard");
            System.out.print("Enter your choice: ");
            int option = OnlyInteger(scanner);
            double FarePerPassenger = booking.getTotalFare() / passengers.size();

            if (option == 1) {
                System.out.println("enter passenger serial no to cancel : ");
                int choice = OnlyInteger(scanner);
                if (choice < 1 || choice > passengers.size()) {
                    System.out.println("Invalid passenger selection!");
                    continue;
                }

                Passenger selectedPassenger = passengers.get(choice - 1);
                if (selectedPassenger.getBookingStatus() == BookingStatus.CANCELLED) {
                    System.out.println("Passenger " + selectedPassenger.getPassengerName() + " is already cancelled!");
                    continue;
                }
                boolean success = cancelPassenger(booking, selectedPassenger);
                if (success) {
                    Payment.Refund(selectedPassenger, FarePerPassenger);
                } else {
                    System.out.println("Failed to cancel passenger.");
                }
                boolean stillActive = passengers.stream().anyMatch(p -> p.getBookingStatus() != BookingStatus.CANCELLED);
                if (!stillActive) {
                    System.out.println("All passengers on this booking are now cancelled.");
                    booking.setStatus(BookingStatus.CANCELLED);
                    break;
                }
            } else if (option == 2) {
                System.out.println("\nCancelling all remaining active passengers...");
                double totalRefund = 0.0;
                int cancelledCount = 0;
                for (Passenger p : passengers) {
                    if (p.getBookingStatus() != BookingStatus.CANCELLED) {
                        boolean success = cancelPassenger(booking, p);
                        if (success) {
                            totalRefund += Payment.Refund(p, FarePerPassenger);
                            cancelledCount++;
                        }
                    }
                }
                updateBookingStatus(booking);
                System.out.printf("Cancelled %d passenger. Total Refund: Rs. %.2f%n", cancelledCount, totalRefund);
                break;
            } else if (option == 3) {
            System.out.println("Returning to menu...");
            break;
        } else {
            System.out.println("Invalid option! Please enter 1, 2, or 3.");
        }
    }
}

    public static boolean cancelPassenger(BookingService booking, Passenger passenger) {
        Train train = booking.getBookedTrain();
        if (train == null) {
            return false;
        }
        Coach coach = null;
        if (passenger.getCoachid() != null) {
            for (Coach c : train.GetCoaches()) {
                if (c.getCoachId().equalsIgnoreCase(passenger.getCoachid())) {
                    coach = c;
                    break;
                }
            }
        }
        if (coach == null && passenger.getCoachType() != null) {
            for (Coach c : train.GetCoaches()) {
                if (c.getCoachType() == passenger.getCoachType()) {
                    coach = c;
                    break;
                }
            }
        }
        if (coach == null && !train.GetCoaches().isEmpty()) {
            coach = train.GetCoaches().get(0);
        }

        if (coach == null) {
            return false;
        }

        SeatInventory inventory = coach.getSeatInventory();
        BookingStatus previousStatus = passenger.getBookingStatus();

        switch (previousStatus) {
            case CONFIRMED -> {
                Seat releasedSeat = null;
                for (Seat seat : coach.getTotalConfirmedSeats()) {
                    if (seat.getSeatNo() == passenger.getSeatno()) {
                        releasedSeat = seat;
                        break;
                    }
                }
                if (releasedSeat != null) {
                    promotePassengers(releasedSeat, coach, inventory);
                }
            }
            case RAC -> {
                inventory.removeRacPassenger(passenger);
                promoteWaitingToRAC(inventory);
            }
            case WAITLIST -> {
                inventory.removeWaitingPassenger(passenger);
            }
            default -> {
                System.out.println("Cannot cancel passenger with status: " + previousStatus);
                return false;
            }
        }

        passenger.setBookingStatus(BookingStatus.CANCELLED);
        passenger.setSeatno(0);
        passenger.setWaitListNo(0);

        updateBookingStatus(booking);
        System.out.println(passenger.getPassengerName() + " has been cancelled.");
        return true;
    }

    private static void promotePassengers(Seat releasedSeat, Coach coach, SeatInventory inventory) {
        Passenger racPassenger = inventory.removeFirstRacPassenger();
        if (racPassenger == null) {
            coach.removeFromTotalConfirmedSeats(releasedSeat);
            releasedSeat.setBookingstatus(BookingStatus.AVAILABLE);
            inventory.addAvailableSeat(releasedSeat);
            return;
        }
        releasedSeat.setBookingstatus(BookingStatus.CONFIRMED);
        racPassenger.setBookingStatus(BookingStatus.CONFIRMED);
        racPassenger.setSeatno(releasedSeat.getSeatNo());
        racPassenger.setCoachid(coach.getCoachId());
        racPassenger.setCoachType(coach.getCoachType());
        racPassenger.setWaitListNo(0);
        System.out.println(racPassenger.getPassengerName() + " promoted from RAC to CONFIRMED (Seat: " + releasedSeat.getSeatNo() + " in Coach " + coach.getCoachId() + ").");
        promoteWaitingToRAC(inventory);
    }

    private static void promoteWaitingToRAC(SeatInventory inventory) {
        Passenger waitingPassenger = inventory.removeFirstWaitingPassenger();
        if (waitingPassenger == null) {
            return;
        }
        inventory.addRacPassenger(waitingPassenger);
        System.out.println(waitingPassenger.getPassengerName() + " promoted from WAITLIST to RAC.");
    }

    public static void updateBookingStatus(BookingService booking) {
        boolean confirmed = false;
        boolean rac = false;
        boolean waiting = false;
        for (Passenger p : booking.getPassengerlist()) {
            switch (p.getBookingStatus()) {
                case CONFIRMED -> confirmed = true;
                case RAC -> rac = true;
                case WAITLIST -> waiting = true;
                default -> {}
            }
        }
        if (confirmed) {
            booking.setStatus(BookingStatus.CONFIRMED);
        } else if (rac) {
            booking.setStatus(BookingStatus.RAC);
        } else if (waiting) {
            booking.setStatus(BookingStatus.WAITLIST);
        } else {
            booking.setStatus(BookingStatus.CANCELLED);
        }
    }
}


//    public static boolean cancelPassenger(String pnr, String passengerName) {
//        BookingService booking = null;
//        Passenger passenger = null;
//        for (BookingService b : ActiveBookings) {
//            if (b.getpnrno().equals(pnr)) {
//                booking = b;
//                break;
//            }
//        }
//        if (booking == null) {
//            System.out.println("PNR not found.");
//            return false;
//        }
//
//        for (Passenger p : booking.getPassengerlist()) {
//            if (p.getPassengerName().equalsIgnoreCase(passengerName) && p.getBookingStatus() != BookingStatus.CANCELLED) {
//                passenger = p;
//                break;
//            }
//        }
//        if (passenger == null) {
//            System.out.println("Passenger not found.");
//            return false;
//        }
//        Train train = booking.getBookedTrain();
//        Coach coach = null;
//        for (Coach c : train.GetCoaches()) {
//            if (c.getCoachId().equals(passenger.getCoachid())) {
//                coach = c;
//                break;
//            }
//        }
//        if (coach == null) {
//            return false;
//        }
//        SeatInventory inventory = coach.getSeatInventory();
//        switch (passenger.getBookingStatus()) {
//            case CONFIRMED -> {
//                Seat releasedSeat = null;
//                for (Seat seat : coach.getTotalConfirmedSeats()) {
//                    if (seat.getSeatNo() == passenger.getSeatno()) {
//                        releasedSeat = seat;
//                        break;
//                    }
//                }
//                if (releasedSeat == null) {
//                    return false;
//                }
//                promotePassengers(releasedSeat, coach, inventory);
//            }
//            case RAC -> {
//                if (!inventory.removeRacPassenger(passenger)) {
//                    return false;
//                }
//                promoteWaitingToRAC(inventory);
//            }
//            case WAITLIST -> {
//                if (!inventory.removeWaitingPassenger(passenger)) {
//                    return false;
//                }
//            }
//            default -> {
//                System.out.println("Cannot cancel this passenger.");
//                return false;
//            }
//        }
//        passenger.setBookingStatus(BookingStatus.CANCELLED);
//        passenger.setSeatno(0);
//        passenger.setWaitListNo(0);
//        boolean allCancelled = booking.getPassengerlist()
//                .stream()
//                .allMatch(p -> p.getBookingStatus() == BookingStatus.CANCELLED);
//        if (allCancelled) {
//            booking.setStatus(BookingStatus.CANCELLED);
//        }
//        System.out.println(passenger.getPassengerName()+ " cancelled successfully.");
//        return true;
//    }
//    private static void promotePassengers(Seat releasedSeat, Coach coach, SeatInventory inventory) {
//        Passenger racPassenger = inventory.removeFirstRacPassenger();
//        if (racPassenger == null) {
//            coach.removeFromTotalConfirmedSeats(releasedSeat);
//            inventory.addAvailableSeat(releasedSeat);
//            return;
//        }
//        releasedSeat.setBookingstatus(BookingStatus.CONFIRMED);
//        racPassenger.setBookingStatus(BookingStatus.CONFIRMED);
//        racPassenger.setSeatno(releasedSeat.getSeatNo());
//        racPassenger.setCoachid(coach.getCoachId());
//        racPassenger.setCoachType(coach.getCoachType());
//        racPassenger.setWaitListNo(0);
//        System.out.println(racPassenger.getPassengerName() + " promoted to CONFIRMED.");
//        promoteWaitingToRAC(inventory);
//    }
//    private static void promoteWaitingToRAC(SeatInventory inventory) {
//        Passenger waitingPassenger = inventory.removeFirstWaitingPassenger();
//        if (waitingPassenger == null) {
//            return;
//        }
//        inventory.addRacPassenger(waitingPassenger);
//        System.out.println(waitingPassenger.getPassengerName() + " promoted from WAITLIST to RAC.");
//    }
//}
