package Actors;
import Enums.StaffRole;
import Objects.Train;
import Services.BookingService;
import Enums.TTECheckStatus;
import Services.Passenger;
import java.util.Scanner;
import static Objects.Storage.ActiveBookings;
import static Services.InputValidators.OnlyInteger;
public class TTE extends Staff {
    private int AssignedTrainNo;
    public TTE(String name, String PhoneNo, String email, String password, int AssignedTrainNo){
        super(name, PhoneNo,email,password, StaffRole.TTE);
        this.AssignedTrainNo = AssignedTrainNo;
    }
    public int getAssignedTrainNo(){return AssignedTrainNo;}
    public static void VerifyTickets(Scanner scanner){
        boolean run=true;
        while (run){
            System.out.println("1.Enter PNR to verify");
            System.out.println("2.Exit");
            int choice= OnlyInteger(scanner);
            if (choice==1) {
                System.out.println("Enter PNR to verify : ");
                String PNR = scanner.nextLine().trim();
                boolean foundpnr=false;
                for (BookingService b : ActiveBookings) {
                    if (b.getpnrno().equals(PNR) && b.getTTECheck().equals(TTECheckStatus.YET_TO_VERIFY)) {
                        b.setTTECheck(TTECheckStatus.VERIFIED);
                        System.out.println("Ticket verified");
                        foundpnr = true;
                        break;
                    }else if(b.getpnrno().equals(PNR) && b.getTTECheck().equals(TTECheckStatus.VERIFIED)){
                        System.out.println("Ticket already verified");
                    }
                }
                if(!foundpnr){
                        System.out.println("PNR not found!");
                    }
            }else if (choice==2){
                run=false;
            }else{
                System.out.println("Invalid choice");
            }
        }
    }
    public static void displayTTETab(Train train){
        System.out.printf("%-20 | %-20 | %-20 \n","PNR","Passengers","TTE check status");
        for(Passenger p : train.getPassengerList()){
            System.out.printf("%-20 | %-20 | %-20 \n",p.getPnr(),p.getName(),p.getTteCheckStatus());
        }
    }
}