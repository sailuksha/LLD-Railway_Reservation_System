package Actors;
import Enums.*;
import Services.BookingService;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class User {
    private String name;
    private String PhoneNo;
    private String email;
    private String password;
    private LocalDate dob;
    private Gender Gender;
    private String AadharNo;
    private List<BookingService> MyBookings;

    public User(String name, String PhoneNo, String email, String password, LocalDate dob, Gender gender, String AadharNo) {
        this.name = name;
        this.PhoneNo = PhoneNo;
        this.email = email;
        this.password = password;
        this.dob = dob;
        this.Gender = gender;
        this.AadharNo = AadharNo;
        this.MyBookings=new ArrayList<>();
    }
    public Gender getGender() {
        return Gender;
    }
    public void addToMyBookings(BookingService booking){
        this.MyBookings.add(booking);
    }
    public String getName() {
        return name;
    }
    public String getPhoneNo() {
        return PhoneNo;
    }
    public String getEmail() {
        return email;
    }
//    public LocalDate getDob() {
//        return dob;
//    }
    public List<BookingService> getMyBookings(){
        return MyBookings;
    }
    public String getPassword() {
        return this.password;
    }
}