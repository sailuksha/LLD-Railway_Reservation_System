package Actors;

import Enums.StaffRole;

public class InventoryManager extends Staff {
    public InventoryManager ( String name, String phoneno,String email,String password){
        super(name,phoneno,email,password, StaffRole.INVENTORY_MANAGER);
    }
}
