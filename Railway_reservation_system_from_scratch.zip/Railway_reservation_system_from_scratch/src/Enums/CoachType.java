package Enums;

public enum CoachType {
    SLEEPER(1.0, 72),
    AC_3TIER(1.5, 64),
    AC_2TIER(2.5, 48),
    AC_FIRST(3.5, 24),
    EXECUTIVE_CHAIR_CAR(5,70),
    AC_CHAIR_CAR(4.5,52);

    private final double fareMultiplier;
    private final int totalSeats;

    CoachType(double fareMultiplier, int totalSeats) {
        this.fareMultiplier = fareMultiplier;
        this.totalSeats = totalSeats;
    }
    public int getTotalSeats(){
        return totalSeats;
    }
}
