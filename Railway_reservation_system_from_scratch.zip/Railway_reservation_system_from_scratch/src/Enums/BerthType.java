package Enums;

public enum BerthType {
    LOWER("LB"),
    MIDDLE("MB"),
    UPPER("UB"),
    SIDE_LOWER("SL"),
    SIDE_UPPER("SU"),
    CHAIR_CAR("CC");
    private final String code;
    BerthType(String code) {
        this.code = code;
    }
}