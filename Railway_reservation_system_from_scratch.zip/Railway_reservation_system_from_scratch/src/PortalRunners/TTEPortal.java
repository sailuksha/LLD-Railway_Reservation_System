package PortalRunners;
import Actors.TTE;
import Objects.Train;
import Services.InputValidators;
import Services.Passenger;
import java.util.Scanner;
import static Actors.TTE.VerifyTickets;
import static Actors.TTE.displayTTETab;
import static Objects.Storage.TrainInventory;
import static PortalRunners.ChartAndReport.DisplayChart;

public class TTEPortal {
    public static void Menu(Scanner scanner, TTE tte) {
        while (true) {
            System.out.println("TTE PORTAL :");
            System.out.println("1. Verify Tickets");
            System.out.println("2. Upgrade RAC to Seat");
            System.out.println("3. View Prepared Chart");
            System.out.println("4. Logout");
            int choice = InputValidators.OnlyInteger(scanner);
            switch (choice) {
                case 1 -> {
                    Train train = null;
                    for (Train t : TrainInventory) {
                        if (t.getTrainNo() == tte.getAssignedTrainNo()) {
                            train = t;
                            break;
                        }
                    }
                    if (train == null) {
                        System.out.println("Assigned train not found!");
                        return;
                    }
                    displayTTETab(train);
                    VerifyTickets(scanner);
                }
                case 2 -> {
                    Train train = null;
                    for (Train t : TrainInventory) {
                        if (t.getTrainNo() == tte.getAssignedTrainNo()) {
                            train = t;
                            break;
                        }
                    }
                    if (train == null) {
                        System.out.println("Assigned train not found!");
                        break;
                    }
                    Passenger.UpgradeRAC(scanner, train);
                }
                case 3 -> {
                    int trainno = tte.getAssignedTrainNo();
                    Train train = null;
                    for (Train t : TrainInventory) {
                        if (t.getTrainNo() == trainno) {
                            train = t;
                            break;
                        }
                    }
                    if (train == null) {
                        System.out.println("Assigned train not found!");
                        return;
                    }
                    DisplayChart(train);
                }
                case 4 -> {
                    System.out.println("TTE logged out successfully.");
                    return;
                }
                default -> System.out.println("Invalid option!");
            }
        }
    }
}
