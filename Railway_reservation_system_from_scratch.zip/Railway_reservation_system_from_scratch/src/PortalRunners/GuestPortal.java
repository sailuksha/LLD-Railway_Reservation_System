package PortalRunners;
import java.util.Scanner;
import Objects.Storage;
import Services.BookingService;

public class GuestPortal {

    public static void Menu(Scanner scanner) {
        System.out.println("Enter PNR to check:");
        String pnr = scanner.nextLine().trim();
        boolean found = false;
        for (BookingService b : Storage.ActiveBookings) {
            if (b.getpnrno().equals(pnr)) {
                System.out.println("PNR: " + pnr + " is " + b.getStatus());
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("PNR not found.");
        }
    }
}