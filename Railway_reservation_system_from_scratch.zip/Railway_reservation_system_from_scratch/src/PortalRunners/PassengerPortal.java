package PortalRunners;
import Actors.Staff;
import Actors.User;
import Enums.Gender;
import Services.BookingService;
import java.time.LocalDate;
import java.util.Scanner;
import static Objects.Storage.*;
import static Objects.Storage.StaffDatabase;
import static Services.BookingService.BookTicket;
import static Services.CancellationService.CancelTicket;
import static Services.InputValidators.*;
import static Services.OTPService.*;


public class PassengerPortal {

    public static void Menu(Scanner scanner) {
        while (true) {

            System.out.println("PASSENGER PORTAL");
            System.out.println("1. Login");
            System.out.println("2. Register");
            System.out.println("3. Exit");
            System.out.print("Enter: ");
            int choice = OnlyInteger(scanner);
            switch (choice) {
                case 1 -> login(scanner);
                case 2 -> register(scanner);
                case 3 -> {
                    System.out.println("Exiting Passenger Portal!");
                    return;
                }
                default -> System.out.println("Invalid choice!");
            }
        }
    }
    public static void PassengerMenu (Scanner scanner, User user){

            while (true) {
                System.out.println("PASSENGER DASHBOARD : ");
                System.out.println("1.Book Ticket");
                System.out.println("2.View Booking history");
                System.out.println("3.Cancel ticket");
                System.out.println("4.Logout");
                int choice = OnlyInteger(scanner);

                switch (choice) {
                    case 1 -> {
                        BookTicket(scanner,user);
                    }
                    case 2 ->{
                        if (user.getMyBookings().isEmpty()){
                            System.out.println("No bookings!");
                        }else {
                            for (BookingService b : user.getMyBookings()) {
                                System.out.println(b.getpnrno() + " is your pnr, status :" + b.getStatus());
                            }
                        }
                    }
                    case 3 -> {
                            CancelTicket(scanner);
                    }
                    case 4->{
                        return;
                    }
                }
            }
        }
    public static void login(Scanner scanner) {
        System.out.println("Enter phone no or email : ");
        String UserLogin = scanner.nextLine().trim();
        User Current = null;
        for (User u : UserDB) {
            if ((u.getPhoneNo().equals(UserLogin)) || (u.getEmail().equals(UserLogin))) {
                System.out.println("Enter your password : ");
                String pass = scanner.nextLine().trim();
                if (u.getPassword().equals(pass)) {
                    TwoFactorAunthentication(scanner, u.getEmail());
                    System.out.println("Login successful!" + u.getName());
                    Current = u;
                }
            }
        }PassengerMenu(scanner,Current);
    }
    private static void register(Scanner scanner) {
        String name = readValidName(scanner, "Enter name as it is in Aadhar : ");
        String phone = "";
        while (true) {
            boolean phoneexist = false;
            String Phone = ReadValidPhoneNumber(scanner, "Enter phone no : ");
            for (Staff s : StaffDatabase) {
                if (s.getPhoneNo().equals(Phone)) {
                    phoneexist = true;
                    break;
                }
            }
            if (phoneexist) {
                System.out.println("Phone number already exists");
            } else {
                phone = Phone;
                break;
            }
        }
        VerifyPhone(scanner,phone);
        String email="";
        while (true){
            boolean emailexist=false;
            String Email=ReadValidEmail(scanner,"Enter your email : ");
            for (Staff s : StaffDatabase) {
                if (s.getEmail().equals(Email)) {
                    emailexist = true;
                    break;
                }
            }
            if (emailexist){
                System.out.println("Email already exists");
            }
            else{
                email=Email;
                break;
            }
        }
        VerifyEmail(scanner,email);
        String pass = ReadValidPassword(scanner, "Set password : ");
        LocalDate dob = Readvaliddate(scanner, "Enter date of birth (dd-mm-yyyy) : ");
        Gender gender = ReadValidGender(scanner);
        String aadharno = ReadValidAadhar(scanner, "Enter you aadhar no : ");
        User user = new User(name, phone, email, pass, dob, gender, aadharno);
        UserDB.add(user);
        System.out.println("Registration successful!");
        Menu(scanner);
    }
}