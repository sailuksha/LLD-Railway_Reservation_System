package Services;
import Actors.Staff;
import java.util.Random;
import java.util.Scanner;

public class OTPService {
    private static final Random random = new Random();

    public static boolean VerifyPhone(Scanner scanner, String phone) {
        String PhoneOtp = String.valueOf(random.nextInt(99999)+100000);
        long ExpiryTime = System.currentTimeMillis() + 120000;

        System.out.println(" SMS sent to " + phone + ": " + PhoneOtp);
        int attempts = 0;
        while (attempts < 3) {
            System.out.print("Enter Mobile OTP: ");
            String inputPhoneOtp = scanner.nextLine().trim();

            if (System.currentTimeMillis() > ExpiryTime) {
                System.out.println("OTPs have expired");
                return false;
            }

            if ((inputPhoneOtp.equals(PhoneOtp))) {
                System.out.println("Phone no Verification Successful!");
                return true;
            } else {
                attempts++;
                System.out.println("Invalid OTP." +  (3 - attempts) +"attempts remaining. " );
            }
        }
        return false;
    }

    public static boolean VerifyEmail(Scanner scanner, String Email) {
        String EmailOtp = String.valueOf(random.nextInt(99999)+100000);
        long ExpiryTime = System.currentTimeMillis() + 120000;

        System.out.println("\n SMS sent to " + Email + ": " + EmailOtp);
        int attempts = 0;
        while (attempts < 3) {
            System.out.print("Enter Mobile OTP: ");
            String input = scanner.nextLine().trim();

            if (System.currentTimeMillis() > ExpiryTime) {
                System.out.println("OTPs have expired.");
                return false;
            }

            if ((input.equals(Email))) {
                System.out.println("Phone no Verification Successful!");
                return true;
            } else {
                attempts++;
                System.out.println("Invalid OTP." +  (3 - attempts) +"attempts remaining. " );
            }
        }
        return false;
    }
    public boolean TwoFactorAunthentication(Scanner scanner, String Email) {
        String GeneratedOtp = String.valueOf(random.nextInt(99999)+100000);
        long expiryTime = System.currentTimeMillis() + 120000;
        int attempts = 0;
        System.out.println("\n Email sent to " + Email + " | OTP: " + GeneratedOtp);

        while (attempts < 3) {
            System.out.print("Enter OTP sent to your email: ");
            String inputOtp = scanner.nextLine().trim();

            if (System.currentTimeMillis() > expiryTime) {
                System.out.println("OTP has expired.");
                return false;
            }

            if (inputOtp.equals(GeneratedOtp)) {
                System.out.println("2FA Verification Successful!");
                return true;
            } else {
                attempts++;
                System.out.println("Invalid OTP." +  (3 - attempts) +"attempts remaining. " );
            }
        }
        return false;
    }
    public static boolean ResetPassword(Scanner scanner, String recovery, Staff staff) {
        String GeneratedOtp = String.valueOf( random.nextInt(99999)+100000);
        long ExpiryTime = System.currentTimeMillis() + 120000;
        int attempts = 0;

        System.out.println("\n OTP for " + recovery + ": " + GeneratedOtp);

        while (attempts < 3) {
            System.out.print("Enter the  OTP: ");
            String inputOtp = scanner.nextLine().trim();

            if (System.currentTimeMillis() > ExpiryTime) {
                System.out.println(" OTP has expired ");
                return false;
            }

            if (inputOtp.equals(GeneratedOtp) ) {
                System.out.println("OTP Verified Successfully!");
                String newpass=InputValidators.ReadValidPassword(scanner,"Enter new password : ");
                staff.setPassword(newpass);
                System.out.println("Password resetted");
                return true;
            } else {
                attempts++;
                System.out.println("Invalid OTP." +  (3 - attempts) +"attempts remaining. " );
            }
        }
        System.out.println("Too many failed attempts. ");
        return false;
    }

}
