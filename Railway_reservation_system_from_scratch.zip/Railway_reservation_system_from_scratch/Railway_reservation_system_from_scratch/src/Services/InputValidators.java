package Services;
import Actors.Gender;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
public class InputValidators {
    public static int OnlyInteger(Scanner scanner) {
        while (true) {
            try {
                String line = scanner.nextLine().trim();
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.print("Invalid input, enter again :  ");
            }
        }
    }
    public static double OnlyFloat(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Float.parseFloat(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input, enter again : ");
            }
        }
    }
    public static String ReadValidPhoneNumber(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String phone = scanner.nextLine().trim();
            if (phone.matches("\\d{10}")) return phone;
            System.out.println("Invalid phone number. Must be exactly 10 digits.");
        }
    }
    public static String readValidName(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String name = scanner.nextLine().trim();
            if (name.length() > 2 && name.matches("[a-zA-Z ]+")) return name;
            System.out.println("Invalid name. ");
        }
    }
    public static String ReadValidEmail(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String email = scanner.nextLine().trim();
//            if (email.matches("^[A-Za-z0-9_.-]+@[A-Za-z0-9.-]+.[A-Za-z]{2,}$")) return email;
            if (email.matches("^[A-Za-z0-9_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) return email;
            System.out.println("Invalid email address, try again : ");
        }
    }
    public static String ReadValidAadhar(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String aadhar = scanner.nextLine().trim();
            if (aadhar.matches("\\d{12}")) return aadhar;
            System.out.println("Invalid input, enter again : ");
        }
    }
    public static String ReadValidPassword(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String pass = scanner.nextLine().trim();
            if (pass.length() >= 6) return pass;
            System.out.println(" Minimum 6 characters required.");
        }
    }
    public static Date Readvaliddob(Scanner scanner, String prompt) {
        while (true) {

            try {
                DateFormat formatter = new SimpleDateFormat("dd-mm-yyyy");
                formatter.setLenient(false);
                System.out.println(prompt);
                String input = scanner.nextLine().trim();
                Date date = formatter.parse(input);
                return date;
            } catch (ParseException e) {
                System.out.println("Invalid dob, enter again : ");;
            }
        }
    }
    public static Gender ReadValidGender(Scanner scanner) {

        Gender gender=null;
        while (gender==null){
            System.out.println("Choose your gender : \n 1.male \n 2.female \n 3.other");
            int choice = OnlyInteger(scanner);
            scanner.nextLine();
            switch (choice) {
                case 1 -> gender = Gender.MALE;
                case 2 -> gender = Gender.FEMALE;
                case 3 -> gender = Gender.OTHER;
                default -> System.out.println("Invalid option");
            };
        }
        return gender;
    }
}
