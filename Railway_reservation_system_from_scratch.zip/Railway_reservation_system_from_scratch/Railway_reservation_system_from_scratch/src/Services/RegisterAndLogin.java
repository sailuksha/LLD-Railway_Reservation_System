package Services;
import Actors.InventoryManager;
import Actors.Staff;
import Actors.SuperAdmin;
import Actors.TTE;
import java.util.Scanner;

import static Objects.Storage.StaffDatabase;
import static Services.InputValidators.*;
import static Services.InputValidators.ReadValidPassword;

public class RegisterAndLogin {

    public static void RegisterStaff(Scanner scanner) {
        System.out.println("REGISTERING NEW STAFF");
        System.out.println("1. Inventory Manager \n2. TTE");
        int Role = OnlyInteger(scanner);
        if (Role != 1 && Role != 2) {
            System.out.println("Invalid choice");
        } else if (Role == 1) {
            System.out.println("Enter Staff id : ");
            String NewId = scanner.nextLine().trim();
//            TteIdDb.add(NewId);
            System.out.println("Enter Staff name : ");
            String name = scanner.nextLine().trim();
            String phone = ReadValidPhoneNumber(scanner, "Enter staff phone no : ");
            for (Staff s : StaffDatabase) {
                if (s.getPhoneNo() == phone) {
                    System.out.println("Phone no already exists!");
                } else {
                    String email = ReadValidEmail(scanner, "Enter staff email : ");
                    String pass = ReadValidPassword(scanner, "Setup password : ");
                    StaffDatabase.add(new InventoryManager(NewId, name, phone, email, pass));
                    System.out.println("Inventory manager " + name + " added successfully.");
                }
            }

        } else if (Role == 2) {
            System.out.println("Enter Staff id : ");
            String NewId = scanner.nextLine().trim();
            System.out.println("Enter Staff name : ");
            String name = scanner.nextLine().trim();
            String phone = ReadValidPhoneNumber(scanner, "Enter staff phone no : ");
            for (Staff s : StaffDatabase) {
                if (s.getPhoneNo() == phone) {
                    System.out.println("Phone no already exists!");
                } else {
                    String email = ReadValidEmail(scanner, "Enter staff email : ");
                    String pass = ReadValidPassword(scanner, "Setup password : ");
                    System.out.println("Enter assigned train no : ");
                    int AssignedTrain = OnlyInteger(scanner);
                    StaffDatabase.add(new TTE(NewId, name, phone, email, pass, AssignedTrain));
                    System.out.println("TTE " + name + " registered successfully.");
                }
            }

        }
    }

    public static void LoginStaff(Scanner scanner, String UserName) {
        Staff CurrentUser = null;
        for (Staff s : StaffDatabase) {
            boolean match;
            match = ((s.getEmail().equals(UserName)) || s.getStaffId().equals(UserName) || s.getPhoneNo() == UserName);
            if (match == false) {
                System.out.println("Staff doesn't exist.");
            } else if (match) {
                System.out.println("Enter your password : ");
                String pass = scanner.nextLine().trim();
                if (s.ValidatePass(pass, s)) {
                    CurrentUser = s;
                    System.out.println("Welcome, " + CurrentUser.getName() + " - " + CurrentUser.getRole());
                    if (s instanceof SuperAdmin) {
                        PortalRunners.SuperAdminPortal(scanner, s);
                    } else if (s instanceof InventoryManager) {
                        PortalRunners.InventoryManagerPortal(scanner, s);
                    } else if (s instanceof TTE) {
                        PortalRunners.TTEPortal(scanner);
                    }
                } else {
                    System.out.println("Invalid login credentials.");
                }
            }
        }
    }

    public static void GenerateTTEID() {
        int staff=StaffDatabase.size();
        String st="";
    }
}
