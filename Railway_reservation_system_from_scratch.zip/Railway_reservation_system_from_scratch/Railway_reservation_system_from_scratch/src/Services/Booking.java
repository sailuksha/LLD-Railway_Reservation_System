package Services;

import Actors.User;
import Objects.BerthType;
import Objects.BookingStatus;
import Objects.Coach;
import Objects.QuotaType;
import Objects.Seat;
import Objects.Train;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import static Objects.Coach.DisplayCoaches;
import static Objects.Storage.ActiveBookings;
import static Objects.Storage.TrainInventory;
import static Objects.Train.DisplayTrainInfo;
import static Objects.Train.FindTrain;
import static Services.InputValidators.OnlyInteger;

public class Booking {

    private String pnrNo;
    private User user;
    private String passengerName;
    private int passengerAge;
    private String passengerGender;
    private String source;
    private String destination;
    private double totalFare;
    private LocalDate bookingDate;
    private BookingStatus status;
    private TTECheckStatus TTECheck;
    private Coach coach;
    private Seat seat;
    private BerthType allocatedBerth;
    private int racNumber;       // > 0 if RAC
    private int waitlistNumber;  // > 0 if WAITING
    private int trainNo;

    public Booking(String pnrNo, User user, String source, String destination, double totalFare, BookingStatus status) {
        this(pnrNo, user, (user != null ? user.getName() : "Passenger"), 30, "MALE", source, destination, totalFare, status, 0);
    }

    public Booking(String pnrNo, User user, String passengerName, int passengerAge, String passengerGender,
                   String source, String destination, double totalFare, BookingStatus status, int trainNo) {
        this.pnrNo = pnrNo;
        this.user = user;
        this.passengerName = passengerName;
        this.passengerAge = passengerAge;
        this.passengerGender = passengerGender;
        this.source = source;
        this.destination = destination;
        this.totalFare = totalFare;
        this.bookingDate = LocalDate.now();
        this.status = status;
        this.TTECheck = TTECheckStatus.YET_TO_VERIFY;
        this.racNumber = 0;
        this.waitlistNumber = 0;
        this.trainNo = trainNo;
    }

    public String getpnrno() { return pnrNo; }
    public User getUser() { return user; }
    public String getPassengerName() { return passengerName; }
    public int getPassengerAge() { return passengerAge; }
    public String getPassengerGender() { return passengerGender; }
    public String getSource() { return source; }
    public String getDestination() { return destination; }
    public double getTotalFare() { return totalFare; }
    public LocalDate getBookingDate() { return bookingDate; }
    public TTECheckStatus getTTECheck() { return TTECheck; }
    public void setTTECheck(TTECheckStatus TTECheck) { this.TTECheck = TTECheck; }
    public BookingStatus getStatus() { return status; }
    public void setStatus(BookingStatus status) { this.status = status; }
    public Coach getCoach() { return coach; }
    public void setCoach(Coach coach) { this.coach = coach; }
    public Seat getSeat() { return seat; }
    public void setSeat(Seat seat) { this.seat = seat; }
    public BerthType getAllocatedBerth() { return allocatedBerth; }
    public void setAllocatedBerth(BerthType allocatedBerth) { this.allocatedBerth = allocatedBerth; }
    public int getRacNumber() { return racNumber; }
    public void setRacNumber(int racNumber) { this.racNumber = racNumber; }
    public int getWaitlistNumber() { return waitlistNumber; }
    public void setWaitlistNumber(int waitlistNumber) { this.waitlistNumber = waitlistNumber; }
    public int getTrainNo() { return trainNo; }
    public void setTrainNo(int trainNo) { this.trainNo = trainNo; }

    // =========================================================================
    //  AUTOMATED SEAT ALLOCATION ENGINE (Railway LLD Logic)
    //  - Passengers CANNOT choose seat numbers; only berth preference is accepted.
    //  - Tries preferred berth under chosen quota first.
    //  - Falls back to any available berth in the quota.
    //  - Falls back to General quota.
    //  - If all confirmed berths are exhausted -> assigns RAC (Side Lower sitting).
    //  - If RAC capacity is exhausted -> assigns Waitlist (WL).
    // =========================================================================
    public static class AllocationResult {
        public BookingStatus status;
        public Coach coach;
        public Seat seat;
        public BerthType berthType;
        public int racNo;
        public int wlNo;

        public AllocationResult(BookingStatus status, Coach coach, Seat seat, BerthType berthType, int racNo, int wlNo) {
            this.status = status;
            this.coach = coach;
            this.seat = seat;
            this.berthType = berthType;
            this.racNo = racNo;
            this.wlNo = wlNo;
        }
    }

    public static AllocationResult allocateBerthOrQueue(Train train, Coach selectedCoach, QuotaType quota,
                                                        BerthType preferredBerth, int age, String gender) {
        // Senior Citizen / Divyang auto-preference for LOWER berth
        if ((age >= 60 || quota == QuotaType.SENIOR_CITIZEN || quota == QuotaType.PHYSICALLY_CHALLENGED)
                && preferredBerth == null) {
            preferredBerth = BerthType.LOWER;
        }

        // 1. Try finding a seat matching quota and preferred berth in the coach
        Seat candidateSeat = null;
        if (preferredBerth != null) {
            for (Seat s : selectedCoach.getTotalAvailableSeats()) {
                if (s.getAssignedquota() == quota && s.getBerthtype() == preferredBerth) {
                    candidateSeat = s;
                    break;
                }
            }
        }

        // 2. Fall back to any available seat in the coach matching the requested quota
        if (candidateSeat == null) {
            for (Seat s : selectedCoach.getTotalAvailableSeats()) {
                if (s.getAssignedquota() == quota) {
                    candidateSeat = s;
                    break;
                }
            }
        }

        // 3. Fall back to GENERAL quota if special quota is full
        if (candidateSeat == null && quota != QuotaType.GENERAL) {
            if (preferredBerth != null) {
                for (Seat s : selectedCoach.getTotalAvailableSeats()) {
                    if (s.getAssignedquota() == QuotaType.GENERAL && s.getBerthtype() == preferredBerth) {
                        candidateSeat = s;
                        break;
                    }
                }
            }
            if (candidateSeat == null) {
                for (Seat s : selectedCoach.getTotalAvailableSeats()) {
                    if (s.getAssignedquota() == QuotaType.GENERAL) {
                        candidateSeat = s;
                        break;
                    }
                }
            }
        }

        // 4. Also search other coaches of the same train/class if selected coach has no confirmed seat
        if (candidateSeat == null) {
            for (Coach otherCoach : train.getCoaches()) {
                if (otherCoach.getType() == selectedCoach.getType() && !otherCoach.getTotalAvailableSeats().isEmpty()) {
                    candidateSeat = otherCoach.getTotalAvailableSeats().get(0);
                    selectedCoach = otherCoach;
                    break;
                }
            }
        }

        // CONFIRMED ALLOCATION
        if (candidateSeat != null) {
            candidateSeat.setBookingstatus(BookingStatus.CONFIRMED);
            selectedCoach.removeTotalAvailableSeats(candidateSeat);
            selectedCoach.addtoTotalConfirmedSeats(candidateSeat);
            return new AllocationResult(BookingStatus.CONFIRMED, selectedCoach, candidateSeat, candidateSeat.getBerthtype(), 0, 0);
        }

        // 5. RAC ALLOCATION (Reservation Against Cancellation)
        // Standard Railway Rule: Up to 2 passengers per Side Lower berth share a sitting slot
        int currentRacCount = 0;
        for (Booking b : ActiveBookings) {
            if (b.getTrainNo() == train.getTrainNo() && b.getStatus() == BookingStatus.RAC) {
                currentRacCount++;
            }
        }

        // Total RAC capacity across train coaches
        int trainRacCapacity = 0;
        for (Coach c : train.getCoaches()) {
            trainRacCapacity += c.getTotalRacCapacity();
        }
        if (trainRacCapacity == 0) {
            trainRacCapacity = 10; // Default buffer for testing if not set
        }

        if (currentRacCount < trainRacCapacity) {
            int nextRacNo = currentRacCount + 1;
            return new AllocationResult(BookingStatus.RAC, selectedCoach, null, BerthType.SIDE_LOWER, nextRacNo, 0);
        }

        // 6. WAITLIST ALLOCATION (WL)
        int currentWlCount = 0;
        for (Booking b : ActiveBookings) {
            if (b.getTrainNo() == train.getTrainNo() && b.getStatus() == BookingStatus.WAITING) {
                currentWlCount++;
            }
        }
        int nextWlNo = currentWlCount + 1;
        return new AllocationResult(BookingStatus.WAITING, selectedCoach, null, null, 0, nextWlNo);
    }

    // =========================================================================
    //  UPDATED BOOKING WORKFLOW (with Payment Gateway & Berth Preference)
    // =========================================================================
    public static void BookTicket(Scanner scanner, User user) {
        System.out.println("\n=== TICKET RESERVATION ===");
        System.out.print("Enter Source Station: ");
        String source = scanner.nextLine().trim();
        System.out.print("Enter Destination Station: ");
        String destination = scanner.nextLine().trim();
        List<Train> availableTrains = new ArrayList<>();

        for (Train t : TrainInventory) {
            List<String> route = t.getRouteStations();
            boolean crossSource = route.contains(source);
            boolean crossDestination = route.contains(destination);
            if (crossSource && crossDestination) {
                int si = route.indexOf(source);
                int sd = route.indexOf(destination);
                if (si < sd) {
                    availableTrains.add(t);
                    DisplayTrainInfo(t.getTrainNo());
                }
            }
        }

        if (availableTrains.isEmpty()) {
            System.out.println("No trains available for the given route.");
            return;
        }

        System.out.print("\nEnter Train Number to book: ");
        int choice = OnlyInteger(scanner);
        Train trainToBeTravelled = FindTrain(choice);
        if (trainToBeTravelled == null) {
            System.out.println("Invalid Train Number.");
            return;
        }

        if (trainToBeTravelled.getCoaches().isEmpty()) {
            System.out.println("No coaches configured on Train #" + trainToBeTravelled.getTrainNo() + ".");
            return;
        }

        // Step 1: Passenger Details
        System.out.println("\n--- Passenger Information ---");
        System.out.print("Enter Passenger Name (or press Enter for " + user.getName() + "): ");
        String passName = scanner.nextLine().trim();
        if (passName.isEmpty()) passName = user.getName();

        System.out.print("Enter Passenger Age: ");
        int passAge = OnlyInteger(scanner);

        System.out.println("Select Gender: 1. Female | 2. Male | 3. Other");
        int genChoice = OnlyInteger(scanner);
        String passGender = switch (genChoice) {
            case 1 -> "FEMALE";
            case 2 -> "MALE";
            default -> "OTHER";
        };

        // Step 2: Quota Selection
        System.out.println("\nSelect Quota:");
        System.out.println("1. General Quota (GN)");
        System.out.println("2. Ladies Quota (LD)");
        System.out.println("3. Senior Citizen / Lower Berth Quota (SS)");
        System.out.println("4. Divyang / Physically Challenged (HP)");
        System.out.println("5. Tatkal Quota (TQ)");
        System.out.print("Enter quota choice (1-5): ");
        int qChoice = OnlyInteger(scanner);
        QuotaType selectedQuota = switch (qChoice) {
            case 2 -> QuotaType.LADIES;
            case 3 -> QuotaType.SENIOR_CITIZEN;
            case 4 -> QuotaType.PHYSICALLY_CHALLENGED;
            case 5 -> QuotaType.TATKAL;
            default -> QuotaType.GENERAL;
        };

        // Step 3: Coach Class Selection
        DisplayCoaches(trainToBeTravelled);
        System.out.print("Enter Coach ID (e.g. S1, B1, A1): ");
        String coachIdInput = scanner.nextLine().trim();
        Coach selectedCoach = null;
        for (Coach c : trainToBeTravelled.getCoaches()) {
            if (c.getCoachId().equalsIgnoreCase(coachIdInput)) {
                selectedCoach = c;
                break;
            }
        }
        if (selectedCoach == null) {
            selectedCoach = trainToBeTravelled.getCoaches().get(0);
            System.out.println("Coach ID not found. Defaulting to Coach " + selectedCoach.getCoachId());
        }

        // Step 4: Berth Preference ONLY (No manual seat selection per railway standard)
        System.out.println("\nSelect Berth Preference (Subject to availability):");
        System.out.println("1. Lower Berth (LB)");
        System.out.println("2. Middle Berth (MB)");
        System.out.println("3. Upper Berth (UB)");
        System.out.println("4. Side Lower (SL)");
        System.out.println("5. Side Upper (SU)");
        System.out.println("6. No Preference");
        System.out.print("Enter choice (1-6): ");
        int bpChoice = OnlyInteger(scanner);
        BerthType preferredBerth = switch (bpChoice) {
            case 1 -> BerthType.LOWER;
            case 2 -> BerthType.MIDDLE;
            case 3 -> BerthType.UPPER;
            case 4 -> BerthType.SIDE_LOWER;
            case 5 -> BerthType.SIDE_UPPER;
            default -> null;
        };

        // Step 5: Fare Calculation
        double fare = trainToBeTravelled.getBaseFare();
        if (selectedQuota == QuotaType.TATKAL) {
            fare += 150.0; // Standard Tatkal surcharge
        }

        // Step 6: Payment Gateway Integration
        System.out.println("\nFare Summary: Rs. " + fare + " | Train #" + trainToBeTravelled.getTrainNo()
                + " (" + source + " -> " + destination + ")");
        boolean paymentSuccess = Payment.ProcessPayment(scanner, fare);
        if (!paymentSuccess) {
            System.out.println("Booking failed: Payment was not completed.");
            return;
        }

        // Step 7: Automated Seat Allocation Logic Execution
        AllocationResult result = allocateBerthOrQueue(trainToBeTravelled, selectedCoach, selectedQuota,
                preferredBerth, passAge, passGender);

        String pnr = GeneratePNR();
        Booking booking = new Booking(pnr, user, passName, passAge, passGender, source, destination, fare, result.status, trainToBeTravelled.getTrainNo());
        booking.setCoach(result.coach);
        booking.setSeat(result.seat);
        booking.setAllocatedBerth(result.berthType);
        booking.setRacNumber(result.racNo);
        booking.setWaitlistNumber(result.wlNo);

        user.addToMyBookings(booking);
        ActiveBookings.add(booking);
        trainToBeTravelled.setTrainBookings(booking);

        // Step 8: Confirmation Display
        System.out.println("\n=======================================================");
        System.out.println("            TICKET RESERVATION SUCCESSFUL!             ");
        System.out.println("=======================================================");
        System.out.println("PNR Number         : " + pnr);
        System.out.println("Passenger Name     : " + passName + " (Age: " + passAge + ", " + passGender + ")");
        System.out.println("Train No & Route   : #" + trainToBeTravelled.getTrainNo() + " (" + source + " -> " + destination + ")");
        System.out.println("Quota Booked       : " + selectedQuota);
        System.out.println("Booking Status     : " + result.status);

        if (result.status == BookingStatus.CONFIRMED) {
            System.out.println("Allocated Coach    : " + result.coach.getCoachId());
            System.out.println("Allocated Seat No  : " + result.seat.getSeatNo());
            System.out.println("Allocated Berth    : " + result.berthType);
            if (preferredBerth != null && result.berthType == preferredBerth) {
                System.out.println("Berth Preference   : " + preferredBerth + " [SATISFIED]");
            } else if (preferredBerth != null) {
                System.out.println("Berth Preference   : " + preferredBerth + " [Alternative Allotted]");
            }
        } else if (result.status == BookingStatus.RAC) {
            System.out.println("RAC Number         : RAC #" + result.racNo + " (Side Lower Shared Sitting)");
            System.out.println("Note               : You have confirmed sitting travel rights. Full berth will be allotted upon chart preparation if cancellations occur.");
        } else {
            System.out.println("Waitlist Number    : WL #" + result.wlNo);
            System.out.println("Note               : Your ticket is unconfirmed. If not confirmed at chart preparation, a 100% automatic refund will be credited.");
        }
        System.out.printf("Total Fare Paid    : Rs. %.2f%n", fare);
        System.out.println("=======================================================\n");
    }

    public static String GeneratePNR() {
        Random random = new Random();
        long pnr = (long)(random.nextDouble() * 9000000000L) + 1000000000L;
        return String.valueOf(pnr);
    }

    // =========================================================================
    //  PREPARE CHART LOGIC (Exactly like real-world Railway System)
    //  1. Re-evaluates vacant berths.
    //  2. Promotes RAC passengers to Confirmed Berths.
    //  3. Promotes Waitlist passengers to freed RAC slots.
    //  4. Auto-cancels remaining Waitlist tickets with 100% full refund.
    //  5. Locks chart and outputs comprehensive platform manifest.
    // =========================================================================
    public static void BookingsReport(int trainno) {
        Train train = null;
        for (Train t : TrainInventory) {
            if (t.getTrainNo() == trainno) {
                train = t;
                break;
            }
        }

        if (train == null) {
            System.out.println("Error: Train #" + trainno + " not found in inventory.");
            return;
        }

        System.out.println("\n==================================================================================================================");
        System.out.println("                         INDIAN RAILWAYS - OFFICIAL RESERVATION CHART MANIFEST                                    ");
        System.out.println("==================================================================================================================");
        System.out.println("Train No & Name  : #" + train.getTrainNo() + " (" + train.getSource() + " -> " + train.getDestination() + ")");
        System.out.println("Route Stations   : " + String.join(" -> ", train.getRouteStations()));
        System.out.println("Charting Status  : FINAL CHART PREPARED & LOCKED (Departure - 4 Hours)");
        System.out.println("Date of Charting : " + LocalDate.now());
        System.out.println("==================================================================================================================");

        // STEP 1: PROMOTE RAC PASSENGERS TO CONFIRMED BERTHS
        List<Booking> promotedRac = new ArrayList<>();
        for (Booking b : ActiveBookings) {
            if (b.getTrainNo() == trainno && b.getStatus() == BookingStatus.RAC) {
                // Find any vacant confirmed berth in train
                Seat freeSeat = null;
                Coach targetCoach = null;
                for (Coach c : train.getCoaches()) {
                    if (!c.getTotalAvailableSeats().isEmpty()) {
                        freeSeat = c.getTotalAvailableSeats().get(0);
                        targetCoach = c;
                        break;
                    }
                }
                if (freeSeat != null) {
                    freeSeat.setBookingstatus(BookingStatus.CONFIRMED);
                    targetCoach.removeTotalAvailableSeats(freeSeat);
                    targetCoach.addtoTotalConfirmedSeats(freeSeat);
                    b.setStatus(BookingStatus.CONFIRMED);
                    b.setCoach(targetCoach);
                    b.setSeat(freeSeat);
                    b.setAllocatedBerth(freeSeat.getBerthtype());
                    b.setRacNumber(0);
                    promotedRac.add(b);
                }
            }
        }

        // STEP 2: PROMOTE WAITLIST TO RAC
        List<Booking> promotedWl = new ArrayList<>();
        int currentRacCount = 0;
        for (Booking b : ActiveBookings) {
            if (b.getTrainNo() == trainno && b.getStatus() == BookingStatus.RAC) {
                currentRacCount++;
            }
        }
        int totalRacCap = 0;
        for (Coach c : train.getCoaches()) totalRacCap += c.getTotalRacCapacity();
        if (totalRacCap == 0) totalRacCap = 10;

        for (Booking b : ActiveBookings) {
            if (b.getTrainNo() == trainno && b.getStatus() == BookingStatus.WAITING) {
                if (currentRacCount < totalRacCap) {
                    currentRacCount++;
                    b.setStatus(BookingStatus.RAC);
                    b.setRacNumber(currentRacCount);
                    b.setWaitlistNumber(0);
                    b.setAllocatedBerth(BerthType.SIDE_LOWER);
                    promotedWl.add(b);
                }
            }
        }

        // STEP 3: AUTO-CANCEL REMAINING UNCONFIRMED WAITLIST PASSENGERS WITH 100% AUTO-REFUND
        List<Booking> refundedWl = new ArrayList<>();
        for (Booking b : ActiveBookings) {
            if (b.getTrainNo() == trainno && b.getStatus() == BookingStatus.WAITING) {
                b.setStatus(BookingStatus.CANCELLED);
                refundedWl.add(b);
                Payment.ProcessRefund(b.getpnrno(), b.getTotalFare());
            }
        }

        // Section 1: Chart Preparation Promotions & Upgrades
        System.out.println("\n[SECTION 1: RAC TO CONFIRMED BERTH PROMOTIONS]");
        if (promotedRac.isEmpty()) {
            System.out.println("  * No RAC passengers were eligible for promotion (no vacant berths available).");
        } else {
            System.out.printf("%-12s | %-20s | %-12s | %-10s | %-15s%n", "PNR", "PASSENGER", "COACH", "SEAT#", "BERTH");
            System.out.println("----------------------------------------------------------------------");
            for (Booking b : promotedRac) {
                System.out.printf("%-12s | %-20s | %-12s | %-10d | %-15s%n",
                        b.getpnrno(), b.getPassengerName(), b.getCoach().getCoachId(), b.getSeat().getSeatNo(), b.getAllocatedBerth());
            }
        }

        System.out.println("\n[SECTION 2: WAITLIST TO RAC PROMOTIONS]");
        if (promotedWl.isEmpty()) {
            System.out.println("  * No Waitlist passengers were promoted to RAC.");
        } else {
            System.out.printf("%-12s | %-20s | %-15s | %-20s%n", "PNR", "PASSENGER", "NEW STATUS", "BERTH TYPE");
            System.out.println("----------------------------------------------------------------------");
            for (Booking b : promotedWl) {
                System.out.printf("%-12s | %-20s | RAC #%-9d | %-20s%n",
                        b.getpnrno(), b.getPassengerName(), b.getRacNumber(), "SIDE_LOWER (Sitting)");
            }
        }

        System.out.println("\n[SECTION 3: DROPPED WAITLIST & 100% AUTO-REFUND LEDGER]");
        if (refundedWl.isEmpty()) {
            System.out.println("  * No unconfirmed waitlist passengers remained. Zero auto-refunds required.");
        } else {
            System.out.printf("%-12s | %-20s | %-15s | %-25s%n", "PNR", "PASSENGER", "REFUND (Rs)", "TRANSACTION STATUS");
            System.out.println("---------------------------------------------------------------------------------");
            double totalRefundAmt = 0.0;
            for (Booking b : refundedWl) {
                totalRefundAmt += b.getTotalFare();
                System.out.printf("%-12s | %-20s | Rs %-12.2f | %-25s%n",
                        b.getpnrno(), b.getPassengerName(), b.getTotalFare(), "100% AUTO-CREDITED");
            }
            System.out.println("---------------------------------------------------------------------------------");
            System.out.printf("Total Auto-Refunded Tickets: %d | Total Amount Reimbursed: Rs. %.2f%n",
                    refundedWl.size(), totalRefundAmt);
        }

        // Section 4: Coach-wise Seat Occupancy
        System.out.println("\n[SECTION 4: COACH-WISE OCCUPANCY & CAPACITY UTILIZATION]");
        System.out.printf("%-12s | %-18s | %-15s | %-15s | %-15s%n",
                "COACH ID", "COACH TYPE", "TOTAL SEATS", "CONFIRMED", "VACANT");
        System.out.println("---------------------------------------------------------------------------------");
        int grandTotal = 0, grandConf = 0, grandVacant = 0;
        for (Coach c : train.getCoaches()) {
            int conf = c.getTotalConfirmedSeats().size();
            int avail = c.getTotalAvailableSeats().size();
            int total = conf + avail;
            grandTotal += total;
            grandConf += conf;
            grandVacant += avail;
            System.out.printf("%-12s | %-18s | %-15d | %-15d | %-15d%n",
                    c.getCoachId(), c.getCoachType(), total, conf, avail);
        }
        System.out.println("---------------------------------------------------------------------------------");
        System.out.printf("TOTAL TRAIN CAPACITY: %d | CONFIRMED: %d | VACANT BERTHS RELEASED TO TTE: %d%n",
                grandTotal, grandConf, grandVacant);

        // Section 5: Official Platform Passenger Manifest
        System.out.println("\n[SECTION 5: OFFICIAL PLATFORM RESERVATION CHART (PASSENGER MANIFEST)]");
        List<Booking> manifestBookings = new ArrayList<>();
        for (Booking b : ActiveBookings) {
            if (b.getTrainNo() == trainno && (b.getStatus() == BookingStatus.CONFIRMED || b.getStatus() == BookingStatus.RAC)) {
                manifestBookings.add(b);
            }
        }

        if (manifestBookings.isEmpty()) {
            System.out.println("  * No confirmed or RAC passengers on this train.");
        } else {
            System.out.printf("%-4s | %-12s | %-20s | %-8s | %-8s | %-8s | %-15s | %-12s | %-20s%n",
                    "#", "PNR", "PASSENGER NAME", "AGE/GEN", "COACH", "SEAT#", "BERTH TYPE", "STATUS", "ROUTE");
            System.out.println("-----------------------------------------------------------------------------------------------------------------------");
            int idx = 1;
            for (Booking b : manifestBookings) {
                String ageGen = b.getPassengerAge() + "/" + (b.getPassengerGender() != null && b.getPassengerGender().startsWith("F") ? "F" : "M");
                String coachId = b.getCoach() != null ? b.getCoach().getCoachId() : "RAC";
                String seatNo = b.getSeat() != null ? String.valueOf(b.getSeat().getSeatNo()) : "RAC #" + b.getRacNumber();
                String berth = b.getAllocatedBerth() != null ? b.getAllocatedBerth().toString() : "SITTING";
                String routeStr = b.getSource() + " -> " + b.getDestination();
                System.out.printf("%-4d | %-12s | %-20s | %-8s | %-8s | %-8s | %-15s | %-12s | %-20s%n",
                        idx++, b.getpnrno(), b.getPassengerName(), ageGen, coachId, seatNo, berth, b.getStatus(), routeStr);
            }
        }

        System.out.println("==================================================================================================================");
        System.out.println("[OFFICIAL DISPATCH NOTICE]");
        System.out.println("  * Digital Chart transmission completed successfully to TTE Handheld Terminal (HHT).");
        System.out.println("  * Online and counter reservations are now officially LOCKED for Train #" + train.getTrainNo() + ".");
        System.out.printf("  * Remaining %d vacant berths are transferred to TTE on-board allotment.%n", grandVacant);
        System.out.println("==================================================================================================================\n");
    }

    // Overload for backwards compatibility
    public static void BookingsReport(Train train) {
        if (train != null) BookingsReport(train.getTrainNo());
    }
}
