package Services;

import Actors.Gender;
import Actors.Staff;
import Actors.TTE;
import Actors.User;
import Objects.BookingStatus;
import Objects.Train;

import java.util.Date;
import java.util.Scanner;

import static Actors.TTE.VerifyTickets;
import static Objects.Inventory.EditInventory;
import static Objects.Storage.*;
import static Objects.Train.DisplayTrainInventory;
import static Services.Booking.BookTicket;
import static Services.Booking.BookingsReport;
import static Services.InputValidators.*;
import static Services.OTPService.*;
import static Services.RegisterAndLogin.LoginStaff;
import static Services.RegisterAndLogin.RegisterStaff;
import static java.lang.Integer.parseInt;

public class PortalRunners {

    public static void Railway(Scanner scanner) {
        boolean runSystem = true;
        while (runSystem) {
            System.out.println("\n=========================================");
            System.out.println("      RAILWAY RESERVATION SYSTEM         ");
            System.out.println("=========================================");
            System.out.println("1. Staff Portal (Admin / Manager / TTE)");
            System.out.println("2. Passenger Portal");
            System.out.println("3. PNR Check with Guest Login");
            System.out.println("4. Exit System");
            System.out.print("Your choice (1-4): ");
            int choice = InputValidators.OnlyInteger(scanner);
            switch (choice) {
                case 1 -> StaffPortal(scanner);
                case 2 -> PassengerPortal(scanner);
                case 3 -> PortalRunners.GuestMenu(scanner);
                case 4 -> {
                    System.out.println("Thank you for using Railway Reservation System. Goodbye!");
                    runSystem = false;
                }
                default -> System.out.println("Invalid option. Please choose 1-4.");
            }
        }
    }

    public static void StaffPortal(Scanner scanner) {
        boolean run = true;
        while (run) {
            System.out.println("\n--- STAFF PORTAL ---");
            System.out.println("1. Login");
            System.out.println("2. Forgot Password");
            System.out.println("3. Back to Main Menu");
            System.out.print("Enter choice (1-3): ");
            int userInput = OnlyInteger(scanner);
            if (userInput == 1) {
                System.out.print("Enter Staff ID, Email or Phone: ");
                String userName = scanner.nextLine().trim();
                LoginStaff(scanner, userName);
            } else if (userInput == 2) {
                System.out.print("Enter Recovery Email or Phone: ");
                String recovery = scanner.nextLine().trim();
                Staff resetId = null;
                for (Staff s : StaffDatabase) {
                    if ((s.getEmail() != null && s.getEmail().equalsIgnoreCase(recovery))
                            || (s.getPhoneNo() != null && s.getPhoneNo().equals(recovery))) {
                        resetId = s;
                        ResetPassword(scanner, recovery, resetId);
                        break;
                    }
                }
                if (resetId == null) {
                    System.out.println("Staff account not found for: " + recovery);
                }
            } else {
                run = false;
            }
        }
    }

    public static void SuperAdminPortal(Scanner scanner, Staff staff) {
        boolean run = true;
        while (run) {
            System.out.println("\n--- SUPER ADMIN DASHBOARD ---");
            System.out.println("1. Register New Staff");
            System.out.println("2. List of Current Staff");
            System.out.println("3. Remove Staff");
            System.out.println("4. View Current Train Inventory");
            System.out.println("5. Edit Inventory");
            System.out.println("6. Prepare Chart & View Report");
            System.out.println("7. Logout");
            System.out.print("Enter your choice (1-7): ");
            int choice = OnlyInteger(scanner);
            switch (choice) {
                case 1 -> RegisterStaff(scanner);
                case 2 -> {
                    System.out.println("\n ACTIVE STAFF MEMBERS:");
                    System.out.printf("%-15s | %-20s | %-15s | %-15s | %-25s | %-15s%n",
                            "STAFF ID", "STAFF NAME", "ROLE", "PHONE", "EMAIL", "TRAIN NO (TTE)");
                    System.out.println("----------------------------------------------------------------------------------------------------------------");
                    for (Staff s : StaffDatabase) {
                        String train = (s instanceof TTE tte) ? String.valueOf(tte.getAssignedTrainNo()) : "N/A";
                        System.out.printf("%-15s | %-20s | %-15s | %-15s | %-25s | %-15s%n",
                                s.getStaffId(), s.getName(), s.getRole(), s.getPhoneNo(), s.getEmail(), train);
                    }
                }
                case 3 -> {
                    System.out.print("Enter Staff ID to remove: ");
                    String id = scanner.nextLine().trim();
                    Staff remove = null;
                    for (Staff ss : StaffDatabase) {
                        if (ss.getStaffId().equalsIgnoreCase(id)) {
                            remove = ss;
                            break;
                        }
                    }
                    if (remove == null) {
                        System.out.println("Staff ID not found.");
                    } else if (remove == staff) {
                        System.out.println("Cannot remove currently logged-in Super Admin.");
                    } else {
                        StaffDatabase.remove(remove);
                        System.out.println("Staff member " + remove.getName() + " [" + remove.getStaffId() + "] removed successfully.");
                    }
                }
                case 4 -> DisplayTrainInventory(TrainInventory);
                case 5 -> EditInventory(scanner, staff);
                case 6 -> {
                    System.out.print("Enter Train Number to Prepare Chart: ");
                    int trainNo = OnlyInteger(scanner);
                    BookingsReport(trainNo);
                }
                case 7 -> {
                    System.out.println("Logged out from Super Admin Dashboard.");
                    run = false;
                }
                default -> System.out.println("Invalid option. Please choose 1-7.");
            }
        }
    }

    public static void InventoryManagerPortal(Scanner scanner, Staff staff) {
        boolean run = true;
        while (run) {
            System.out.println("\n--- INVENTORY MANAGER DASHBOARD ---");
            System.out.println("1. View Complete Train Inventory");
            System.out.println("2. Edit Inventory (Add/Edit/Remove Train)");
            System.out.println("3. Prepare Chart & View Report");
            System.out.println("4. Logout");
            System.out.print("Enter choice (1-4): ");
            int ch = OnlyInteger(scanner);
            switch (ch) {
                case 1 -> DisplayTrainInventory(TrainInventory);
                case 2 -> EditInventory(scanner, staff);
                case 3 -> {
                    System.out.print("Enter Train Number to Prepare Chart: ");
                    int trainNo = OnlyInteger(scanner);
                    BookingsReport(trainNo);
                }
                case 4 -> {
                    System.out.println("Logged out from Manager Dashboard.");
                    run = false;
                }
                default -> System.out.println("Invalid choice. Please select 1-4.");
            }
        }
    }

    public static void TTEPortal(Scanner scanner) {
        boolean run = true;
        while (run) {
            System.out.println("\n--- TTE DASHBOARD ---");
            System.out.println("1. Verify Ticket by PNR");
            System.out.println("2. View Prepared Chart Manifest");
            System.out.println("3. Logout");
            System.out.print("Enter your choice (1-3): ");
            int choice = OnlyInteger(scanner);

            switch (choice) {
                case 1 -> VerifyTickets(scanner);
                case 2 -> {
                    System.out.print("Enter Train Number to view chart: ");
                    int tNo = OnlyInteger(scanner);
                    BookingsReport(tNo);
                }
                case 3 -> {
                    System.out.println("Logged out from TTE Dashboard.");
                    run = false;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    public static void PassengerPortal(Scanner scanner) {
        boolean run = true;
        while (run) {
            System.out.println("\n--- PASSENGER PORTAL ---");
            System.out.println("1. Login");
            System.out.println("2. Register");
            System.out.println("3. Back to Main Menu");
            System.out.print("Enter choice (1-3): ");
            int choice = OnlyInteger(scanner);
            switch (choice) {
                case 1 -> {
                    System.out.print("Enter Registered Phone Number or Email: ");
                    String userLogin = scanner.nextLine().trim();
                    User current = null;
                    for (User u : UserDB) {
                        if ((u.getPhoneNo() != null && u.getPhoneNo().equals(userLogin))
                                || (u.getEmail() != null && u.getEmail().equalsIgnoreCase(userLogin))) {
                            current = u;
                            break;
                        }
                    }
                    if (current == null) {
                        System.out.println("User not found with phone/email: " + userLogin);
                        break;
                    }
                    System.out.print("Enter Password: ");
                    String pass = scanner.nextLine().trim();
                    if (current.getPassword().equals(pass)) {
                        System.out.println("\nLogin Successful! Welcome, " + current.getName() + ".");
                        PassengerMenu(scanner, current);
                    } else {
                        System.out.println("Access Denied: Incorrect password.");
                    }
                }
                case 2 -> {
                    String name = readValidName(scanner, "Enter Full Name: ");
                    String phoneNo = ReadValidPhoneNumber(scanner, "Enter Phone Number (10 digits): ");
                    VerifyPhone(scanner, phoneNo);
                    String email = ReadValidEmail(scanner, "Enter Email: ");
                    VerifyEmail(scanner, email);
                    String pass = ReadValidPassword(scanner, "Set Password (min 6 chars): ");
                    Date dob = Readvaliddob(scanner, "Enter Date of Birth (dd-mm-yyyy): ");
                    Gender gender = ReadValidGender(scanner);
                    String aadharNo = ReadValidAadhar(scanner, "Enter 12-digit Aadhaar Number: ");
                    User user = new User(name, phoneNo, email, pass, dob, gender, aadharNo);
                    UserDB.add(user);
                    System.out.println("Registration Successful! You can now log in.");
                }
                case 3 -> run = false;
                default -> System.out.println("Invalid option. Please choose 1-3.");
            }
        }
    }

    public static void PassengerMenu(Scanner scanner, User user) {
        boolean inMenu = true;
        while (inMenu) {
            System.out.println("\n--- PASSENGER DASHBOARD (" + user.getName() + ") ---");
            System.out.println("1. Book Ticket");
            System.out.println("2. View Booking History / PNR Status");
            System.out.println("3. Cancel Ticket");
            System.out.println("4. Logout");
            System.out.print("Enter choice (1-4): ");
            int choice = OnlyInteger(scanner);

            switch (choice) {
                case 1 -> BookTicket(scanner, user);
                case 2 -> {
                    if (user.getMyBookings().isEmpty()) {
                        System.out.println("You have no booking history.");
                    } else {
                        System.out.printf("%n%-12s | %-18s | %-15s | %-10s | %-15s | %-12s%n",
                                "PNR", "PASSENGER", "ROUTE", "COACH", "SEAT/BERTH", "STATUS");
                        System.out.println("--------------------------------------------------------------------------------------------");
                        for (Booking b : user.getMyBookings()) {
                            String coachStr = b.getCoach() != null ? b.getCoach().getCoachId() : "N/A";
                            String seatBerth;
                            if (b.getStatus() == BookingStatus.CONFIRMED && b.getSeat() != null) {
                                seatBerth = "Seat #" + b.getSeat().getSeatNo() + " (" + b.getAllocatedBerth() + ")";
                            } else if (b.getStatus() == BookingStatus.RAC) {
                                seatBerth = "RAC #" + b.getRacNumber() + " (SL)";
                            } else if (b.getStatus() == BookingStatus.WAITING) {
                                seatBerth = "WL #" + b.getWaitlistNumber();
                            } else {
                                seatBerth = "CANCELLED";
                            }
                            System.out.printf("%-12s | %-18s | %-15s | %-10s | %-15s | %-12s%n",
                                    b.getpnrno(), b.getPassengerName(), b.getSource() + "->" + b.getDestination(),
                                    coachStr, seatBerth, b.getStatus());
                        }
                    }
                }
                case 3 -> {
                    System.out.print("Enter 10-digit PNR Number to cancel: ");
                    String pnr = scanner.nextLine().trim();
                    Booking found = null;
                    for (Booking b : ActiveBookings) {
                        if (b.getpnrno().equalsIgnoreCase(pnr)) {
                            found = b;
                            break;
                        }
                    }
                    if (found == null) {
                        System.out.println("Error: Booking with PNR " + pnr + " not found.");
                    } else if (found.getStatus() == BookingStatus.CANCELLED) {
                        System.out.println("Notice: This ticket has already been cancelled.");
                    } else {
                        found.setStatus(BookingStatus.CANCELLED);
                        // Release confirmed seat back to available pool
                        if (found.getSeat() != null && found.getCoach() != null) {
                            found.getSeat().setBookingstatus(BookingStatus.AVAILABLE);
                            found.getCoach().removeTotalConfirmedSeats(found.getSeat());
                            found.getCoach().addtoTotalAvailableSeats(found.getSeat());
                        }
                        System.out.println("Booking " + pnr + " has been CANCELLED successfully.");
                        Payment.ProcessRefund(pnr, found.getTotalFare());
                    }
                }
                case 4 -> {
                    System.out.println("Logged out from Passenger Dashboard.");
                    inMenu = false;
                }
                default -> System.out.println("Invalid option. Please choose 1-4.");
            }
        }
    }

    public static void GuestMenu(Scanner scanner) {
        System.out.print("Enter 10-digit PNR Number to check: ");
        String pnr = scanner.nextLine().trim();
        Booking found = null;
        for (Booking b : ActiveBookings) {
            if (b.getpnrno().equalsIgnoreCase(pnr)) {
                found = b;
                break;
            }
        }
        if (found == null) {
            System.out.println("PNR " + pnr + " not found in system.");
        } else {
            System.out.println("\n=== PNR STATUS ENQUIRY ===");
            System.out.println("PNR Number       : " + found.getpnrno());
            System.out.println("Passenger Name   : " + found.getPassengerName());
            System.out.println("Journey Route    : " + found.getSource() + " -> " + found.getDestination());
            System.out.println("Booking Status   : " + found.getStatus());
            if (found.getStatus() == BookingStatus.CONFIRMED && found.getSeat() != null) {
                System.out.println("Coach & Seat     : Coach " + found.getCoach().getCoachId() + ", Seat #"
                        + found.getSeat().getSeatNo() + " [" + found.getAllocatedBerth() + "]");
            } else if (found.getStatus() == BookingStatus.RAC) {
                System.out.println("RAC Position     : RAC #" + found.getRacNumber() + " (Side Lower Sitting)");
            } else if (found.getStatus() == BookingStatus.WAITING) {
                System.out.println("Waitlist Position: WL #" + found.getWaitlistNumber());
            }
            System.out.println("TTE Verification : " + found.getTTECheck());
            System.out.println("==========================\n");
        }
    }
}
