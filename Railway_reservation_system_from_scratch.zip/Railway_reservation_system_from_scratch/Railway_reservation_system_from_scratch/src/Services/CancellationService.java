package Services;

import Enums.BookingStatus;
import Objects.Coach;
import Objects.Seat;
import Objects.SeatInventory;
import Objects.Train;

import java.util.List;
import java.util.Scanner;

import static Objects.Storage.ActiveBookings;
import static Services.InputValidators.OnlyInteger;

public class CancellationService {

    /**
     * Interactive cancellation workflow:
     * Asks user for PNR, displays all passengers in that booking,
     * allows selecting which passenger(s) to cancel, and computes/displays
     * the accurate refund amount per passenger.
     */
    public static void CancelTicketWorkflow(Scanner scanner) {
        System.out.print("Enter PNR to cancel: ");
        String pnr = scanner.nextLine().trim();

        BookingService booking = null;
        for (BookingService b : ActiveBookings) {
            if (b.getpnrno().equals(pnr)) {
                booking = b;
                break;
            }
        }

        if (booking == null) {
            System.out.println("PNR not found!");
            return;
        }

        if (booking.getStatus() == BookingStatus.CANCELLED) {
            System.out.println("All tickets under PNR " + pnr + " are already cancelled.");
            return;
        }

        List<Passenger> passengers = booking.getPassengerlist();
        if (passengers == null || passengers.isEmpty()) {
            System.out.println("No passengers found in this booking.");
            return;
        }

        boolean anyActive = passengers.stream().anyMatch(p -> p.getBookingStatus() != BookingStatus.CANCELLED);
        if (!anyActive) {
            System.out.println("All passengers under this booking are already cancelled.");
            booking.setStatus(BookingStatus.CANCELLED);
            return;
        }

        while (true) {
            System.out.println("\n====================== PASSENGER LIST (PNR: " + pnr + ") ======================");
            if (booking.getBookedTrain() != null) {
                System.out.println("Train: " + booking.getBookedTrain().getTrainNo() + " | Journey: " + booking.getSource() + " -> " + booking.getDestination());
            }
            System.out.println("-------------------------------------------------------------------------------");
            System.out.printf("%-4s | %-20s | %-12s | %-10s | %-12s | %-15s%n",
                    "#", "NAME", "STATUS", "COACH", "SEAT/WL", "QUOTA");
            System.out.println("-------------------------------------------------------------------------------");

            for (int i = 0; i < passengers.size(); i++) {
                Passenger p = passengers.get(i);
                String seatInfo = "-";
                if (p.getBookingStatus() == BookingStatus.CONFIRMED) {
                    seatInfo = "Seat: " + p.getSeatno();
                } else if (p.getBookingStatus() == BookingStatus.RAC) {
                    seatInfo = "RAC";
                } else if (p.getBookingStatus() == BookingStatus.WAITLIST) {
                    seatInfo = "WL: " + p.getWaitListNo();
                } else if (p.getBookingStatus() == BookingStatus.CANCELLED) {
                    seatInfo = "CANCELLED";
                }
                String coachInfo = (p.getCoachid() != null && !p.getCoachid().isEmpty()) ? p.getCoachid() : "-";
                System.out.printf("%-4d | %-20s | %-12s | %-10s | %-12s | %-15s%n",
                        (i + 1), p.getPassengerName(), p.getBookingStatus(), coachInfo, seatInfo, p.getQuotaType());
            }
            System.out.println("-------------------------------------------------------------------------------");

            System.out.println("\nCancellation Options:");
            System.out.println("1. Cancel a specific passenger");
            System.out.println("2. Cancel all active passengers");
            System.out.println("3. Back to Dashboard");
            System.out.print("Enter your choice: ");
            int option = OnlyInteger(scanner);

            double farePerPassenger = booking.getTotalFare() / passengers.size();

            if (option == 1) {
                System.out.print("Enter passenger number to cancel (1 to " + passengers.size() + "): ");
                int choice = OnlyInteger(scanner);
                if (choice < 1 || choice > passengers.size()) {
                    System.out.println("Invalid passenger selection!");
                    continue;
                }

                Passenger selectedPassenger = passengers.get(choice - 1);
                if (selectedPassenger.getBookingStatus() == BookingStatus.CANCELLED) {
                    System.out.println("Passenger " + selectedPassenger.getPassengerName() + " is already cancelled!");
                    continue;
                }

                System.out.println("\nCancelling passenger: " + selectedPassenger.getPassengerName() + "...");
                boolean success = cancelPassenger(booking, selectedPassenger);
                if (success) {
                    Payment.Refund(selectedPassenger, farePerPassenger);
                } else {
                    System.out.println("Failed to cancel passenger.");
                }

                boolean stillActive = passengers.stream().anyMatch(p -> p.getBookingStatus() != BookingStatus.CANCELLED);
                if (!stillActive) {
                    System.out.println("\nAll passengers on this booking are now cancelled.");
                    booking.setStatus(BookingStatus.CANCELLED);
                    break;
                }

            } else if (option == 2) {
                System.out.println("\nCancelling all remaining active passengers...");
                double totalRefund = 0.0;
                int cancelledCount = 0;
                for (Passenger p : passengers) {
                    if (p.getBookingStatus() != BookingStatus.CANCELLED) {
                        boolean success = cancelPassenger(booking, p);
                        if (success) {
                            totalRefund += Payment.Refund(p, farePerPassenger);
                            cancelledCount++;
                        }
                    }
                }
                updateBookingStatus(booking);
                System.out.printf("\nSuccessfully cancelled %d passenger(s). Total Refund: Rs. %.2f%n", cancelledCount, totalRefund);
                break;

            } else if (option == 3) {
                System.out.println("Returning to menu...");
                break;
            } else {
                System.out.println("Invalid option! Please enter 1, 2, or 3.");
            }
        }
    }

    public static boolean cancelPassenger(String pnr, String passengerName) {
        BookingService booking = null;
        for (BookingService b : ActiveBookings) {
            if (b.getpnrno().equals(pnr)) {
                booking = b;
                break;
            }
        }
        if (booking == null) {
            System.out.println("PNR not found.");
            return false;
        }

        Passenger passenger = null;
        for (Passenger p : booking.getPassengerlist()) {
            if (p.getPassengerName().equalsIgnoreCase(passengerName) && p.getBookingStatus() != BookingStatus.CANCELLED) {
                passenger = p;
                break;
            }
        }
        if (passenger == null) {
            System.out.println("Active passenger not found.");
            return false;
        }

        return cancelPassenger(booking, passenger);
    }

    public static boolean cancelPassenger(BookingService booking, Passenger passenger) {
        Train train = booking.getBookedTrain();
        if (train == null) {
            return false;
        }

        Coach coach = null;
        if (passenger.getCoachid() != null) {
            for (Coach c : train.GetCoaches()) {
                if (c.getCoachId().equalsIgnoreCase(passenger.getCoachid())) {
                    coach = c;
                    break;
                }
            }
        }
        if (coach == null && passenger.getCoachType() != null) {
            for (Coach c : train.GetCoaches()) {
                if (c.getCoachType() == passenger.getCoachType()) {
                    coach = c;
                    break;
                }
            }
        }
        if (coach == null && !train.GetCoaches().isEmpty()) {
            coach = train.GetCoaches().get(0);
        }

        if (coach == null) {
            return false;
        }

        SeatInventory inventory = coach.getSeatInventory();
        BookingStatus previousStatus = passenger.getBookingStatus();

        switch (previousStatus) {
            case CONFIRMED -> {
                Seat releasedSeat = null;
                for (Seat seat : coach.getTotalConfirmedSeats()) {
                    if (seat.getSeatNo() == passenger.getSeatno()) {
                        releasedSeat = seat;
                        break;
                    }
                }
                if (releasedSeat != null) {
                    promotePassengers(releasedSeat, coach, inventory);
                }
            }
            case RAC -> {
                inventory.removeRacPassenger(passenger);
                promoteWaitingToRAC(inventory);
            }
            case WAITLIST -> {
                inventory.removeWaitingPassenger(passenger);
            }
            default -> {
                System.out.println("Cannot cancel passenger with status: " + previousStatus);
                return false;
            }
        }

        passenger.setBookingStatus(BookingStatus.CANCELLED);
        passenger.setSeatno(0);
        passenger.setWaitListNo(0);

        updateBookingStatus(booking);
        System.out.println(passenger.getPassengerName() + " has been cancelled.");
        return true;
    }

    private static void promotePassengers(Seat releasedSeat, Coach coach, SeatInventory inventory) {
        Passenger racPassenger = inventory.removeFirstRacPassenger();
        if (racPassenger == null) {
            coach.removeFromTotalConfirmedSeats(releasedSeat);
            releasedSeat.setBookingstatus(BookingStatus.AVAILABLE);
            inventory.addAvailableSeat(releasedSeat);
            return;
        }
        releasedSeat.setBookingstatus(BookingStatus.CONFIRMED);
        racPassenger.setBookingStatus(BookingStatus.CONFIRMED);
        racPassenger.setSeatno(releasedSeat.getSeatNo());
        racPassenger.setCoachid(coach.getCoachId());
        racPassenger.setCoachType(coach.getCoachType());
        racPassenger.setWaitListNo(0);
        System.out.println(racPassenger.getPassengerName() + " promoted from RAC to CONFIRMED (Seat: " + releasedSeat.getSeatNo() + " in Coach " + coach.getCoachId() + ").");
        promoteWaitingToRAC(inventory);
    }

    private static void promoteWaitingToRAC(SeatInventory inventory) {
        Passenger waitingPassenger = inventory.removeFirstWaitingPassenger();
        if (waitingPassenger == null) {
            return;
        }
        inventory.addRacPassenger(waitingPassenger);
        System.out.println(waitingPassenger.getPassengerName() + " promoted from WAITLIST to RAC.");
    }

    public static void updateBookingStatus(BookingService booking) {
        boolean confirmed = false;
        boolean rac = false;
        boolean waiting = false;
        for (Passenger p : booking.getPassengerlist()) {
            switch (p.getBookingStatus()) {
                case CONFIRMED -> confirmed = true;
                case RAC -> rac = true;
                case WAITLIST -> waiting = true;
                default -> {}
            }
        }
        if (confirmed) {
            booking.setStatus(BookingStatus.CONFIRMED);
        } else if (rac) {
            booking.setStatus(BookingStatus.RAC);
        } else if (waiting) {
            booking.setStatus(BookingStatus.WAITLIST);
        } else {
            booking.setStatus(BookingStatus.CANCELLED);
        }
    }
}
