package Services;

public enum TTECheckStatus {
    VERIFIED,
    YET_TO_VERIFY,
    MARK_NO_SHOW,
    UPGRADED
}