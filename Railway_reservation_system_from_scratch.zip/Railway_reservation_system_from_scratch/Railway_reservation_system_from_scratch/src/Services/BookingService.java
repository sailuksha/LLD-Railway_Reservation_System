package Services;
import Actors.User;
import Enums.*;
import Objects.*;
import java.util.*;
import java.time.LocalDate;
import static Objects.Storage.ActiveBookings;
import static Objects.Storage.TrainInventory;
import static Objects.Train.DisplayTrainInfo;
import static Objects.Train.FindTrain;
import static Services.InputValidators.*;
import static Services.Payment.ProcessPayment;

public class BookingService {
    private String pnrNo;
    private List<Passenger> Passengerlist;
    private User user;
    private String source;
    private String destination;
    private QuotaType quotaType;
    private double totalFare;
    private LocalDate bookingDate;
    private Train bookedTrain;
    private BookingStatus status;
    private TTECheckStatus TTECheck;
//    private CoachType coachType;
    private BerthType berthType;
    public BookingService(String pnrNo, List<Passenger> passengers, String source, String destination, QuotaType quotaType, double totalFare, BookingStatus status) {
        this.pnrNo = pnrNo;
        this.Passengerlist = passengers;
        this.source = source;
        this.destination = destination;
        this.quotaType = quotaType;
        this.totalFare = totalFare;
        this.bookingDate = LocalDate.now();
        this.status = status;
        this.TTECheck = TTECheckStatus.YET_TO_VERIFY;
    }
    public String getpnrno() {
        return pnrNo;
    }
    public Train getBookedTrain() {
        return bookedTrain;
    }
    public void setBookedTrain(Train bookedTrain) {
        this.bookedTrain = bookedTrain;
    }
    public TTECheckStatus getTTECheck() {
        return TTECheck;
    }
    public QuotaType getQuotaType() {
        return quotaType;
    }
    public BerthType getBerthType() {
        return berthType;
    }
    public double getTotalFare() {
        return totalFare;
    }
    public BookingStatus getStatus() {
        return status;
    }
    public List<Passenger> getPassengerlist() {
        return Passengerlist;
    }
    public String getSource() {
        return source;
    }
    public String getDestination() {
        return destination;
    }

    public void setUser(User user) {
        this.user = user;
    }
    public void setTTECheck(TTECheckStatus TTECheck) {
        this.TTECheck = TTECheck;
    }
    public void setStatus(BookingStatus status) {
        this.status = status;
    }
    public static String GeneratePNR() {
        Random random = new Random();
        return String.valueOf( random.nextLong(999999999L+1000000000L));
    }

    public static void BookTicket(Scanner scanner, User user) {
        System.out.println("Enter source:");
        String source = scanner.nextLine().trim();
        System.out.println("Enter destination:");
        String destination = scanner.nextLine().trim();
        List<Train> availableTrains = new ArrayList<>();
        int si = -1;
        int di = -1;
        for (Train train : TrainInventory) {
            List<String> route = train.getRouteStations();
            for (int i = 0; i < route.size(); i++) {
                if (route.get(i).equalsIgnoreCase(source)) {
                    si = i;
                }
                if (route.get(i).equalsIgnoreCase(destination)) {
                   di = i;
                }
            }
            if (si != -1 && di != -1 && si < di) {
                availableTrains.add(train);
                DisplayTrainInfo(train.getTrainNo());
            }
        }
        if (availableTrains.isEmpty()) {
            System.out.println("No trains available.");
            return;
        }
        System.out.println("Enter train number:");
        int trainNo = OnlyInteger(scanner);
        Train selectedTrain = FindTrain(trainNo);
        if (selectedTrain == null ) {
            System.out.println("Invalid train selection.");
            return;
        }
        int stationsTravelled = di - si;
        System.out.println("Select Quota:\n" + "1. Tatkal\n" + "2. Ladies\n" + "3. Senior Citizen\n" + "4. Physically Challenged\n" + "5. General");
        int quotaChoice = OnlyInteger(scanner);
        QuotaType quotaType = switch (quotaChoice) {
            case 1 -> QuotaType.TATKAL;
            case 2 -> QuotaType.LADIES;
            case 3 -> QuotaType.SENIOR_CITIZEN;
            case 4 -> QuotaType.PHYSICALLY_CHALLENGED;
            case 5 -> QuotaType.GENERAL;
            default -> null;
        };
        if (quotaType == null) {
            System.out.println("Invalid quota selection.");
            return;
        }
        Coach selectedCoach = selectedTrain.HoldSeatInCoach(selectedTrain, scanner,quotaType);
        if (selectedCoach == null) {
            System.out.println("No suitable coach available.");
            return;
        }

        System.out.println("Enter number of passengers:");
        int passengerCount = OnlyInteger(scanner);
        if (passengerCount <= 0) {
            System.out.println("Invalid passenger count.");
            return;
        }
        String pnr = GeneratePNR();
        List<Passenger> passengers = new ArrayList<>();
        for (int i = 1; i <= passengerCount; i++) {
            System.out.println("Enter details of passenger " + i);
            String name = readValidName(scanner, "Enter name as it is in Aadhaar: ");
            LocalDate dob = Readvaliddob(scanner, "Enter DOB (dd-mm-yyyy): ");
            System.out.println("Select gender:");
            Gender gender = ReadValidGender(scanner);
            BerthType berthType = getBerthPreference(scanner,selectedCoach.getCoachType());
            Passenger passenger = new Passenger(pnr, name, dob, gender, quotaType, berthType, BookingStatus.HOLD, TTECheckStatus.YET_TO_VERIFY);
            passenger.setCoachType(selectedCoach.getCoachType());
            passengers.add(passenger);
        }
        selectedTrain.addPassengerList(passengers);
        Passenger.AssignSeats(selectedTrain,passengers);
        boolean allwaitlisted = passengers.stream().allMatch(p -> p.getBookingStatus() == BookingStatus.WAITLIST);
        if (allwaitlisted) {
            selectedTrain.getPassengerList().removeAll(passengers);
            System.out.println("No available seats you will be waitlisted");
            return;
        }
        double farePerPassenger =selectedTrain.getBaseFare() * stationsTravelled;
        double totalFare = farePerPassenger * passengerCount;
        System.out.println("Fare per passenger: " + farePerPassenger);
        System.out.println("Total fare: " + totalFare);
        boolean PaymentSuccess=ProcessPayment(totalFare);
        if (!PaymentSuccess){
            selectedTrain.getPassengerList().removeAll(passengers);
            for (Passenger p : passengers){
                if(p.getBookingStatus()==BookingStatus.CONFIRMED){
                    Coach coach=null;
                    for (Coach c : selectedTrain.GetCoaches()){
                        if (c.getCoachId().equals(p.getCoachid())){
                            coach=c;
                            break;
                        }
                    }
                    if (coach!=null){
                        for (Seat s: coach.getTotalConfirmedSeats()){
                            if (s.getSeatNo()==p.getSeatno()){
                                coach.removeFromTotalConfirmedSeats(s);
                                break;
                            }
                        }

                    }
                }else if (p.getBookingStatus()==BookingStatus.RAC){
                    for (Coach c : selectedTrain.GetCoaches()){
                        c.getSeatInventory().removeRacPassenger(p);
                    }
                }else if (p.getBookingStatus()==BookingStatus.WAITLIST){
                    for (Coach c : selectedTrain.GetCoaches()){
                        c.getSeatInventory().removeWaitingPassenger(p);
                    }
                }
            }
            System.out.println("Ticket booking stopped ,payment failed");
            return;
        }
        BookingStatus bookingStatus = getOverallBookingStatus(passengers);
        BookingService booking = new BookingService(pnr, passengers, source, destination, quotaType, totalFare, bookingStatus);
        booking.setBookedTrain(selectedTrain);
        booking.setUser(user);
        user.addToMyBookings(booking);
        ActiveBookings.add(booking);
        selectedTrain.setTrainBookings(booking);
        System.out.println(" BOOKING DETAILS :");
        System.out.println("PNR: " + pnr);
        System.out.println("Train: " + selectedTrain.getTrainNo());
        System.out.println("Source: " + source);
        System.out.println("Destination: " + destination);
        System.out.println("Total Fare: " + totalFare);
        System.out.println("\nPassenger allocation:");
        for (Passenger p : passengers) {System.out.println("PNR :"+p.getPnr()+"Name : "+p.getPassengerName()+ " | Status: " + p.getBookingStatus() + " | Coach: " + p.getCoachid() + " | Seat: " + p.getSeatno() );}
        System.out.println("Ticket booking completed!");
    }
    private static BerthType getBerthPreference(Scanner scanner, CoachType coachType) {
        if (coachType == CoachType.EXECUTIVE_CHAIR_CAR || coachType == CoachType.AC_CHAIR_CAR) {
            return BerthType.CHAIR_CAR;
        }
        if (coachType == CoachType.AC_FIRST) {
            System.out.println("Select berth:\n1. Lower\n2. Upper");
            return switch (OnlyInteger(scanner)) {
                case 1 -> BerthType.LOWER;
                case 2 -> BerthType.UPPER;
                default -> BerthType.LOWER;
            };
        }
        if (coachType == CoachType.AC_2TIER) {
            System.out.println("Select berth:\n" + "1. Lower\n" + "2. Upper\n" + "3. Side Lower\n" + "4. Side Upper");
            return switch (OnlyInteger(scanner)) {
                case 1 -> BerthType.LOWER;
                case 2 -> BerthType.UPPER;
                case 3 -> BerthType.SIDE_LOWER;
                case 4 -> BerthType.SIDE_UPPER;
                default -> BerthType.LOWER;
            };
        }
        System.out.println("Select berth:\n" + "1. Lower\n" + "2. Middle\n" + "3. Upper\n" + "4. Side Lower\n" + "5. Side Upper");
        return switch (OnlyInteger(scanner)) {
            case 1 -> BerthType.LOWER;
            case 2 -> BerthType.MIDDLE;
            case 3 -> BerthType.UPPER;
            case 4 -> BerthType.SIDE_LOWER;
            case 5 -> BerthType.SIDE_UPPER;
            default -> BerthType.LOWER;
        };
    }
    private static BookingStatus getOverallBookingStatus(List<Passenger> passengers) {
        boolean confirmed = false;
        boolean rac = false;
        boolean waiting = false;
        for (Passenger p : passengers) {
            switch (p.getBookingStatus()) {
                case CONFIRMED -> confirmed = true;
                case RAC -> rac = true;
                case WAITLIST -> waiting = true;
                default -> {
                }
            }
        }
        if (confirmed) {
            return BookingStatus.CONFIRMED;
        }
        if (rac) {
            return BookingStatus.RAC;
        }
        if (waiting) {
            return BookingStatus.WAITLIST;
        }
        return BookingStatus.CANCELLED;
    }
}