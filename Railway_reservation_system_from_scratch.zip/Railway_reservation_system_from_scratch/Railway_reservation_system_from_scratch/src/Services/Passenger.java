package Services;
import Enums.*;
import Objects.*;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import static Services.InputValidators.OnlyInteger;
public class Passenger {

    private String pnr;
    private int Seatno;
    private CoachType coachType;
    private String coachid;
    private String PassengerName;
    private LocalDate dob;
    private Gender gender;
    private QuotaType quotaType;
    private BerthType Berthpreferred;
    private BookingStatus bookingStatus;
    private TTECheckStatus tteCheckStatus;
    private int WaitListNo;

    public Passenger(String pnr, String PassengerName, LocalDate dob, Gender gender, QuotaType quotaType, BerthType berthpreferred, BookingStatus bookingStatus, TTECheckStatus tteCheckStatus) {
        this.pnr = pnr;
        this.PassengerName = PassengerName;
        this.dob = dob;
        this.gender = gender;
        this.quotaType = quotaType;
        this.Berthpreferred = berthpreferred;
        this.bookingStatus = bookingStatus;
        this.tteCheckStatus = tteCheckStatus;
    }

    public String getCoachid() {
        return coachid;
    }

    public void setCoachid(String coachid) {
        this.coachid = coachid;
    }

    public int getWaitListNo() {
        return WaitListNo;
    }

    public void setWaitListNo(int waitListNo) {
        WaitListNo = waitListNo;
    }

    public BerthType getBerthpreferred() {
        return Berthpreferred;
    }

    public int getSeatno() {
        return Seatno;
    }

    public void setSeatno(int seatno) {
        Seatno = seatno;
    }

    private int fromStationIndex;
    private int toStationIndex;

    public int getFromStationIndex() {
        return fromStationIndex;
    }

    public void setFromStationIndex(int fromStationIndex) {
        this.fromStationIndex = fromStationIndex;
    }

    public int getToStationIndex() {
        return toStationIndex;
    }

    public void setToStationIndex(int toStationIndex) {
        this.toStationIndex = toStationIndex;
    }

    public String getPnr() {
        return pnr;
    }

    public String getPassengerName() {
        return PassengerName;
    }

    public String getName() {
        return PassengerName;
    }

    public LocalDate getDob() {
        return dob;
    }

    public int getage(LocalDate dob) {
        return Period.between(dob, LocalDate.now()).getYears();
    }

    public QuotaType getQuotaType() {
        return quotaType;
    }

    public BookingStatus getBookingStatus() {
        return bookingStatus;
    }

    public void setBookingStatus(BookingStatus bookingStatus) {
        this.bookingStatus = bookingStatus;
    }

    public TTECheckStatus getTteCheckStatus() {
        return tteCheckStatus;
    }

    public void setTteCheckStatus(TTECheckStatus tteCheckStatus) {
        this.tteCheckStatus = tteCheckStatus;
    }

    public Gender getGender() {
        return gender;
    }

    public CoachType getCoachType() {
        return coachType;
    }

    public void setCoachType(CoachType coachType) {
        this.coachType = coachType;
    }

    public static void UpgradeRAC(Scanner scanner, Train train) {
        if (train == null) {
            System.out.println("Train not found!");
            return;
        }
        List<Passenger> racPassengers = new ArrayList<>();
        System.out.println(" RAC PASSENGERS :");
        int index = 1;
        for (Coach coach : train.GetCoaches()) {
            for (Passenger p : coach.getSeatInventory().getRacList()) {
                racPassengers.add(p);
                System.out.printf("%d. %s | PNR: %s | Coach: %s | RAC%n", index++, p.getPassengerName(), p.getPnr(), coach.getCoachId());
            }
        }
        if (racPassengers.isEmpty()) {
            System.out.println("No RAC passengers available!");
            return;
        }

        System.out.println("Enter passenger number to upgrade:");
        int choice = OnlyInteger(scanner);
        if (choice <= 0 || choice > racPassengers.size()) {
            System.out.println("Invalid selection!");
            return;
        }
        Passenger selectedPassenger = racPassengers.get(choice - 1);
        Coach selectedCoach = null;
        for (Coach coach : train.GetCoaches()) {
            if (coach.getCoachId().equalsIgnoreCase(selectedPassenger.getCoachid())) {
                selectedCoach = coach;
                break;
            }
        }
        if (selectedCoach == null) {
            System.out.println("Coach not found!");
            return;
        }
        SeatInventory inventory = selectedCoach.getSeatInventory();
        Seat availableSeat = null;
        for (Seat seat : inventory.getAvailableSeats()) {
            if (seat.getBookingstatus() == BookingStatus.AVAILABLE && seat.getAssignedquota() == selectedPassenger.getQuotaType() && seat.getBerthtype() == selectedPassenger.getBerthpreferred()) {
                availableSeat = seat;
                break;
            }
        }
        if (availableSeat == null) {
            System.out.println("No suitable confirmed seat available!");
            return;
        }
        inventory.getRacList().remove(selectedPassenger);
        availableSeat.setBookingstatus(BookingStatus.CONFIRMED);
        selectedPassenger.setSeatno(availableSeat.getSeatNo());
        selectedPassenger.setBookingStatus(BookingStatus.CONFIRMED);
        selectedPassenger.setTteCheckStatus(TTECheckStatus.UPGRADED);
        selectedPassenger.setWaitListNo(0);
        inventory.removeAvailableSeat(availableSeat);
        selectedCoach.addtoTotalConfirmedSeats(availableSeat);
        System.out.println("RAC UPGRADE SUCCESSFUL!");
        System.out.println("Passenger: " + selectedPassenger.getPassengerName());
        System.out.println("Coach: " + selectedCoach.getCoachId());
        System.out.println("Seat Number: " + availableSeat.getSeatNo());
        System.out.println("Status: CONFIRMED");
    }


//    public static void AssignSeats(Train train, List<Passenger> passengers) {
//        int defaultFrom = (passengers != null && !passengers.isEmpty()) ? passengers.get(0).getFromStationIndex() : 0;
//        int defaultTo = (passengers != null && !passengers.isEmpty() && passengers.get(0).getToStationIndex() > 0)
//                ? passengers.get(0).getToStationIndex()
//                : (train.getRoute() != null ? train.getRoute().size() - 1 : 1);
//        AssignSeats(train, passengers, defaultFrom, defaultTo);
//    }

    public static void AssignSeats(Train train, List<Passenger> passengers, int fromStationIndex, int toStationIndex) {
        for (Passenger p : passengers) {
            p.setFromStationIndex(fromStationIndex);
            p.setToStationIndex(toStationIndex);
            boolean allocated = false;

            // 1.find a seat with preferred berth & matching quota
            for (Coach c : train.GetCoaches()) {
                if (c.getCoachType() == p.getCoachType()) {
                    for (Seat s : c.getSeats()) {
                        if (s.getAssignedquota() == p.getQuotaType()
                                && s.getBerthtype() == p.getBerthpreferred()
                                && s.isAvailableForSegment(fromStationIndex, toStationIndex)) {

                            s.bookSegment(fromStationIndex, toStationIndex);
                            s.setBookingstatus(BookingStatus.CONFIRMED);
                            p.setSeatno(s.getSeatNo());
                            p.setCoachid(c.getCoachId());
                            p.setCoachType(c.getCoachType());
                            p.setBookingStatus(BookingStatus.CONFIRMED);
                            p.setWaitListNo(0);
                            c.addtoTotalConfirmedSeats(s);
                            c.getSeatInventory().removeAvailableSeat(s);
                            allocated = true;
                            break;
                        }
                    }
                    if (allocated) {
                        break;
                    }
                }
            }

            // 2.If preferred berth not available, find any seat in the coach matching quota
            if (!allocated) {
                for (Coach c : train.GetCoaches()) {
                    if (c.getCoachType() == p.getCoachType()) {
                        for (Seat s : c.getSeats()) {
                            if (s.getAssignedquota() == p.getQuotaType()
                                    && s.isAvailableForSegment(fromStationIndex, toStationIndex)) {

                                s.bookSegment(fromStationIndex, toStationIndex);
                                s.setBookingstatus(BookingStatus.CONFIRMED);
                                p.setSeatno(s.getSeatNo());
                                p.setCoachid(c.getCoachId());
                                p.setCoachType(c.getCoachType());
                                p.setBookingStatus(BookingStatus.CONFIRMED);
                                p.setWaitListNo(0);
                                c.addtoTotalConfirmedSeats(s);
                                c.getSeatInventory().removeAvailableSeat(s);
                                allocated = true;
                                break;
                            }
                        }
                        if (allocated) {
                            break;
                        }
                    }
                }
            }

            // 3.RAC
            if (!allocated) {
                for (Coach c1 : train.GetCoaches()) {
                    if (c1.getCoachType() == p.getCoachType()) {
                        SeatInventory inventory = c1.getSeatInventory();
                        if (inventory.addRacPassenger(p)) {
                            p.setCoachid(c1.getCoachId());
                            p.setCoachType(c1.getCoachType());
                            p.setSeatno(0);
                            p.setWaitListNo(0);
                            allocated = true;
                            break;
                        }
                    }
                }
            }

            // 4.WAITLIST
            if (!allocated) {
                for (Coach c2 : train.GetCoaches()) {
                    if (c2.getCoachType() == p.getCoachType()) {
                        SeatInventory inventory = c2.getSeatInventory();
                        if (inventory.addWaitingPassenger(p)) {
                            p.setCoachid(c2.getCoachId());
                            p.setCoachType(c2.getCoachType());
                            p.setSeatno(0);
                            allocated = true;
                            break;
                        }
                    }
                }
            }

            // 5.Reservation full
            if (!allocated) {
                p.setBookingStatus(BookingStatus.CANCELLED);
                System.out.println(p.getPassengerName() + " reservation capacity full.");
            }
        }
    }
}