package Services;
import Enums.BookingStatus;
import Enums.CoachType;
import java.util.Scanner;
import java.util.UUID;
import static Services.InputValidators.OnlyInteger;

public class Payment {
    private String PaymentID;
    private double amount;
    static Scanner scanner = new Scanner(System.in);
    public Payment(String paymentID, double amount) {
        this.PaymentID = paymentID;
        this.amount = amount;
    }
    public static boolean ProcessPayment(double amt) {
        String paymentid = UUID.randomUUID().toString();
        System.out.println("1.Proceed payment\n2.Cancel payment");
        while (true) {
            int ch = OnlyInteger(scanner);
            if (ch == 1) {
                System.out.println("Payment successful, payment id :"+paymentid);
                return true;

            } else if (ch == 2) {
                System.out.println("Payment cancelled");
                return false;

            } else {
                System.out.println("Invalid option");
            }
        }
    }
    public static double Refund(Passenger passenger, double fare) {
        double cancellationfee = 0.0;
        double refundamt = 0.0;

        if (passenger.getBookingStatus() == BookingStatus.WAITLIST || passenger.getBookingStatus() == BookingStatus.RAC) {
            cancellationfee = 60.0;
        } else if (passenger.getCoachType() != null) {
            switch (passenger.getCoachType()) {
                case AC_FIRST -> cancellationfee = 240.0;
                case AC_2TIER -> cancellationfee = 200.0;
                case AC_3TIER -> cancellationfee = 180.0;
                case EXECUTIVE_CHAIR_CAR -> cancellationfee = 250.0;
                case AC_CHAIR_CAR -> cancellationfee = 150.0;
                case SLEEPER -> cancellationfee = 120.0;
                default -> cancellationfee = 120.0;
            }
        } else {
            cancellationfee = 120.0;
        }

        refundamt = Math.max(0.0, fare - cancellationfee);

        System.out.println("\n---------------- CANCELLATION & REFUND RECEIPT ----------------");
        System.out.println("Passenger Name     : " + passenger.getPassengerName());
        System.out.println("Coach Type         : " + (passenger.getCoachType() != null ? passenger.getCoachType() : "N/A"));
        System.out.println("Booking Status     : " + passenger.getBookingStatus());
        System.out.printf("Original Fare Paid : Rs. %.2f%n", fare);
        System.out.printf("Cancellation Fee   : Rs. %.2f%n", cancellationfee);
        System.out.printf("Refund Amount      : Rs. %.2f%n", refundamt);
        System.out.println("---------------------------------------------------------------");

        return refundamt;
    }
}