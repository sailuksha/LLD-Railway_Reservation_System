package Services;
import Enums.BookingStatus;
import Enums.CoachType;
import java.util.Scanner;
import java.util.UUID;
import static Services.InputValidators.OnlyInteger;

public class Payment {
    static Scanner scanner = new Scanner(System.in);
    public static boolean ProcessPayment(double amt) {
        String paymentid = UUID.randomUUID().toString();
        System.out.println("1.Proceed payment\n2.Cancel payment");
        while (true) {
            int ch = OnlyInteger(scanner);
            if (ch == 1) {
                System.out.println("Payment successful, payment id :"+paymentid);
                return true;

            } else if (ch == 2) {
                System.out.println("Payment cancelled");
                return false;

            } else {
                System.out.println("Invalid option");
            }
        }
    }
    public static double Refund(Passenger passenger, double fare) {
        double cancellationfee = 0.0;
        double refundamt = 0.0;
        if (passenger.getBookingStatus() == BookingStatus.WAITLIST) {
            cancellationfee = 0.0;
        } else if (passenger.getBookingStatus() == BookingStatus.RAC) {
            cancellationfee = 50.0;
        } else if (passenger.getCoachType() != null) {
            switch (passenger.getCoachType()) {
                case CoachType.AC_FIRST -> cancellationfee = 240.0;
                case CoachType.AC_2TIER -> cancellationfee = 200.0;
                case CoachType.AC_3TIER -> cancellationfee = 180.0;
                case CoachType.SLEEPER -> cancellationfee = 120.0;
                case CoachType.EXECUTIVE_CHAIR_CAR -> cancellationfee = 250.0;
                case CoachType.AC_CHAIR_CAR -> cancellationfee = 150.0;
            }
        }
        refundamt = fare - cancellationfee;
        System.out.printf("TICKET CANCELLED : %n cancellation fee : %.2f%n Original fare paid : %.2f%n refund amt : %.2f%n", cancellationfee, fare, refundamt);
        return refundamt;
    }
}