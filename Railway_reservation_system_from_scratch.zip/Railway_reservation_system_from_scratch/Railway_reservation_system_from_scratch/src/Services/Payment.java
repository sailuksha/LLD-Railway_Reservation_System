package Services;

import java.util.Scanner;
import static Services.InputValidators.OnlyInteger;

public class Payment {

    public enum PaymentMethod {
        UPI,
        DEBIT_CARD,
        CREDIT_CARD,
        NET_BANKING
    }

    public static boolean ProcessPayment(Scanner scanner, double amount) {
        System.out.printf("%n=== PAYMENT GATEWAY ===%n");
        System.out.printf("Total Amount to Pay: Rs. %.2f%n", amount);
        System.out.println("Select Payment Method:");
        System.out.println("1. UPI (GPay / PhonePe / Paytm)");
        System.out.println("2. Debit Card");
        System.out.println("3. Credit Card");
        System.out.println("4. Net Banking");
        System.out.println("5. Cancel Payment");
        System.out.print("Enter choice (1-5): ");
        int choice = OnlyInteger(scanner);

        PaymentMethod method;
        switch (choice) {
            case 1 -> {
                method = PaymentMethod.UPI;
                System.out.print("Enter UPI ID (e.g. user@okhdfcbank): ");
                String upi = scanner.nextLine().trim();
                System.out.println("Requesting payment from " + upi + "...");
            }
            case 2 -> {
                method = PaymentMethod.DEBIT_CARD;
                System.out.print("Enter 16-digit Card Number: ");
                String card = scanner.nextLine().trim();
                System.out.print("Enter CVV: ");
                String cvv = scanner.nextLine().trim();
            }
            case 3 -> {
                method = PaymentMethod.CREDIT_CARD;
                System.out.print("Enter 16-digit Card Number: ");
                String card = scanner.nextLine().trim();
                System.out.print("Enter CVV: ");
                String cvv = scanner.nextLine().trim();
            }
            case 4 -> {
                method = PaymentMethod.NET_BANKING;
                System.out.print("Select Bank (1. SBI | 2. HDFC | 3. ICICI | 4. Axis): ");
                int bankChoice = OnlyInteger(scanner);
                System.out.println("Redirecting to secure bank gateway...");
            }
            case 5 -> {
                System.out.println("Payment cancelled by user.");
                return false;
            }
            default -> {
                System.out.println("Invalid payment option. Payment aborted.");
                return false;
            }
        }

        System.out.print("Processing transaction with Payment Gateway");
        try {
            for (int i = 0; i < 3; i++) {
                Thread.sleep(300);
                System.out.print(".");
            }
            System.out.println();
        } catch (InterruptedException ignored) {}

        String txnId = "TXN" + System.currentTimeMillis();
        System.out.println("Payment Successful via " + method + "!");
        System.out.println("Transaction ID: " + txnId);
        System.out.printf("Amount Paid: Rs. %.2f%n%n", amount);
        return true;
    }

    public static void ProcessRefund(String pnr, double refundAmount) {
        String refundTxnId = "RFND" + System.currentTimeMillis();
        System.out.printf("[PAYMENT GATEWAY] 100%% Refund of Rs. %.2f credited back to source account for PNR: %s (Txn ID: %s)%n",
                refundAmount, pnr, refundTxnId);
    }
}
