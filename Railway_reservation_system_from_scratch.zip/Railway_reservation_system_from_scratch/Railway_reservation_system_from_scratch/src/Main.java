import java.util.Scanner;

import static PortalRunners.Portals.Railway;

public static void main() {
        Scanner scanner=new Scanner(System.in);
        Railway(scanner);
    }