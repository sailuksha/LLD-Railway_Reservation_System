package Actors;
import Enums.StaffRole;

public class SuperAdmin extends Staff {
    public SuperAdmin(String staffid,String name, String phone, String email, String password){
        super(name, phone, email, password, StaffRole.SUPER_ADMIN);
        this.setStaffId(staffid);
    }
}
