package Actors;

public class SuperAdmin extends Staff {
    public SuperAdmin(String name, String phone, String email, String password){
        super("SA001",name, phone, email, password, StaffRole.SUPER_ADMIN);
    }
}
