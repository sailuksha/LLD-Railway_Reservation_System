package Actors;
import Services.Booking;
import Services.TTECheckStatus;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import static Objects.Storage.ActiveBookings;
import static Services.InputValidators.OnlyInteger;
public class TTE extends Staff {

//    private static List<String> TteIdDb=new ArrayList<>();
//
//    public static void addTTEId(String newid){
//        TteIdDb.add(new)
//    }
    private int AssignedTrainNo;
    public TTE(String staffId, String name, String PhoneNo, String email, String password, int AssignedTrainNo){
        super(staffId,name, PhoneNo,email,password,Actors.StaffRole.TTE);
        this.AssignedTrainNo = AssignedTrainNo;
    }
    public int getAssignedTrainNo(){return AssignedTrainNo;}
    public static void VerifyTickets(Scanner scanner){
        boolean run=true;
        while (run){
            System.out.println("1.Enter PNR to verify");
            System.out.println("2.Exit");
            int choice= OnlyInteger(scanner);
            if (choice==1) {
                String PNR = scanner.nextLine().trim();
                for (Booking b : ActiveBookings) {
                    if (b.getpnrno().equals(PNR)) {
                        b.setTTECheck(TTECheckStatus.VERIFIED);

                    } else {
                        System.out.println("PNR not found!");
                    }
                }
            }else if (choice==2){
                run=false;
            }else{
                System.out.println("Invalid choice");
            }
        }
    }
}
