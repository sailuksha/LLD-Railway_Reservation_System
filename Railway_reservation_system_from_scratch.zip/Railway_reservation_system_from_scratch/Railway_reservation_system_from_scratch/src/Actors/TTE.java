package Actors;

import Enums.BookingStatus;
import Enums.CoachType;
import Enums.StaffRole;
import Enums.TTECheckStatus;
import Objects.Coach;
import Objects.Seat;
import Objects.Train;
import Services.BookingService;
import Services.CancellationService;
import Services.Passenger;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static Objects.Storage.ActiveBookings;
import static Services.InputValidators.OnlyInteger;

public class TTE extends Staff {
    private int AssignedTrainNo;

    public TTE(String name, String PhoneNo, String email, String password, int AssignedTrainNo) {
        super(name, PhoneNo, email, password, StaffRole.TTE);
        this.AssignedTrainNo = AssignedTrainNo;
    }

    public int getAssignedTrainNo() {
        return AssignedTrainNo;
    }

    public static void VerifyTickets(Scanner scanner) {
        VerifyTickets(scanner, null);
    }

    public static void VerifyTickets(Scanner scanner, Train train) {
        boolean run = true;
        while (run) {
            System.out.println("\n----------------- TICKET VERIFICATION -----------------");
            System.out.println("1. Enter PNR to verify / mark attendance");
            System.out.println("2. Back to TTE Portal");
            System.out.print("Enter choice: ");
            int choice = OnlyInteger(scanner);

            if (choice == 1) {
                System.out.print("Enter PNR to verify: ");
                String pnr = scanner.nextLine().trim();

                BookingService targetBooking = null;
                for (BookingService b : ActiveBookings) {
                    if (b.getpnrno().equals(pnr)) {
                        targetBooking = b;
                        break;
                    }
                }

                if (targetBooking == null) {
                    System.out.println("PNR not found!");
                    continue;
                }

                List<Passenger> pList = targetBooking.getPassengerlist();
                if (pList == null || pList.isEmpty()) {
                    System.out.println("No passengers found for this PNR.");
                    continue;
                }

                System.out.println("\nPassengers under PNR: " + pnr);
                System.out.println("----------------------------------------------------------------------------------");
                System.out.printf("%-4s | %-20s | %-12s | %-10s | %-10s | %-15s%n",
                        "#", "NAME", "STATUS", "COACH", "SEAT NO", "TTE CHECK");
                System.out.println("----------------------------------------------------------------------------------");
                for (int i = 0; i < pList.size(); i++) {
                    Passenger p = pList.get(i);
                    String coachInfo = p.getCoachid() != null ? p.getCoachid() : "-";
                    String seatInfo = p.getSeatno() > 0 ? String.valueOf(p.getSeatno()) : (p.getBookingStatus() == BookingStatus.WAITLIST ? "WL-" + p.getWaitListNo() : "RAC");
                    if (p.getBookingStatus() == BookingStatus.CANCELLED) {
                        seatInfo = "CANCELLED";
                    }
                    System.out.printf("%-4d | %-20s | %-12s | %-10s | %-10s | %-15s%n",
                            (i + 1), p.getPassengerName(), p.getBookingStatus(), coachInfo, seatInfo, p.getTteCheckStatus());
                }
                System.out.println("----------------------------------------------------------------------------------");

                System.out.println("\nVerification Actions:");
                System.out.println("1. Mark all active passengers as PRESENT (VERIFIED)");
                System.out.println("2. Mark a specific passenger as PRESENT (VERIFIED)");
                System.out.println("3. Mark a specific passenger as ABSENT (NO-SHOW - Vacates Seat)");
                System.out.println("4. Back");
                System.out.print("Choose action: ");
                int act = OnlyInteger(scanner);

                if (act == 1) {
                    for (Passenger p : pList) {
                        if (p.getBookingStatus() != BookingStatus.CANCELLED) {
                            p.setTteCheckStatus(TTECheckStatus.VERIFIED);
                        }
                    }
                    targetBooking.setTTECheck(TTECheckStatus.VERIFIED);
                    System.out.println("All active passengers marked as VERIFIED.");

                } else if (act == 2) {
                    System.out.print("Enter passenger number: ");
                    int pIdx = OnlyInteger(scanner);
                    if (pIdx >= 1 && pIdx <= pList.size()) {
                        Passenger p = pList.get(pIdx - 1);
                        if (p.getBookingStatus() == BookingStatus.CANCELLED) {
                            System.out.println("Passenger is already cancelled.");
                        } else {
                            p.setTteCheckStatus(TTECheckStatus.VERIFIED);
                            System.out.println(p.getPassengerName() + " marked as VERIFIED.");
                        }
                    } else {
                        System.out.println("Invalid passenger selection.");
                    }

                } else if (act == 3) {
                    System.out.print("Enter passenger number to mark NO-SHOW: ");
                    int pIdx = OnlyInteger(scanner);
                    if (pIdx >= 1 && pIdx <= pList.size()) {
                        Passenger absentP = pList.get(pIdx - 1);
                        if (absentP.getBookingStatus() == BookingStatus.CANCELLED) {
                            System.out.println("Passenger is already cancelled.");
                        } else {
                            absentP.setTteCheckStatus(TTECheckStatus.MARK_NO_SHOW);
                            if (absentP.getBookingStatus() == BookingStatus.CONFIRMED && absentP.getSeatno() > 0 && train != null) {
                                for (Coach c : train.GetCoaches()) {
                                    if (c.getCoachId().equalsIgnoreCase(absentP.getCoachid())) {
                                        Seat freedSeat = null;
                                        for (Seat s : c.getTotalConfirmedSeats()) {
                                            if (s.getSeatNo() == absentP.getSeatno()) {
                                                freedSeat = s;
                                                break;
                                            }
                                        }
                                        if (freedSeat != null) {
                                            c.removeFromTotalConfirmedSeats(freedSeat);
                                            freedSeat.setBookingstatus(BookingStatus.AVAILABLE);
                                            c.getSeatInventory().addAvailableSeat(freedSeat);
                                            System.out.println("Seat " + absentP.getSeatno() + " in Coach " + c.getCoachId() + " vacated and added to available seats.");
                                        }
                                        break;
                                    }
                                }
                            }
                            System.out.println(absentP.getPassengerName() + " marked as NO-SHOW.");
                        }
                    } else {
                        System.out.println("Invalid passenger selection.");
                    }
                }

            } else if (choice == 2) {
                run = false;
            } else {
                System.out.println("Invalid choice!");
            }
        }
    }

    private static class VacantSeatOption {
        Coach coach;
        Seat seat;

        VacantSeatOption(Coach coach, Seat seat) {
            this.coach = coach;
            this.seat = seat;
        }
    }

    /**
     * TTE Manual RAC Upgrade Logic:
     * 1. Displays all RAC passengers on the train.
     * 2. Lets TTE select which RAC passenger to upgrade.
     * 3. Finds and displays all vacant/available seats across all coaches matching that passenger's coach class.
     * 4. Lets TTE select which vacant seat to allot.
     * 5. Confirms the seat, moves RAC passenger to CONFIRMED, promotes the first waitlisted passenger to RAC,
     *    and prints a complete upgrade confirmation.
     */
    public static void UpgradeRAC(Scanner scanner, Train train) {
        if (train == null) {
            System.out.println("Train not found!");
            return;
        }

        List<Passenger> racPassengers = new ArrayList<>();
        for (Coach coach : train.GetCoaches()) {
            racPassengers.addAll(coach.getSeatInventory().getRacList());
        }

        if (racPassengers.isEmpty()) {
            System.out.println("\nNo RAC passengers found on Train #" + train.getTrainNo() + ".");
            return;
        }

        System.out.println("\n================================== RAC PASSENGERS LIST ==================================");
        System.out.printf("%-4s | %-20s | %-12s | %-18s | %-15s | %-10s%n",
                "#", "PASSENGER NAME", "PNR", "COACH TYPE", "PREF BERTH", "COACH");
        System.out.println("-----------------------------------------------------------------------------------------");
        for (int i = 0; i < racPassengers.size(); i++) {
            Passenger p = racPassengers.get(i);
            String coachInfo = p.getCoachid() != null ? p.getCoachid() : "-";
            System.out.printf("%-4d | %-20s | %-12s | %-18s | %-15s | %-10s%n",
                    (i + 1), p.getPassengerName(), p.getPnr(), p.getCoachType(), p.getBerthpreferred(), coachInfo);
        }
        System.out.println("-----------------------------------------------------------------------------------------");

        System.out.print("Enter RAC passenger number to upgrade (or 0 to cancel): ");
        int choice = OnlyInteger(scanner);
        if (choice == 0) {
            System.out.println("Upgrade cancelled.");
            return;
        }
        if (choice < 1 || choice > racPassengers.size()) {
            System.out.println("Invalid selection!");
            return;
        }

        Passenger selectedPassenger = racPassengers.get(choice - 1);
        CoachType targetType = selectedPassenger.getCoachType();

        List<VacantSeatOption> availableOptions = new ArrayList<>();
        for (Coach c : train.GetCoaches()) {
            if (targetType == null || c.getCoachType() == targetType) {
                for (Seat s : c.getSeatInventory().getAvailableSeats()) {
                    if (s.getBookingstatus() == BookingStatus.AVAILABLE) {
                        availableOptions.add(new VacantSeatOption(c, s));
                    }
                }
            }
        }

        if (availableOptions.isEmpty()) {
            System.out.println("\nNo vacant/available seats found in any " + targetType + " coach on this train!");
            System.out.println("Note: You can verify tickets and mark absent passengers as No-Show to release their seats.");
            return;
        }

        System.out.println("\n------------------------ VACANT / AVAILABLE SEATS IN " + targetType + " ------------------------");
        System.out.printf("%-4s | %-10s | %-10s | %-15s | %-18s%n",
                "#", "COACH ID", "SEAT NO", "BERTH TYPE", "QUOTA");
        System.out.println("--------------------------------------------------------------------------------");
        for (int i = 0; i < availableOptions.size(); i++) {
            VacantSeatOption opt = availableOptions.get(i);
            System.out.printf("%-4d | %-10s | %-10d | %-15s | %-18s%n",
                    (i + 1), opt.coach.getCoachId(), opt.seat.getSeatNo(), opt.seat.getBerthtype(), opt.seat.getAssignedquota());
        }
        System.out.println("--------------------------------------------------------------------------------");

        System.out.print("Select seat number (1 to " + availableOptions.size() + ") to allot to " + selectedPassenger.getPassengerName() + " (or 0 to cancel): ");
        int seatChoice = OnlyInteger(scanner);
        if (seatChoice == 0) {
            System.out.println("Upgrade cancelled.");
            return;
        }
        if (seatChoice < 1 || seatChoice > availableOptions.size()) {
            System.out.println("Invalid seat selection!");
            return;
        }

        VacantSeatOption selectedOption = availableOptions.get(seatChoice - 1);
        Coach allocatedCoach = selectedOption.coach;
        Seat allocatedSeat = selectedOption.seat;

        Coach currentCoach = null;
        for (Coach c : train.GetCoaches()) {
            if (c.getSeatInventory().getRacList().contains(selectedPassenger)) {
                currentCoach = c;
                break;
            }
        }
        if (currentCoach == null) {
            currentCoach = allocatedCoach;
        }

        allocatedCoach.getSeatInventory().removeAvailableSeat(allocatedSeat);
        allocatedSeat.setBookingstatus(BookingStatus.CONFIRMED);
        allocatedCoach.addtoTotalConfirmedSeats(allocatedSeat);

        currentCoach.getSeatInventory().getRacList().remove(selectedPassenger);

        selectedPassenger.setSeatno(allocatedSeat.getSeatNo());
        selectedPassenger.setCoachid(allocatedCoach.getCoachId());
        selectedPassenger.setCoachType(allocatedCoach.getCoachType());
        selectedPassenger.setBookingStatus(BookingStatus.CONFIRMED);
        selectedPassenger.setWaitListNo(0);
        selectedPassenger.setTteCheckStatus(TTECheckStatus.UPGRADED);

        for (BookingService b : ActiveBookings) {
            if (b.getpnrno().equals(selectedPassenger.getPnr())) {
                CancellationService.updateBookingStatus(b);
                break;
            }
        }

        Passenger promotedWaiting = currentCoach.getSeatInventory().removeFirstWaitingPassenger();
        if (promotedWaiting != null) {
            currentCoach.getSeatInventory().addRacPassenger(promotedWaiting);
            System.out.println("\nPassenger " + promotedWaiting.getPassengerName() + " has been promoted from WAITLIST to RAC.");
        }

        System.out.println("\n========================================================");
        System.out.println("             TTE MANUAL RAC UPGRADE SUCCESSFUL!         ");
        System.out.println("========================================================");
        System.out.println("Passenger Name : " + selectedPassenger.getPassengerName());
        System.out.println("PNR            : " + selectedPassenger.getPnr());
        System.out.println("Allotted Coach : " + allocatedCoach.getCoachId() + " (" + allocatedCoach.getCoachType() + ")");
        System.out.println("Allotted Seat  : " + allocatedSeat.getSeatNo() + " (" + allocatedSeat.getBerthtype() + ")");
        System.out.println("New Status     : " + selectedPassenger.getBookingStatus());
        System.out.println("TTE Status     : " + selectedPassenger.getTteCheckStatus());
        System.out.println("========================================================\n");
    }

    public static void displayTTETab(Train train) {
        System.out.println("\n================================== TTE MANIFEST ==================================");
        System.out.printf("%-15s | %-20s | %-12s | %-12s | %-15s%n",
                "PNR", "PASSENGER", "STATUS", "COACH-SEAT", "TTE STATUS");
        System.out.println("----------------------------------------------------------------------------------");
        for (Passenger p : train.getPassengerList()) {
            String seatInfo = "-";
            if (p.getBookingStatus() == BookingStatus.CONFIRMED) {
                seatInfo = (p.getCoachid() != null ? p.getCoachid() : "") + "-" + p.getSeatno();
            } else if (p.getBookingStatus() == BookingStatus.RAC) {
                seatInfo = (p.getCoachid() != null ? p.getCoachid() : "") + "-RAC";
            } else if (p.getBookingStatus() == BookingStatus.WAITLIST) {
                seatInfo = "WL-" + p.getWaitListNo();
            } else if (p.getBookingStatus() == BookingStatus.CANCELLED) {
                seatInfo = "CANCELLED";
            }
            System.out.printf("%-15s | %-20s | %-12s | %-12s | %-15s%n",
                    p.getPnr(), p.getName(), p.getBookingStatus(), seatInfo, p.getTteCheckStatus());
        }
        System.out.println("----------------------------------------------------------------------------------");
    }
}
