package Actors;

public enum StaffRole {
    SUPER_ADMIN,
    INVENTORY_MANAGER,
    TTE
}
