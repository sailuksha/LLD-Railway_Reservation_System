package Actors;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}