package Actors;
import Services.BookingService;
import java.util.ArrayList;
import java.util.List;

public class User {
    private String name;
    private String PhoneNo;
    private String email;
    private String password;
    private List<BookingService> MyBookings;

    public User(String name, String PhoneNo, String email, String password) {
        this.name = name;
        this.PhoneNo = PhoneNo;
        this.email = email;
        this.password = password;
        this.MyBookings=new ArrayList<>();
    }
    public void addToMyBookings(BookingService booking){
        this.MyBookings.add(booking);
    }
    public String getName() {
        return name;
    }
    public String getPhoneNo() {
        return PhoneNo;
    }
    public String getEmail() {
        return email;
    }
    public List<BookingService> getMyBookings(){
        return MyBookings;
    }
    public String getPassword() {
        return this.password;
    }
}