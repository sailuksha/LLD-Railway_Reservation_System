package Actors;
import Services.Booking;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class User {
    private String name;
    private String PhoneNo;
    private String email;
    private String password;
    private Date dob;
    private Gender Gender;
    private String AadharNo;
    private List<Booking> MyBookings;

    public User(String name, String PhoneNo, String email, String password, Date dob, Gender gender, String AadharNo) {
        this.name = name;
        this.PhoneNo = PhoneNo;
        this.email = email;
        this.password = password;
        this.dob = dob;
        this.Gender = gender;
        this.AadharNo = AadharNo;
        this.MyBookings=new ArrayList<>();

    }
    public void addToMyBookings(Booking booking){
        this.MyBookings.add(booking);
    }

    public String getName() {
        return name;
    }

    public String getPhoneNo() {
        return PhoneNo;
    }

    public String getEmail() {
        return email;
    }

    public List<Booking> getMyBookings(){
        return MyBookings;
    }
    public String getPassword() {
        return this.password;
    }

}
