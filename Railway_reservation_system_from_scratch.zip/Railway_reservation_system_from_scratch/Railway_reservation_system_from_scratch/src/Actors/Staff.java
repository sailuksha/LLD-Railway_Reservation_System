package Actors;

public abstract class Staff {
    private String staffId;
    private String Name;
    private String PhoneNo;
    private String email;
    private String password;
    private StaffRole role;

    public Staff(String staffId, String name, String PhoneNo, String email, String password, StaffRole role) {
        this.staffId = staffId;
        this.Name = name;
        this.PhoneNo = PhoneNo;
        this.email = email;
        this.password = password;
        this.role = role;
    }

    public String getStaffId() {
        return staffId;
    }
        public String getPhoneNo() {
        return PhoneNo;
    }

    public String getEmail() {
        return email;
    }
    public String getName(){
        return Name;
    }

    public StaffRole getRole() {
        return role;
    }

    public void setPassword(String NewPass) {
        this.password = NewPass;
    }

    public boolean ValidatePass(String pass, Staff staff) {
        return staff.password.equals(pass);
    }
}
