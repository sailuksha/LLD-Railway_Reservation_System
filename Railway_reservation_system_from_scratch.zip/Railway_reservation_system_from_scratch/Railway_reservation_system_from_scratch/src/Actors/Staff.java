package Actors;
import Enums.StaffRole;
import static Objects.Storage.StaffDatabase;

public abstract class Staff {
    private String staffId;
    private String Name;
    private String PhoneNo;
    private String email;
    private String password;
    private StaffRole role;

    public Staff( String name, String PhoneNo, String email, String password, StaffRole role) {
        this.Name = name;
        this.PhoneNo = PhoneNo;
        this.email = email;
        this.password = password;
        this.role = role;
    }
    public String getStaffId() {
        return staffId;
    }
    public String getPhoneNo() {
        return PhoneNo;
    }
    public String getEmail() {
        return email;
    }
    public String getName(){
        return Name;
    }
    public StaffRole getRole() {
        return role;
    }
    public void setPassword(String NewPass) {
        this.password = NewPass;
    }
    public boolean ValidatePass(String pass, Staff staff) {
        return staff.password.equals(pass);
    }
    public void setStaffId(String staffId) {
        this.staffId = staffId;
    }

    public static String GenerateStaffId(Staff staff){
        String newstaffid=null;
        String prefix=null;
        for (Staff s : StaffDatabase){
            String staffid=s.getStaffId();
            if (staffid==null){
                continue;
            }
            int staffno=Integer.parseInt(staffid.substring(staffid.length()-3));
            int newstaffno=staffno+1;

            if (staff instanceof SuperAdmin){
                prefix="SA";
            }else if (staff instanceof InventoryManager){
                prefix="IM";
            }else{
                prefix="TTE";
            }
            newstaffid=prefix+String.format("%03d",newstaffno);
        }
        return newstaffid;
    }
}