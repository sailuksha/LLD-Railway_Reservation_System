package Actors;

public class InventoryManager extends Staff {
    public InventoryManager (String staffId, String name, String phoneno,String email,String password){
        super(staffId,name,phoneno,email,password,StaffRole.INVENTORY_MANAGER);
    }
}
