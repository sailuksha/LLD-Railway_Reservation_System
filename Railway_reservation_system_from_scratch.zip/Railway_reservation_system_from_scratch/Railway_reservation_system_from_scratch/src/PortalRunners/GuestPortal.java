package PortalRunners;
import Enums.BookingStatus;
import Objects.Station;
import Objects.Storage;
import Objects.Train;
import Services.BookingService;
import Services.Passenger;
import java.util.Scanner;

public class GuestPortal {

    public static void Menu(Scanner scanner) {
        System.out.print("Enter PNR to check: ");
        String pnr = scanner.nextLine().trim();
        boolean found = false;

        for (BookingService b : Storage.ActiveBookings) {
            if (b.getpnrno().equals(pnr)) {
                found = true;
                System.out.println(" PNR ENQUIRY DETAILS : ");
                System.out.println("PNR Number       : " + b.getpnrno());
                System.out.println("Overall Status   : " + b.getStatus());

                Train train = b.getBookedTrain();
                if (train != null) {
                    System.out.println("Train Number     : " + train.getTrainNo());
                    if (train.getJourneydate() != null) {
                        System.out.println("Journey Date     : " + train.getJourneydate());
                    }
                    if (train.getTime() != null) {
                        System.out.println("Departure Time   : " + train.getTime());
                    }
                    System.out.println("Boarding Station : " + b.getSource());
                    System.out.println("Destination      : " + b.getDestination());

                    // Find Platform Number for the passenger's boarding station
                    int platformNo = -1;
                    if (train.getRoute() != null) {
                        for (Station s : train.getRoute()) {
                            if (s.getStationName().equalsIgnoreCase(b.getSource())) {
                                platformNo = s.getPlatformno();
                                break;
                            }
                        }
                    }
                    if (platformNo == -1 && train.getSource() != null) {
                        if (train.getSource().getStationName().equalsIgnoreCase(b.getSource())) {
                            platformNo = train.getSource().getPlatformno();
                        }
                    }

                    if (platformNo != -1) {
                        System.out.println("Boarding Platform: Platform " + platformNo);
                    } else {
                        System.out.println("Boarding Platform: To be announced (TBA)");
                    }
                }

                System.out.println("Passenger Details:");
                System.out.printf("%-20s | %-20s | %-20s | %-20s | %-20s%n", "#", "NAME", "STATUS", "COACH", "SEAT NO");

                if (b.getPassengerlist() != null) {
                    for (int i = 0; i < b.getPassengerlist().size(); i++) {
                        Passenger p = b.getPassengerlist().get(i);
                        String coach = (p.getCoachid() != null && !p.getCoachid().isEmpty()) ? p.getCoachid() : "-";
                        String seat = "-";
                        if (p.getBookingStatus() == BookingStatus.CONFIRMED) {
                            seat = String.valueOf(p.getSeatno());
                        } else if (p.getBookingStatus() == BookingStatus.RAC) {
                            seat = "RAC";
                        } else if (p.getBookingStatus() == BookingStatus.WAITLIST) {
                            seat = "WL-" + p.getWaitListNo();
                        } else if (p.getBookingStatus() == BookingStatus.CANCELLED) {
                            seat = "CANCELLED";
                        }
                        System.out.printf("%-4d | %-20s | %-12s | %-10s | %-10s%n",
                                (i + 1), p.getPassengerName(), p.getBookingStatus(), coach, seat);
                    }
                }
                break;
            }
        }

        if (!found) {
            System.out.println("PNR not found.");
        }
    }
}
