package PortalRunners;
import Actors.Staff;
import Actors.SuperAdmin;
import Objects.Train;
import Objects.Coach;
import Services.Passenger;
import java.util.Scanner;
import static Objects.Storage.TrainInventory;
import static Services.InputValidators.OnlyInteger;
public class ChartAndReport {

    public static void displayChart(Scanner scanner) {
        System.out.println("Enter train no:");
        int trainno = OnlyInteger(scanner);
        Train selectedTrain = null;
        for (Train t : TrainInventory) {
            if (t.getTrainNo() == trainno) {
                selectedTrain = t;
                break;
            }
        }
        if (selectedTrain == null) {
            System.out.println("Train not found!");
            return;
        }
        DisplayChart(selectedTrain);
    }
    public static void displayReport(Scanner scanner) {
        System.out.println("Enter train no to view report:");
        int trainno = OnlyInteger(scanner);
        BookingsReport(trainno);
    }
    public static void Redirect(Scanner scanner, Staff staff) {
        if (staff instanceof SuperAdmin) {
            SuperAdminPortal.Menu(scanner, staff);
        } else {
            InventoryManagerPortal.Menu(scanner, staff);
        }
    }
    public static void DisplayChart(Train train) {
        if (train == null) {
            System.out.println("Train not found!");
            return;
        }
        int trainno = train.getTrainNo();
        System.out.printf("CHART OF TRAIN # %d%n", trainno);
        for (Coach c : train.GetCoaches()) {
            System.out.printf("%nCoach: %s%n", c.getCoachId());
            System.out.printf("%-10s | %-20s | %-10s | %-12s | %-22s | %-15s | %-20s%n", "SEAT NO", "PASSENGER NAME", "AGE", "GENDER", "QUOTA", "STATUS", "TTE STATUS");
            for (Passenger p : train.getPassengerList()) {
                if (p.getCoachid() != null && p.getCoachid().equalsIgnoreCase(c.getCoachId())) {
                    System.out.printf("%-10d | %-20s | %-10d | %-12s | %-22s | %-15s | %-20s%n", p.getSeatno(), p.getPassengerName(), p.getage(p.getDob()), p.getGender(), p.getQuotaType(), p.getBookingStatus(), p.getTteCheckStatus());
                }
            }
        }
    }
    public static void BookingsReport(int trainno) {
        Train selectedTrain = null;
        for (Train t : TrainInventory) {
            if (t.getTrainNo() == trainno) {
                selectedTrain = t;
                break;
            }
        }
        if (selectedTrain == null) {
            System.out.println("Train not found!");
            return;
        }
        System.out.printf("TRAIN BOOKINGS REPORT FOR TRAIN: %d", trainno);
        System.out.printf("%-15s | %-20s | %-20s | %-15s | %-15s%n", "COACH ID", "CONFIRMED SEATS", "AVAILABLE SEATS", "RAC COUNT", "WAITLIST COUNT");
        for (Coach c : selectedTrain.GetCoaches()) {
            System.out.printf("%-15s | %-20d | %-20d | %-15d | %-15d%n", c.getCoachId(), c.getTotalConfirmedSeats().size(), c.getTotalAvailableSeats().size(), c.getSeatInventory().getRacList().size(), c.getSeatInventory().getWaitingList().size());
        }
    }
}