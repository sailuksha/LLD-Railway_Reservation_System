package PortalRunners;
import Actors.Staff;
import Services.InputValidators;
import java.util.Scanner;
import static Objects.Inventory.EditInventory;
import static Objects.Storage.TrainInventory;
import static Objects.Train.DisplayTrainInventory;
import static PortalRunners.ChartAndReport.displayChart;
import static PortalRunners.ChartAndReport.displayReport;

public class InventoryManagerPortal {

    public static void Menu(Scanner scanner, Staff staff) {
        while (true) {
            System.out.println("INVENTORY MANAGER DASHBOARD");
            System.out.println("1. View Inventory");
            System.out.println("2. Edit Inventory");
            System.out.println("3. View Prepared Chart");
            System.out.println("4. View Booking Report");
            System.out.println("5. Logout");
            int choice = InputValidators.OnlyInteger(scanner);

            switch (choice) {
                case 1 -> DisplayTrainInventory(TrainInventory);
                case 2 -> EditInventory(scanner, staff);
                case 3 -> displayChart(scanner);
                case 4 -> displayReport(scanner);
                case 5 -> {
                   return;
                }
                default -> System.out.println("Invalid option");
            }
        }
    }
}