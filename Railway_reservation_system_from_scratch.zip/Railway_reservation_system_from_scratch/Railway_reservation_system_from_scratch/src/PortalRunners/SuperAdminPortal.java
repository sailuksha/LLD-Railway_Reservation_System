package PortalRunners;
import Actors.Staff;
import Actors.SuperAdmin;
import Actors.TTE;
import Services.InputValidators;
import java.util.Scanner;
import static Objects.Inventory.EditInventory;
import static Objects.Storage.StaffDatabase;
import static Objects.Storage.TrainInventory;
import static Objects.Train.DisplayTrainInventory;
import static PortalRunners.ChartAndReport.displayChart;
import static PortalRunners.ChartAndReport.displayReport;
import static PortalRunners.StaffPortal.RegisterStaff;

public class SuperAdminPortal {

    public static void Menu(Scanner scanner, Staff staff) {
        while (true) {
            System.out.println("SUPER ADMIN DASHBOARD");
            System.out.println("1. Register Staff");
            System.out.println("2. List Staff");
            System.out.println("3. Remove Staff");
            System.out.println("4. View Inventory");
            System.out.println("5. Edit Inventory");
            System.out.println("6. View Chart");
            System.out.println("7. Booking Report");
            System.out.println("8. Logout");
            int choice = InputValidators.OnlyInteger(scanner);
            switch (choice) {
                case 1 -> RegisterStaff(scanner);
                case 2 -> displayStaff();
                case 3 -> removeStaff(scanner);
                case 4 -> DisplayTrainInventory(TrainInventory);
                case 5 -> EditInventory(scanner, staff);
                case 6 -> displayChart(scanner);
                case 7 -> displayReport(scanner);
                case 8 -> {
                    return;
                }
                default -> System.out.println("Invalid option");
            }
        }
    }
    private static void displayStaff() {
        System.out.println(" ACTIVE STAFFS : ");
        System.out.printf("%-20s | %-20s | %-20s | %-20s | %-20s | %-20s %n ", " STAFF ID", " STAFF NAME ", "ROLE", " PHONE", " EMAIL", " TRAINNO (FOR TTE)");
        for (Staff s : StaffDatabase) {
            String train = (s instanceof TTE tte) ? "Train : " + tte.getAssignedTrainNo() : "NA";
            System.out.printf("%-20s | %-20s | %-20s | %-20s | %-20s | %-20s %n ", s.getStaffId(), s.getName(), s.getRole(), s.getPhoneNo(), s.getEmail(), train);
        }
    }
    private static void removeStaff(Scanner scanner) {
        System.out.println(" ACTIVE STAFFS : ");
        System.out.printf(" %-20s | %-20s | %-20s | %-20s | %-20s | %-20s %n ", "STAFF ID", "STAFF NAME ", "ROLE", "PHONE", "EMAIL", "TRAINNO (FOR TTE)");
        for (Staff s : StaffDatabase) {
            String train = (s instanceof TTE tte) ? "Train : " + tte.getAssignedTrainNo() : "NA";
            System.out.printf(" %-20s | %-20s | %-20s | %-20s | %-20s | %-20s %n ", s.getStaffId(), s.getName(), s.getRole(), s.getPhoneNo(), s.getEmail(), train);
        }
        System.out.println("Enter StaffID to remove : ");
        String id = scanner.nextLine().trim();
        Staff remove = null;
        for (Staff ss : StaffDatabase) {
            if (ss.getStaffId().equals(id)) {
                remove = ss;
                break;
            }
        }
        if (remove instanceof SuperAdmin){
            System.out.println("Super admin can not be removed");
        }
        else if (remove == null) {
            System.out.println("Staff id not found. ");
        } else {
            StaffDatabase.remove(remove);
            System.out.println("Staff : " + remove.getName() + "removed.");
        }
    }
}