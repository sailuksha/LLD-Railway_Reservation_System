package PortalRunners;
import Services.InputValidators;
import java.util.Scanner;

public class Portals {
    public static void Railway(Scanner scanner) {
        while (true) {
            System.out.println("RAILWAY RESERVATION SYSTEM");
            System.out.println("1. Staff Portal");
            System.out.println("2. Passenger Portal");
            System.out.println("3. PNR Check with Guest Login");
            System.out.println("4. Exit System");
            int choice = InputValidators.OnlyInteger(scanner);
            switch (choice) {
                case 1 -> StaffPortal.Menu(scanner);
                case 2 -> PassengerPortal.Menu(scanner);
                case 3 -> GuestPortal.Menu(scanner);
                case 4 -> {
                    System.out.println("Exited. Thank you!");
                    return;
                }
                default -> System.out.println("Invalid option");
            }
        }
    }
}