package Enums;

public enum QuotaType {
        GENERAL,
        LADIES,
        SENIOR_CITIZEN,
        PHYSICALLY_CHALLENGED,
        TATKAL

}
