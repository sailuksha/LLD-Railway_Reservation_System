package Enums;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}