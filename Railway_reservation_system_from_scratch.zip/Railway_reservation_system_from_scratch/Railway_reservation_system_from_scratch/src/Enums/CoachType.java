package Enums;

public enum CoachType {
    SLEEPER(72),
    AC_3TIER(64),
    AC_2TIER(48),
    AC_FIRST(24),
    EXECUTIVE_CHAIR_CAR(70),
    AC_CHAIR_CAR(52);

    private final int totalSeats;

    CoachType(int totalSeats) {
        this.totalSeats = totalSeats;
    }
    public int getTotalSeats(){
        return totalSeats;
    }
}
