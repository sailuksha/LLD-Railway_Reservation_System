package Enums;

public enum BookingStatus {
    AVAILABLE,
    WAITLIST,
    CONFIRMED,
    RAC,
    CANCELLED,
    HOLD
}
