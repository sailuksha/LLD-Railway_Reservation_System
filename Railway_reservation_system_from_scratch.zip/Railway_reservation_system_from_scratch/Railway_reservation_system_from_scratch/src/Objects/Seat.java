package Objects;
import Enums.BerthType;
import Enums.BookingStatus;
import Enums.QuotaType;
import java.util.HashSet;
import java.util.Set;

public class Seat {

    private int SeatNo;
    private BerthType berthtype;
    private QuotaType assignedquota;
    private BookingStatus bookingstatus;
    private final Set<Integer> bookedSegments = new HashSet<>();

    public Seat(int seatno, BerthType berthType, QuotaType quotaType, BookingStatus bookingStatus) {

        this.SeatNo = seatno;
        this.berthtype = berthType;
        this.assignedquota = quotaType;
        this.bookingstatus = bookingStatus;
    }

    public boolean isAvailableForSegment(int fromIndex, int toIndex) {
        for (int i = fromIndex; i < toIndex; i++) {
            if (bookedSegments.contains(i)) {
                return false;
            }
        }
        return true;
    }

    public void bookSegment(int fromIndex, int toIndex) {
        for (int i = fromIndex; i < toIndex; i++) {
            bookedSegments.add(i);
        }
    }

    public void releaseSegment(int fromIndex, int toIndex) {
        for (int i = fromIndex; i < toIndex; i++) {
            bookedSegments.remove(i);
        }
    }

    public boolean isCompletelyFree() {
        return bookedSegments.isEmpty();
    }

    public int getSeatNo() {
        return SeatNo;
    }

    public BerthType getBerthtype() {
        return berthtype;
    }

    public QuotaType getAssignedquota() {
        return assignedquota;
    }

    public BookingStatus getBookingstatus() {
        return bookingstatus;
    }

    public void setBookingstatus(BookingStatus bookingstatus) {
        this.bookingstatus = bookingstatus;
    }
}
