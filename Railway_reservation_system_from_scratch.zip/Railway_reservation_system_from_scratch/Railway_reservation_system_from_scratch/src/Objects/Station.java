package Objects;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import static Services.InputValidators.OnlyInteger;

public class Station {
    private String StationName;
    private int Platformno;

    public Station(String stationName, int platformno) {
        this.StationName = stationName;
        this.Platformno = platformno;
    }

    public static List<Station> Route(String route) {
        Scanner scanner=new Scanner(System.in);
        List<Station> TrainRoute = new ArrayList<>();
        List<String> routenames = new ArrayList<>(Arrays.asList(route.split(",")));
        for (String s : routenames) {
            System.out.println("Enter platform no");
            int ptno = OnlyInteger(scanner);
            Station station = new Station(s, ptno);
            TrainRoute.add(station);
        }
        return TrainRoute;
    }

    public String getStationName() {
        return StationName;
    }

    public int getPlatformno() {
        return Platformno;
    }

    public String toString() {
        return StationName;
    }

    public static List<Station> Route(String route, String Platformnumbers) {
        List<Station> TrainRoute = new ArrayList<>();
        List<String> routenames = new ArrayList<>(Arrays.asList(route.split(",")));
        List<String> ptnos = new ArrayList<>(Arrays.asList(Platformnumbers.split(",")));
        for (int i = 0; i < routenames.size(); i++) {
            String s = routenames.get(i).trim();
            int b = (i < ptnos.size()) ? Integer.parseInt(ptnos.get(i).trim()) : 1;
            Station station = new Station(s, b);
            TrainRoute.add(station);
        }
        return TrainRoute;
    }
}
