package Objects;
import Enums.CoachType;
import Enums.QuotaType;
import Services.Passenger;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import static Objects.Storage.TrainInventory;
public class Train {
    private int TrainNo;
    private Station Source;
    private Station destination;
    private double BaseFare;
    private List<Station> Route;
    private List<Coach> coaches = new ArrayList<>();
    private List<Passenger> passengerList = new ArrayList<>();
    private LocalDate Journeydate=LocalDate.now();
    private LocalTime time;
    public Train(int TrainNo, Station source, Station destination, List<Station> Route, double BaseFare,LocalDate dateOfJourney,LocalTime timeofjourney) {
        this.TrainNo = TrainNo;
        this.Source = source;
        this.destination = destination;
        this.BaseFare = BaseFare;
        this.Journeydate = dateOfJourney;
        this.time = timeofjourney;
        this.Route = Route;
    }
    public LocalDate getJourneydate() {
        return Journeydate;
    }

    public LocalTime getTime() {
        return time;
    }

    public List<Passenger> getPassengerList() {
        return passengerList;
    }
    public void addPassengerList(List<Passenger> passengers) {
        passengerList.addAll(passengers);
    }
    public void AddCoach(Coach coach) {
        if (coach != null) {
            coaches.add(coach);
        }
    }
    public List<Coach> GetCoaches() {
        return coaches;
    }
    public void RemoveCoaches(Coach coach) {
        coaches.remove(coach);
    }

    public void setSource(Station source) {
        this.Source = source;
    }

    public void setDestination(Station destination) {
        this.destination = destination;
    }

    public Coach HoldSeatInCoach(Train train, Scanner scanner, QuotaType quotaType) {
        int defaultFrom = 0;
        int defaultTo = (train.getRoute() != null && train.getRoute().size() > 1) ? train.getRoute().size() - 1 : 1;
        return HoldSeatInCoach(train, scanner, quotaType, defaultFrom, defaultTo);
    }

    public Coach HoldSeatInCoach(Train train, Scanner scanner, QuotaType quotaType, int fromStationIndex, int toStationIndex) {
        while (true) {
            System.out.println("Enter preferred coach:");
            System.out.println("1AC / 2AC / 3AC / SL / EC / CC");
            String choice = scanner.next().trim().toUpperCase();
            CoachType selectedType = switch (choice) {
                case "1AC" -> CoachType.AC_FIRST;
                case "2AC" -> CoachType.AC_2TIER;
                case "3AC" -> CoachType.AC_3TIER;
                case "SL" -> CoachType.SLEEPER;
                case "EC" -> CoachType.EXECUTIVE_CHAIR_CAR;
                case "CC" -> CoachType.AC_CHAIR_CAR;
                default -> null;
            };
            if (selectedType == null) {
                System.out.println("Invalid coach type");
                continue;
            }
            List<Coach> matchingcoaches = new ArrayList<>();
            for (Coach c : train.GetCoaches()) {
                if (c.getCoachType() == selectedType) {
                    matchingcoaches.add(c);
                }
            }
            if (matchingcoaches.isEmpty()) {
                System.out.println("Train : " + train.getTrainNo() + " does not have " + choice + " coaches.");
                continue;
            }
            int totalquotaseats = 0;
            int totalracavailable = 0;
            int totalwaitlistavailable = 0;
            for (Coach c : matchingcoaches) {
                int countquotaseats = 0;
                for (Seat seat : c.getSeats()) {
                    if (seat.getAssignedquota() == quotaType && seat.isAvailableForSegment(fromStationIndex, toStationIndex)) {
                        countquotaseats++;
                    }
                }
                totalquotaseats += countquotaseats;
                totalracavailable += (c.getSeatInventory().RacCapacity() ? 1 : 0);
                totalwaitlistavailable += (c.getSeatInventory().WaitingListCapacity() ? 1 : 0);
            }
            System.out.println("AVAILABILITY FOR : " + choice + " Quotatype :" + quotaType);
            if (totalquotaseats > 0) {
                System.out.println("AVAILABLE : " + totalquotaseats);
            } else if (totalracavailable > 0) {
                System.out.println("RAC available ");
            } else if (totalwaitlistavailable > 0) {
                System.out.println("WAITLIST available");
            } else {
                System.out.println("REGRET");
                return null;
            }
            return matchingcoaches.get(0);
        }
    }
    public void SetBaseFare(double baseFare) {
        this.BaseFare = baseFare;
    }
    public int getTrainNo() {
        return TrainNo;
    }
    public void setTrainNo(int trainNo) {
        TrainNo = trainNo;
    }

    public List<Station> getRoute() {
        return Route;
    }

    public Station getDestination() {
        return destination;
    }

    public Station getSource() {
        return Source;
    }

    public double getBaseFare() {
        return BaseFare;
    }

    public static void DisplayTrainInventory(List<Train> TrainInventory) {
        System.out.println(" TRAIN INVENTORY : ");
        for (Train t : TrainInventory) {
            System.out.println("Train : " + t.getTrainNo() + " | " + t.getSource().getStationName() + " to " + t.getDestination().getStationName() + " | base fare : rs. " + t.getBaseFare());
            System.out.printf("%-15s | %-25s | %-15s%n", "COACH ID", "COACH TYPE", "AVAILABLE SEATS");
            for (Coach c : t.GetCoaches()) {
                System.out.printf("%-15s | %-25s | %-15s%n", c.getCoachId(), c.getCoachType(), c.getSeatInventory().getAvailableSeats().size());
            }
        }
    }
    public static boolean ValidateTrain(int Trainno) {
        for (Train t : TrainInventory) {
            if (t.getTrainNo() == Trainno) {
                return false;
            }
        }
        return true;
    }
    public static void DisplayTrainInfo(int TrainNo,LocalDate journeydate) {
        for (Train t : TrainInventory) {
            if (t.getTrainNo() == TrainNo && t.getJourneydate().equals(journeydate)) {
                System.out.println("Train : " + t.getTrainNo() + " | " + t.getSource() + " to " + t.getDestination() + " | base fare : rs. " + t.getBaseFare()+"Date : "+t.getJourneydate()+"Departure time : "+t.getTime());
                return;
            }
        }
    }
    public static Train FindTrain(int TrainNo) {
        for (Train t : TrainInventory) {
            if (t.getTrainNo() == TrainNo) {
                return t;
            }
        }
        return null;
    }
}