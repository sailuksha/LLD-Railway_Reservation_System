package Objects;
import Services.Booking;
import java.util.ArrayList;
import java.util.List;
import static Objects.Storage.TrainInventory;
public class Train {

    private int TrainNo;
    private String Source;
    private String destination;
    private double BaseFare;
    private List<String> Route;
    private List<Coach> coaches=new ArrayList<>();
    private List<Booking> TrainBookings=new ArrayList<>();

    public Train(int TrainNo, String source, String destination, String Route, double BaseFare) {
        this.TrainNo = TrainNo;
        this.Source = source;
        this.destination = destination;
        this.BaseFare = BaseFare;
        List<String> route=new ArrayList<>();
        for (String st : Route.split(",")) {
            route.add(st.trim());
        }
        this.Route=route;
    }

    public void setTrainBookings(Booking trainBooking) {
        TrainBookings.add(trainBooking);
    }

    public void AddCoach(Coach coach){
        this.coaches.add(coach);
    }
    public void SetBaseFare(double baseFare) {
        this.BaseFare = baseFare;
    }

    public int getTrainNo() {
        return TrainNo;
    }

    public void setTrainNo(int trainNo) {
        this.TrainNo = trainNo;
    }

    public String getSource() {
        return Source;
    }

    public List<Coach> getCoaches() {
        return coaches;
    }

    public void setSource(String source) {
        this.Source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }



    public double getBaseFare() {
        return BaseFare;
    }
    public List<String> getRouteStations() {
        return Route;
    }
    public static void DisplayTrainInventory(List<Train> TrainInventory) {
        System.out.println(" TRAIN INVENTORY : ");
        for (Train t : TrainInventory) {
            System.out.println("\nTrain : " + t.getTrainNo() + " | " + t.getSource() + " to " + t.getDestination() + " | base fare : rs. " + t.getBaseFare());
            System.out.printf("%-20s | %-20s | %-20s | %-20s | %-20s | %-20s | %-20S %n ","COACH ID ","COACH TYPE","GENERAL","LADIES","SENIOR CITIZEN","PHYSICALLY-CHALLENGED","CURRENTLY-AVAILABLE");
            for (Coach c : t.GetCoaches()){
                System.out.printf("%-20s | %-20s | %-20s | %-20s | %-20s | %-20s | %-20S %n ",c.getCoachId(),c.getType(),c.getGeneralSeats(),c.getLadiesSeats(),c.getSeniorCitizenSeats(),c.getPhysicallyChallengedSeats(),c.getTotalAvailableSeats().size());
            }
        }
    }
    public static void DisplayTrainInfo(int TrainNo){
        for (Train t:TrainInventory){
            if (t.getTrainNo()== TrainNo){
                System.out.println("\nTrain : " + t.getTrainNo() + " | " + t.getSource() + " to " + t.getDestination() + " | base fare : rs. " + t.getBaseFare());
            }
        }
    }
    public List<Coach> GetCoaches() {
        return coaches;

    }
    public static Train FindTrain(int TrainNo){
        Train train=null;
        for (Train t : TrainInventory){
            if (t.getTrainNo()== TrainNo){
                train=t;
            }
        }
        return train;
    }
    public void RemoveCoaches(Coach CoachId){
        this.coaches.remove(CoachId);
    }
}