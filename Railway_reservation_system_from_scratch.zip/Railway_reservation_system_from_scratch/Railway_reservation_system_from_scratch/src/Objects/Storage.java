package Objects;

import Actors.Gender;
import Actors.Staff;
import Actors.SuperAdmin;
import Actors.User;
import Services.Booking;

import java.util.ArrayList;
import java.util.List;

public class Storage {

    // TRAIN DB
    public static List<Train> TrainInventory = new ArrayList<>();

    static {
        // Pre-configure Seed Train 12623 with Coaches for ready out-of-the-box booking & testing
        Train train1 = new Train(12623, "Chennai", "Trivandrum", "Chennai, Coimbatore, Ernakulam, Trivandrum", 500.0);
        Coach.GenerateCoach(null, CoachType.SLEEPER, 1, train1, 10, 10, 10);
        Coach.GenerateCoach(null, CoachType.AC_3TIER, 1, train1, 10, 10, 10);
        TrainInventory.add(train1);

        Train train2 = new Train(16345, "Coimbatore", "Bangalore", "Coimbatore, Erode, Salem, Bangalore", 400.0);
        Coach.GenerateCoach(null, CoachType.SLEEPER, 1, train2, 10, 10, 10);
        TrainInventory.add(train2);
    }

    // STAFF DB
    public static List<Staff> StaffDatabase = new ArrayList<>();

    static {
        StaffDatabase.add(new SuperAdmin("Sailuksha", "9999999999", "sa001@railway.in", "sa001@123"));
    }

    // USER DATABASE
    public static List<User> UserDB = new ArrayList<>();

    static {
        UserDB.add(new User("Sailuksha", "9442919737", "sai@gmail.com", "sailuksha", null, Gender.FEMALE, "288374009424"));
    }

    // BOOKING DB
    public static List<Booking> ActiveBookings = new ArrayList<>();
}
