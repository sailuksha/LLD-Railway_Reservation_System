package Objects;
import Enums.CoachType;
import Actors.Staff;
import Actors.SuperAdmin;
import Actors.User;
import Services.BookingService;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import static Objects.Station.Route;

public class Storage {

    // TRAIN DB
    public static List<Train> TrainInventory = new ArrayList<>();
    static{
        Station source1=new Station("chennai",2);
        Station destination1=new Station("Trivandrum",3);
        List <Station> route1= Route("Chennai, Coimbatore, Ernakulam, Trivandrum","2,4,3,2");
        Train train1 = new Train(12623,source1,destination1, route1, 500.0,LocalDate.of(2026,11,24), LocalTime.of(5,30));
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train1, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train1, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train1, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train1, 10, 10, 10);
        TrainInventory.add(train1);

        Station source2=new Station("Coimbatore",2);
        Station destination2=new Station("Bangalore",3);
        List <Station> route2= Route("Coimbatore, Erode, Salem, Bangalore","3,6,2,8");
        Train train2 = new Train(16345, source2, destination2, route2, 400.0,LocalDate.of(2026,11,24), LocalTime.of(5,30));
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train2, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train2, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train2, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train2, 10, 10, 10);

        TrainInventory.add(train2);

        Station source3=new Station("Chennai",2);
        Station destination3=new Station("Mysore",3);
        List <Station> route3= Route("Chennai, Katpadi, Bengaluru, Mysore","5,4,3,4");
        Train train3 = new Train(20607, source3, destination3, route3, 750.0,LocalDate.of(2026,11,24), LocalTime.of(5,30));
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train3, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train3, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train3, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train3, 10, 10, 10);

        TrainInventory.add(train3);

        Station source4=new Station("Mysore",2);
        Station destination4=new Station("Chennai",3);
        List <Station> route4= Route("Mysore, Bengaluru, Katpadi, Chennai","5,7,1,2");
        Train train4 = new Train(20608, source4, destination4, route4, 750.0,LocalDate.of(2026,11,24), LocalTime.of(5,30));
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train4, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train4, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train4, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train4, 10, 10, 10);

        TrainInventory.add(train4);


        Station source5=new Station("Mangalore",2);
        Station destination5=new Station("Madgaon",3);
        List <Station> route5= Route("Mangalore, Udupi, Karwar, Madgaon","3,5,1,4");

        Train train5 = new Train(20631, source5, destination5, route5, 1200.0,LocalDate.of(2026,11,24), LocalTime.of(5,30));
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train5, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train5, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train5, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train5, 10, 10, 10);
        TrainInventory.add(train5);


        Station source6=new Station("Coimbatore",2);
        Station destination6=new Station("Bangalore",3);
        List <Station> route6= Route("Coimbatore, Tiruppur, Erode, Salem, Bengalore","3,3,5,5,8");


        Train train6 = new Train(20642, source6, destination6, route6, 1100.0,LocalDate.of(2026,11,24), LocalTime.of(5,30));
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train6, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train6, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train6, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train6, 10, 10, 10);
        TrainInventory.add(train6);

        Station source7=new Station("Chennai",2);
        Station destination7=new Station("Coimbatore",3);
        List <Station> route7= Route("Chennai, Salem, Erode, Tiruppur, Coimbatore","2,5,3,4,3");

        Train train7 = new Train(12675, source7, destination7, route7, 450.0,LocalDate.of(2026,11,24), LocalTime.of(5,30));
        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train7, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train7, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train7, 10, 10, 10);
        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train7, 10, 10, 10);

        TrainInventory.add(train7);

//
//        Train train8 = new Train(12625, "Trivandrum", "Delhi", "Trivandrum, Ernakulam, Kozhikode, Mangalore, Mumbai, Kota, Delhi", 1800.0,LocalDate.of(2026,11,24), LocalTime.of(5,30));
//        Coach.GenerateCoach((Scanner)null, CoachType.AC_CHAIR_CAR, 1, train8, 10, 10, 10);
//        Coach.GenerateCoach((Scanner)null, CoachType.EXECUTIVE_CHAIR_CAR, 1, train8, 10, 10, 10);
//        TrainInventory.add(train8);
//
//
//        Train train9 = new Train(12664, "Howrah", "Chennai", "Howrah, Bhubaneswar, Visakhapatnam, Vijayawada, Chennai", 950.0,LocalDate.of(2026,11,24), LocalTime.of(5,30));
//        Coach.GenerateCoach((Scanner)null, CoachType.AC_CHAIR_CAR, 1, train9, 10, 10, 10);
//        Coach.GenerateCoach((Scanner)null, CoachType.EXECUTIVE_CHAIR_CAR, 1, train9, 10, 10, 10);
//        TrainInventory.add(train9);
//
//        Train train10 = new Train(12627, "Chennai", "Delhi", "Chennai, Vijayawada, Nagpur, Bhopal, Agra, Delhi", 1600.0,LocalDate.of(2026,11,24), LocalTime.of(5,30));
//        Coach.GenerateCoach((Scanner)null, CoachType.AC_CHAIR_CAR, 1, train10, 10, 10, 10);
//        Coach.GenerateCoach((Scanner)null, CoachType.EXECUTIVE_CHAIR_CAR, 1, train10, 10, 10, 10);
//        TrainInventory.add(train10);
//
//
//        Train train11 = new Train(20665, "Chennai", "Tirunelveli", "Chennai, Villupuram, Trichy, Madurai, Tirunelveli", 900.0,LocalDate.of(2026,11,24), LocalTime.of(5,30));
//        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train11, 10, 10, 10);
//        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train11, 10, 10, 10);
//        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train11, 10, 10, 10);
//        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train11, 10, 10, 10);
//        TrainInventory.add(train11);
//
//
//        Train train12 = new Train(20627, "Chennai", "Nagercoil", "Chennai, Villupuram, Trichy, Madurai, Nagercoil", 1300.0,LocalDate.of(2026,11,24), LocalTime.of(5,30));
//        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train12, 10, 10, 10);
//        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train12, 10, 10, 10);
//        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train12, 10, 10, 10);
//        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train12, 10, 10, 10);
//        TrainInventory.add(train12);
//
//
//        Train train13 = new Train(12678, "Bangalore", "Ernakulam", "Bangalore, Salem, Erode, Coimbatore, Palakkad, Ernakulam", 650.0,LocalDate.of(2026,11,24), LocalTime.of(5,30));
//        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train13, 10, 10, 10);
//        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train13, 10, 10, 10);
//        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train13, 10, 10, 10);
//        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train13, 10, 10, 10);
//        TrainInventory.add(train13);
//
//
//        Train train14 = new Train(16316, "Mysore", "Trivandrum", "Mysore, Bangalore, Erode, Coimbatore, Ernakulam, Trivandrum", 850.0,LocalDate.of(2026,11,24), LocalTime.of(5,30));
//        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train14, 10, 10, 10);
//        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train14, 10, 10, 10);
//        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train14, 10, 10, 10);
//        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train14, 10, 10, 10);
//        TrainInventory.add(train14);
//
//        Train train15 = new Train(20633, "Mangalore", "Madgaon", "Mangalore, Udupi, Karwar, Madgaon", 1000.0,LocalDate.of(2026,11,24), LocalTime.of(5,30));
//        Coach.GenerateCoach((Scanner)null, CoachType.AC_FIRST, 1, train15, 10, 10, 10);
//        Coach.GenerateCoach((Scanner)null, CoachType.AC_2TIER, 1, train15, 10, 10, 10);
//        Coach.GenerateCoach((Scanner)null, CoachType.AC_3TIER, 1, train15, 10, 10, 10);
//        Coach.GenerateCoach((Scanner)null, CoachType.SLEEPER, 1, train15, 10, 10, 10);
//        TrainInventory.add(train15);
    }
    // STAFF DB
    public static List<Staff> StaffDatabase = new ArrayList<>();
    static {StaffDatabase.add(new SuperAdmin("SA001","Sailuksha", "9999999999", "sa001@railway.in", "sa001@123"));}
    //USER DATABASE
    public static List<User> UserDB = new ArrayList<>();
    static {UserDB.add(new User("Sailuksha", "9442919737", "sai@gmail.com", "sailuksha"));}
    //BOOKING DB
    public static List<BookingService> ActiveBookings = new ArrayList<>();
}