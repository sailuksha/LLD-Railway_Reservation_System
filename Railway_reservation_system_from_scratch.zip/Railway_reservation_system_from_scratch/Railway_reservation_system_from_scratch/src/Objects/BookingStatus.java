package Objects;

public enum BookingStatus {
    AVAILABLE,
    WAITING,
    CONFIRMED,
    RAC,
    CANCELLED
}
