package Objects;

public enum QuotaType {
        GENERAL,
        LADIES,
        SENIOR_CITIZEN,
        PHYSICALLY_CHALLENGED,
        TATKAL,
        PREMIUM_TATKAL

}
