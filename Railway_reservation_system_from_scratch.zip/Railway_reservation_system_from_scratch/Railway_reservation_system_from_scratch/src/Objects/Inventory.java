package Objects;
import Actors.Staff;
import Actors.SuperAdmin;
import Services.PortalRunners;
import java.util.Scanner;
import static Objects.Coach.AddCoach;
import static Objects.Coach.EditCoach;
import static Objects.Storage.TrainInventory;
import static Services.InputValidators.OnlyFloat;
import static Services.InputValidators.OnlyInteger;
import static Services.PortalRunners.InventoryManagerPortal;
import static Services.PortalRunners.SuperAdminPortal;

public class Inventory {

    public static void EditInventory(Scanner scanner, Staff staff) {
        boolean run=true;
        while (run) {
            System.out.println(" EDITING INVENTORY : ");
            System.out.println("1.Add train ");
            System.out.println("2.Edit train");
            System.out.println("3.Remove train");
            System.out.println("4.Exit");
            System.out.println("Enter : ");
            int ch = OnlyInteger(scanner);
            switch (ch) {
                case 1 -> {
                    System.out.println("ADDING TRAIN : ");
                    System.out.println("Enter train no : ");
                    int TrainNo = OnlyInteger(scanner);
                    System.out.println("Enter source : ");
                    String source = scanner.nextLine().trim();
                    System.out.println("Enter destination : ");
                    String dest = scanner.nextLine().trim();
                    System.out.println("Enter complete route : ");
                    String Route=scanner.nextLine().trim();
                    double BaseFare = OnlyFloat(scanner, "Enter base fare : ");
                    Train NewTrain = new Train(TrainNo, source, dest, Route, BaseFare);
                    AddCoach(scanner,NewTrain);
                    TrainInventory.add(NewTrain);
                    System.out.println("Added successfully.");
                    Redirect(scanner,staff);
                }
                case 2 -> {
                    System.out.println("EDITTING TRAIN : ");
                    System.out.println("Enter the train no to be edited : ");
                    int trainno = OnlyInteger(scanner);
                    Train TrainToEdit = null;
                    for (Train t : TrainInventory) {
                        if (trainno == t.getTrainNo()) {
                            TrainToEdit = t;
                            break;
                        }
                    }
                    if (TrainToEdit == null) {
                        System.out.println("Train not found!");
                        break;
                    }
                    System.out.println("1.Edit train no \n 2.Edit source \n 3.Edit destination \n 4.Edit basefare \n5.Edit Coaches");
                    int choose = OnlyInteger(scanner);

                    switch (choose) {

                        case 1 -> {
                            System.out.println("Enter new trainno : ");
                            int NewTrainNo = OnlyInteger(scanner);
                            TrainToEdit.setTrainNo(NewTrainNo);
                            System.out.println("editted");


                        }
                        case 2 -> {
                            System.out.println("Enter new source : ");
                            String NewSource = scanner.nextLine().trim();
                            TrainToEdit.setSource(NewSource);
                            System.out.println("editted");
                        }
                        case 3 -> {
                            System.out.println("Enter new destination : ");
                            String NewDestination = scanner.nextLine().trim();
                            TrainToEdit.setDestination(NewDestination);
                            System.out.println("editted");
                        }
                        case 4 -> {
                            double NewBaseFare = OnlyFloat(scanner, "Enter new Basefare : ");
                            TrainToEdit.SetBaseFare(NewBaseFare);
                            System.out.println("editted");
                        }
                        case 5->{
                            EditCoach(scanner,TrainToEdit);
                        }
                    }
                    Redirect(scanner,staff);
                }
                case 3 -> {
                    System.out.println("Enter trainno to remove : ");
                    int TrainToRemove = OnlyInteger(scanner);
                    for (Train t : TrainInventory) {
                        if (t.getTrainNo() == TrainToRemove) {
                            TrainInventory.remove(t);
                            System.out.println(TrainToRemove + "removed.");
                            Redirect(scanner,staff);
                        }
                    }
                }
                case 4 ->{
                    run=false;
                    Redirect(scanner, staff);
                }
                default -> {
                    System.out.println("invalid option!");
                }
            }
        }
    }
    public static void Redirect(Scanner scanner,Staff staff){
        if (staff instanceof SuperAdmin){
            SuperAdminPortal(scanner,staff);
        }
        else{
            InventoryManagerPortal(scanner,staff);
        }
    }
}
