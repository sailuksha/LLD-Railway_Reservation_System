package Objects;

public enum BerthType {
    LOWER("LB"),
    MIDDLE("MB"),
    UPPER("UB"),
    SIDE_LOWER("SL"),
    SIDE_UPPER("SU");
    private final String code;
    BerthType(String code) {
        this.code = code;
    }

}